from .payments import Payments
from .field_sources import FIELD_SOURCES
from enum import Enum


class PMTR_ENUM(Enum):
    IFPAY_ACCTING_TYPE = {
        FIELD_SOURCES.CSV: 'IFPAY_ACCTING_TYPE',
        FIELD_SOURCES.RAW_PARQUET: 'IFPAY_ACCTING_TYPE',
        FIELD_SOURCES.PROC_PARQUET: 'ACCTING_TYPE',
        FIELD_SOURCES.ELASTIC: 'ACCTING_TYPE'
    }
    IFPAY_36_RATE = 'IFPAY_36_RATE'
    # ACCTING_TYPE = 'ACCTING_TYPE'
    PAYMN_NUMBER = 'PAYMN_NUMBER'
    IFPAY_MT202COV_TAG21 = 'IFPAY_MT202COV_TAG21'
    IFPAY_DEB_ACCOUNT = 'IFPAY_DEB_ACCOUNT'
    IFPAY_PAYMN_DETAIL = 'IFPAY_PAYMN_DETAIL'
    IFPAY_TRAN_CRE = 'IFPAY_TRAN_CRE'

    # def __new__(cls, value):
    #     if isinstance(value, str):
    #         print(value)
    #         return super().__new__(cls, {
    #             FIELD_SOURCES.CSV: value,
    #             FIELD_SOURCES.RAW_PARQUET: value,
    #             FIELD_SOURCES.PROC_PARQUET: value,
    #             FIELD_SOURCES.ELASTIC: value
    #         })
    #     else:
    #         print(value)
    #         return super().__new__(cls, value)
            # 'IFPAY_BANK_INFO',
            # 'IFPAY_BEN_ACCOUNT', 'IFPAY_CAPTURE_DATE', 'IFPAY_CEUR_EXRATE',
            # 'IFPAY_CHQ_CODE', 'IFPAY_CHRG_CODE', 'IFPAY_CONT_AMOUNT',
            # 'IFPAY_CONT_EX_RATE', 'IFPAY_CORR_TYPE', 'IFPAY_CRE_ACCOUNT',
            # 'IFPAY_CRE_AMOUNT', 'IFPAY_CRE_CURR', 'IFPAY_CRE_VAL_DATE',
            # 'IFPAY_CUST_EX_RATE', 'IFPAY_DEB_ACCOUNT', 'IFPAY_DEB_VAL_DATE',
            # 'IFPAY_DEUR_EXRATE', 'IFPAY_DIRECT_ID', 'IFPAY_EXEC_DATE',
            # 'IFPAY_GROS_CRE_AM', 'IFPAY_GROS_CRE_CUR', 'IFPAY_GROS_DEB_AM',
            # 'IFPAY_GROS_DEB_CUR', 'IFPAY_LOC_AMNT', 'IFPAY_MAIN_STATUS',
            # 'IFPAY_MT103_FTAG53', 'IFPAY_MT103_FTAG54', 'IFPAY_MT202COV_TAG33',
            # 'IFPAY_MT202COV_TAG50', 'IFPAY_MT202COV_TAG52', 'IFPAY_MT202COV_TAG59',
            # 'IFPAY_MT202COV_TAG70', 'IFPAY_MT202COV_TAG72', 'IFPAY_OCU_ACCOUNT',
            # 'IFPAY_ORG_AMOUNT', 'IFPAY_ORG_CURR', 'IFPAY_PAYM_AMNT',
            # 'IFPAY_PAYM_CURR', 'IFPAY_PAYMN_DETAIL', 'IFPAY_PAYMN_REF',
            # 'IFPAY_REC_CNTRY', 'IFPAY_REF_TRAN_CRE', 'IFPAY_REF_TRAN_DEB', 'IFPAY_REG_AMOUNT', 'IFPAY_REG_CURR', 'IFPAY_SEN_CNTRY',
            # 'IFPAY_MT202COV_TAG21', 'IFPAY_SRC_FORMAT', 'IFPAY_TRAN_CRE',
            # 'IFPAY_TRAN_DEB'

class PMTR(Payments):

    def column_list(self):
        pass

    def mandatory_fields(self) -> list:
        # enum_c = PMTR_ENUM()
        return [
            PMTR_ENUM.IFPAY_ACCTING_TYPE, PMTR_ENUM.PAYMN_NUMBER, 
            PMTR_ENUM.IFPAY_MT202COV_TAG21, PMTR_ENUM.IFPAY_36_RATE
        ]
    
    def direct_comparisons(self) -> list:
        return [PMTR_ENUM.IFPAY_DEB_ACCOUNT, PMTR_ENUM.IFPAY_ACCTING_TYPE, PMTR_ENUM.IFPAY_TRAN_CRE, PMTR_ENUM.IFPAY_PAYMN_DETAIL]