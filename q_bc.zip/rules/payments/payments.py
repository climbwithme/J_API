from abc import ABC, abstractmethod

class Payments(ABC):

    @abstractmethod
    def column_list(self) -> list:
        pass

    @abstractmethod
    def mandatory_fields(self) -> list:
        pass
