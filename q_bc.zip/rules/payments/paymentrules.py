from enum import Enum

class PAYMENT_TYPE(Enum):
    PMTR= 'PMTR'
    PMTN= 'PMTN'

class PaymentRules:

    def getSuffix(self, payment_type: PAYMENT_TYPE):
        if payment_type == payment_type.PMTR:
            suffix = "RBS"
        elif payment_type == payment_type.PMTN:
            suffix = "NWB"
        return suffix

    def getPaymentTypeFromFileName(self, fname):
        payment_type = fname.split('_')[1]
        if payment_type == PAYMENT_TYPE.PMTR.value:
            return PAYMENT_TYPE.PMTR
        elif payment_type == PAYMENT_TYPE.PMTN.value:
            return PAYMENT_TYPE.PMTN