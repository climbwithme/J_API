from enum import Enum

class FIELD_SOURCES(Enum):
    CSV = 'CSV'
    RAW_PARQUET = 'RAW_PARQUET'
    PROC_PARQUET = 'PROC_PARQUET'
    ELASTIC = 'ELASTIC'
