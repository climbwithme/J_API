$currentDirectory = Get-Location
$job_id=$args[0]
$job_type=$args[1]
$bypass=$args[2]

Write-Host "Current Directory: $currentDirectory"
Write-Host "Job ID: $job_id"


$output_path = './app/static/py_reports/External/' + $job_id

$file_pull_path = $output_path + '/1_file_pull'
$mandatory_path = $output_path + '/2_mandatory'
$comp_path = $output_path + '/3_comparison'
$fieldlength_path = $output_path + '/4_fieldlength'
$count_path = $output_path + '/5_count_check_path'
$report_path = $output_path + '/extract_report_in_excel'

New-Item -ItemType Directory -Path $output_path -ErrorAction SilentlyContinue

$file_pull = './tests/external/test_1_file_pull.py'
$mandatory = './tests/external/test_2_mandatory.py'
$comp = './tests/external/test_3_comparison.py'
$fieldlength = './tests/external/test_4_field_length.py'
$count_chk = './tests/external/test_5_count_check.py'

.\venv\Scripts\Activate.ps1

$database = "./app/q_automation.db"
$start_sql = "UPDATE external_job_ids SET status = 'STARTED' where id=$job_id;"

if ($bypass -ne "True") {
    pytest $file_pull --alluredir="$output_path/reports" --job_id $job_id --job_type "$job_type" > "$file_pull_path.txt"
}
sqlite3.exe $database $start_sql

if ($LASTEXITCODE -eq 0) {
    pytest $mandatory --alluredir="$output_path/reports" --job_id $job_id --job_type "$job_type" > "$mandatory_path.txt"
    pytest $comp --alluredir="$output_path/reports" --job_id $job_id --job_type "$job_type" > "$comp_path.txt"
    pytest $fieldlength --alluredir="$output_path/reports" --job_id $job_id --job_type "$job_type" > "$fieldlength_path.txt"
    pytest $count_chk --alluredir="$output_path/reports" --job_id $job_id --job_type "$job_type" > "$count_path.txt"
}

pytest .\tests\setup\test_write_summary.py --job_id $job_id --job_type "$job_type" > $report_path

$sql = "UPDATE external_job_ids SET status = 'COMPLETED' where id=$job_id;"
sqlite3.exe $database $sql