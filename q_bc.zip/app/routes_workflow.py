from app import app, db
from flask import render_template, request, redirect, url_for, flash
from datetime import datetime

import os
import re
import subprocess

from config_test import TestConfig
from systems.reusables.awscommons import AwsCommons
from systems.reusables.commons import Commons
from systems.reusables.oscommons import OsCommons
from .models import AwsBucket, ExtJobIDS, IntJobIDS, AWSEnvDetails, QuanJobIDS
from app.forms import (
    ApplicationForm,
    ExternalJConfigForm,
    InternalJConfigForm,
    QuantexaJConfigForm,
    QuantexaJConfigFormConfirm,
    QuantexaVForm,
    ExternalVForm,
    InternalVForm,
)


def getCurrentAwsBuckets():
    aws_buckets = AwsBucket.query.all()
    bucket_list = []
    for bucket in aws_buckets:
        print(bucket.bucket_name)
        bucket_list.extend([bucket.bucket_name])
    return bucket_list


def get_all_EnvConfig():
    entries = db.session.query(AWSEnvDetails).all()
    data = {}
    for entry in entries:
        key = entry.name
        values = {}
        values["internal_target"] = entry.internal_target
        values["external_source"] = entry.external_source
        values["external_target"] = entry.external_target
        values["q_csv"] = entry.q_csv
        values["q_pq"] = entry.q_pq
        values["q_proc_pq"] = entry.q_proc_pq
        data[key] = values
    return data


def getAwsBucketName(key):
    return AwsBucket.query.filter_by(bucket_name=key).first().bucket_value


def getAwsFileFromPath(bucket_name, path):
    aws_commons = AwsCommons()
    response = aws_commons.get_list_of_objects(bucket_name, path)
    keys = []
    try:
        for val in response["Contents"]:
            keys.append(val["Key"])
    except:
        return []
    return keys


def getAwsFileFromPathContaining(bucket_name, path, containing):
    aws_commons = AwsCommons()
    response = aws_commons.get_list_of_objects(bucket_name, path)
    keys = []
    try:
        for val in response["Contents"]:
            # print(val)
            value = val["Key"]
            if containing in value:
                keys.append(value)
    except:
        return []
    return keys

def submit_external_jobid_instance(job_id_instance):
    db.session.add(job_id_instance)
    db.session.commit()

    id = job_id_instance.id
    path = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), "script_external.ps1"
    )
    cmd = [
        "powershell.exe",
        "-ExecutionPolicy",
        "Unrestricted",
        "-File",
        path,
        str(id),
        str("External"),
        "False"
    ]
    logpath = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), "static", "py_reports", "external", f"{id}"
    )
    OsCommons().create_path(logpath)
    log_file = f"{logpath}\\logfile_external.txt"
    with open(log_file, "w") as log_file:
        process = subprocess.Popen(cmd, stdout=log_file, stderr=log_file)
    return id

def submit_internal_jobid_instance(job_id_instance, module):
    db.session.add(job_id_instance)
    db.session.commit()

    id = job_id_instance.id
    path = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), "script_internal.ps1"
    )
    cmd = [
        "powershell.exe",
        "-ExecutionPolicy",
        "Unrestricted",
        "-File",
        path,
        str(id),
        str("Internal"),
        module,
        "False"
    ]
    logpath = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), "static", "py_reports", "internal", f"{id}"
    )
    OsCommons().create_path(logpath)
    log_file = f"{logpath}\\logfile_internal.txt"
    with open(log_file, "w") as log_file:
        process = subprocess.Popen(cmd, stdout=log_file, stderr=log_file)
    return id

def submit_quantexa_jobid_instance(job_id_instance, workflow):
    db.session.add(job_id_instance)
    db.session.commit()
    id = job_id_instance.id
    path = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), "script_quantexa.ps1"
    )
    logpath = os.path.join(
        os.path.abspath(os.path.dirname(__file__)), "static", "py_reports", "quantexa", f"{id}"
    )
    OsCommons().create_path(logpath)
    
    cmd = [
        "powershell.exe",
        "-ExecutionPolicy",
        "Unrestricted",
        "-File",
        path,
        str(id),
        str("Quantexa"),
        workflow,
        "False"
    ]
    log_file = f"{logpath}\\logfile_quantexa.txt"
    with open(log_file, "w") as log_file:
        process = subprocess.Popen(cmd, stdout=log_file, stderr=log_file)
    return id


@app.route("/", methods=["GET", "POST"])
@app.route("/index", methods=["GET", "POST"])
def home_page():
    form = ApplicationForm()
    application_module = TestConfig.APPLICATIONS_MODULE
    application = ""
    workflow = ""
    module = ""
    if request.method == "POST":
        application = request.values["application"]
        form.application.choices = list(application_module.keys())
        if application == "Quantexa CB":
            form.workflow.choices = list(application_module.get(application))
        elif application == "Informatica BDM":
            form.workflow.choices = list(application_module.get(application).keys())
        if request.values["ov_application"] == application:
            if "workflow" in request.values.keys():
                workflow = request.values["workflow"]
                if application == "Quantexa CB":
                    return redirect(
                        url_for(
                            "job_configs_quantexa",
                            application=application,
                            workflow=workflow,
                        )
                    )
                form.module.choices = list(
                    application_module[application].get(workflow)
                )
                if "module" in request.values.keys():
                    module = request.values["module"]
                    if workflow == "External":
                        return redirect(
                            url_for(
                                "job_configs_external",
                                application=application,
                                workflow=workflow,
                                module=module,
                            )
                        )
                    else:
                        return redirect(
                            url_for(
                                "job_configs_internal",
                                application=application,
                                workflow=workflow,
                                module=module,
                            )
                        )
    else:
        form.application.choices = list(application_module.keys())
    return render_template(
        "home.html",
        title="Quantexa Automation Home",
        home_page=True,
        form=form,
        application=application,
        workflow=workflow,
        module=module,
    )


@app.route("/job_configs_external", methods=["GET", "POST"])
def job_configs_external():
    form = ExternalJConfigForm()
    application = request.values["application"]
    workflow = request.values["workflow"]
    module = request.values["module"]

    date_month_indicator = TestConfig.EXTERNAL_TYPE.get(module)
    env_dict = get_all_EnvConfig()

    print(request.values)
    bucket_list = getCurrentAwsBuckets()

    form.bucket_source.choices = bucket_list
    form.bucket_target.choices = bucket_list

    return render_template(
        "job_configs/external_workflow.html",
        title="External Workflow",
        job_configs=True,
        form=form,
        application=application,
        workflow=workflow,
        module=module,
        date_month_indicator=date_month_indicator.value,
        env_dict=env_dict,
        subheader='Select Test Configuration'
    )


@app.route("/job_configs_internal", methods=["GET", "POST"])
def job_configs_internal():
    form = InternalJConfigForm()
    application = request.values["application"]
    workflow = request.values["workflow"]
    module = request.values["module"]

    env_dict = get_all_EnvConfig()
    bucket_list = getCurrentAwsBuckets()

    form.bucket_target.choices = bucket_list
    

    if form.validate_on_submit():
        flash('Data Missing')

    return render_template(
        "job_configs/internal_workflow.html",
        title="Internal Workflow",
        job_configs=True,
        form=form,
        application=application,
        workflow=workflow,
        module=module,
        env_dict=env_dict,
        subheader='Select Test Configuration'
    )


@app.route("/job_configs_quantexa", methods=["GET", "POST"])
def job_configs_quantexa():
    form = QuantexaJConfigForm()
    bucket_list = getCurrentAwsBuckets()
    application = request.values["application"]
    workflow = request.values["workflow"]

    form.application = request.values["application"]
    form.workflow = request.values["workflow"]
    form.bucket_source.choices = bucket_list
    form.bucket_target.choices = bucket_list
    form.bucket_processed.choices = bucket_list
    env_dict = get_all_EnvConfig()

    return render_template(
        "job_configs/quantexa_workflow.html",
        title="Quantexa Workflow",
        job_configs=True,
        form=form,
        application=application,
        workflow=workflow,
        env_dict=env_dict,
        subheader='Select Test Configuration'
    )


@app.route("/job_configs_quantexa_confirm", methods=["GET", "POST"])
def job_configs_quantexa_confirm():
    form = QuantexaJConfigFormConfirm()

    application = request.values["application"]
    workflow = request.values["workflow"]

    form.aws_commit_name = request.values["aws_commit_name"]

    form.application = request.values["application"]
    form.workflow = request.values["workflow"]
    form.bucket_source = request.values["bucket_source"]
    form.bucket_target = request.values["bucket_target"]
    form.bucket_processed = request.values["bucket_processed"]

    form.batch_date = request.values["batch_date"]
    env_dict = get_all_EnvConfig()

    form.path_csv = env_dict[form.bucket_source]["q_csv"]
    form.path_rawpq = env_dict[form.bucket_target]["q_pq"].replace("~~~~~", form.aws_commit_name)
    form.path_procpq = env_dict[form.bucket_processed]["q_proc_pq"].replace(
        "~~~~~", form.aws_commit_name
    )

    return render_template(
        "job_validators/quantexa_path.html",
        title="Quantexa Workflow",
        job_configs=True,
        form=form,
        application=application,
        workflow=workflow,
        env_dict=env_dict,
        subheader='Confirm/Update Test Configuration'
    )


@app.route("/validator_external", methods=["GET", "POST"])
def validator_external():
    form = ExternalVForm()
    print(request.values)
    path_aws_source = request.values["path_aws_source"]
    path_aws_target = request.values["path_aws_target"]
    application = request.values["application"]
    workflow = request.values["workflow"]
    module = request.values["module"]

    bucket_source = getAwsBucketName(request.values["bucket_source"])
    bucket_target = getAwsBucketName(request.values["bucket_target"])

    if module == "Country Risk":
        filter_contains = "Country_Risk_List"

    form.source_file_list.choices = getAwsFileFromPathContaining(
        bucket_source, path_aws_source, filter_contains
    )
    form.target_file_list.choices = getAwsFileFromPathContaining(
        bucket_target, path_aws_target, filter_contains
    )

    src_list = []
    target_list = []

    for value in form.source_file_list.choices:
        if value.endswith(".csv"):
            if "batch_month" in request.values:
                batch_month = request.values["batch_month"]
                file_name = value.rsplit(".csv")[0].rsplit("/", maxsplit=1)[1]
                pattern = r'\d{4}-\d{2}'
                match = re.search(pattern, file_name)
                print(match)
                dt_obj = datetime.strptime(batch_month, "%Y-%m")
                print(dt_obj)
                if match.group() == dt_obj.strftime('%Y-%m'):
                    src_list.append(value)
            else:
                src_list.append(value)
    for value in form.target_file_list.choices:
        if value.endswith(".csv"):
            target_list.append(value)

    form.source_file_list.choices = src_list
    form.target_file_list.choices = target_list
    count_source = len(form.source_file_list.choices)
    count_target = len(form.target_file_list.choices)

    if count_source == 0:
        flash(
            f"No CSV Files Found in provided source data: Bucket: {bucket_source} | Path: {path_aws_source}"
        )
    else:
        flash(f"PASS: {count_source} Source CSV Found")
    if count_target == 0:
        flash(
            f"No CSV Files Found in provided source data: Bucket: {bucket_target} | Path: {path_aws_target}"
        )
    else:
        flash(f"PASS: {count_target} Target CSV Found")

    return render_template(
        "job_validators/external_wf.html",
        title="External Workflow",
        job_configs=True,
        form=form,
        application=application,
        workflow=workflow,
        module=module,
        bucket_target=bucket_target,
        bucket_source=bucket_source,
        subheader='Select Test Configuration'
    )


@app.route("/validator_quantexa", methods=["GET", "POST"])
def validator_quantexa():
    form = QuantexaVForm()
    print(request.values)
    application = request.values["application"]
    workflow = request.values["workflow"]

    form.bucket_source = getAwsBucketName(request.values["bucket_source"])
    form.bucket_target = getAwsBucketName(request.values["bucket_target"])
    form.bucket_processed = getAwsBucketName(request.values["bucket_processed"])
    form.batch_date = request.values["batch_date"]
    form.aws_commit_name = request.values["aws_commit_name"]

    form.path_csv = request.values["path_csv"]
    form.path_rawpq = request.values["path_rawpq"]
    form.path_procpq = request.values["path_procpq"]
    
    if workflow == "Payments":
        filter_contains = "Payment"

    form.source_file_list.choices = getAwsFileFromPathContaining(
        form.bucket_source, form.path_csv, filter_contains
    )
    form.target_file_list.choices = getAwsFileFromPathContaining(
        form.bucket_target, form.path_rawpq, ".parquet"
    )
    form.proc_pq_file_list.choices = getAwsFileFromPathContaining(
        form.bucket_processed, form.path_procpq, ".parquet"
    )

    filtered_list = []
    for value in form.source_file_list.choices:
        if value.endswith(".csv"):
            print(value)
            file_dt = value.rsplit(".csv")[0].rsplit("_", maxsplit=1)[1]
            print(file_dt)
            dt_obj = datetime.strptime(form.batch_date, "%Y-%m-%d")
            try:
                file_dt_obj = datetime.strptime(file_dt, "%Y%m%d")
            except:
                continue
            if file_dt_obj == dt_obj:
                filtered_list.append(value)
    form.source_file_list.choices = filtered_list

    csv_list = len(form.source_file_list.choices)
    pq_list = len(form.target_file_list.choices)
    proc_pq_list = len(form.proc_pq_file_list.choices)

    if csv_list == 0:
        flash(
            f"No CSV Files Found in provided source data: Bucket: {form.bucket_source} | Path: {form.path_csv}"
        )
    else:
        flash(f"PASS: {csv_list} Source CSV Found")
    if pq_list == 0:
        flash(
            f"No Parquet Files Found in provided target data: Bucket: {form.bucket_target} | Path: {form.path_rawpq}"
        )
    else:
        flash(f"PASS: {pq_list} Target Parquet Found")
    if proc_pq_list == 0:
        flash(
            f"No Parquet Files Found in provided data: Bucket: {form.bucket_processed} | Path: {form.path_procpq}"
        )
    else:
        flash(f"PASS: {proc_pq_list} Target CSV Found")
    return render_template(
        "job_validators/quantexa_wf.html",
        title="Quantexa Workflow",
        job_configs=True,
        form=form,
        application=application,
        workflow=workflow,
        subheader='Select Files Under Test'
    )


@app.route("/validator_internal", methods=["GET", "POST"])
def validator_internal():
    form = InternalVForm()
    print(request.values)
    path_aws_target = request.values["path_aws_target"]
    application = request.values["application"]
    workflow = request.values["workflow"]
    module = request.values["module"]
    filter_start_date = request.values["filter_start_date"]
    filter_end_date = request.values["filter_end_date"]

    bucket_target = getAwsBucketName(request.values["bucket_target"])

    if module == "Payments":
        filter_contains = "Payment"

    form.target_file_list.choices = getAwsFileFromPathContaining(
        bucket_target, path_aws_target, filter_contains
    )

    filtered_list = []
    for value in form.target_file_list.choices:
        if value.endswith(".csv"):
            file_dt = value.rsplit(".csv")[0].rsplit("_", maxsplit=1)[1]
            st_dt_obj = datetime.strptime(
                request.values["filter_start_date"], "%Y-%m-%d"
            )
            ed_dt_obj = datetime.strptime(request.values["filter_end_date"], "%Y-%m-%d")

            file_dt_obj = datetime.strptime(file_dt, "%Y%m%d")
            if file_dt_obj <= ed_dt_obj and file_dt_obj >= st_dt_obj:
                filtered_list.append(value)
    form.target_file_list.choices = filtered_list

    count_target = len(form.target_file_list.choices)
    if count_target == 0:
        flash(
            f"No CSV Files Found in provided source data: Bucket: {bucket_target} | Path: {path_aws_target}"
        )
    else:
        flash(f"PASS: {count_target} Target CSV Found")

    return render_template(
        "job_validators/internal_wf.html",
        title="Internal Workflow",
        job_configs=True,
        form=form,
        application=application,
        workflow=workflow,
        module=module,
        bucket_target=bucket_target,
        filter_start_date=filter_start_date,
        filter_end_date=filter_end_date,
        subheader='Select Files Under Test'
    )

@app.route("/submit_external_api", methods=["POST"])
def submit_external_api():
    print(request.values)
    try:
        data = request.get_json()
        print(data)
        module = data["module"]
        bucket_source = data["bucket_source"]
        bucket_target = data["bucket_target"]
        source_file_list = data["source_csv"]
        target_file_list = data["target_csv"]
        validation_count = int(data["validation_count"])
        validation_mandatory = int(data["validation_mandatory"])
        validation_comparison = int(data["validation_comparison"])
        validation_fieldlength = int(data["validation_fieldlength"])

        external_job_id_instance = ExtJobIDS(
            module=module,
            bucket_source_csv=bucket_source,
            bucket_target_csv=bucket_target,
            source_csv=source_file_list,
            target_csv=target_file_list,
            validation_count=validation_count,
            validation_mandatory=validation_mandatory,
            validation_comparison=validation_comparison,
            validation_fieldlength=validation_fieldlength,
        )

        id = submit_external_jobid_instance(external_job_id_instance)

        return {'result': 'Job Submitted', 'Job id': id}
    except KeyError:
        return {'error': 'Invalid JSON Payload'}, 400

@app.route("/submit_quantexa_api", methods=["POST"])
def submit_quantexa_api():
    print(request.values)
    try:
        data = request.get_json()
        print(data)
        module = data["module"]
        workflow = data["workflow"]
        bucket_source = data["bucket_source"]
        source_file_list = data["source_file_list"].replace("\"\"", "\"")
        bucket_processed = data["bucket_processed"]
        path_procpq = data["path_procpq"]
        bucket_target = data["bucket_target"]
        elastic_index = data["elastic_index"]
        path_rawpq = data["path_rawpq"]
        validation_count = int(data["validation_count"])
        validation_mandatory = int(data["validation_mandatory"])
        validation_comparison = int(data["validation_comparison"])
        validation_csv_pq = int(data["validation_csv_pq"])
        validation_pq_pro = int(data["validation_pq_pro"])
        validation_pro_quan = int(data["validation_pro_quan"])
        
        job_id_instance = QuanJobIDS(
            module=module,
            bucket_source=bucket_source,
            bucket_target=bucket_target,
            bucket_processed=bucket_processed,
            source_file_list=source_file_list,
            path_procpq=path_procpq,
            elastic_index=elastic_index,
            path_rawpq=path_rawpq,
            validation_count=validation_count,
            validation_mandatory=validation_mandatory,
            validation_comparison=validation_comparison,
            validation_csv_pq=validation_csv_pq,
            validation_pq_pro=validation_pq_pro,
            validation_pro_quan=validation_pro_quan
        )

        id = submit_quantexa_jobid_instance(job_id_instance, workflow)
    
        return {'result': 'Job Submitted', 'Job id': id}
    except KeyError:
        return {'error': 'Invalid JSON Payload'}, 400

@app.route("/submit_internal_api", methods=["GET", "POST"])
def submit_internal_api():
    print(request.values)
    try:
        data = request.get_json()
        print(data)
        module = data["module"]
        bucket_target = data["bucket_target"]
        target_file_list = data["target_csv"]
        filter_start_date = datetime.strptime(data["filter_start_date"], "%Y-%m-%d")
        filter_end_date = datetime.strptime(data["filter_end_date"], "%Y-%m-%d")
        validation_count = int(data["validation_count"])
        validation_mandatory = int(data["validation_mandatory"])
        validation_comparison = int(data["validation_comparison"])
        validation_fieldlength = int(data["validation_fieldlength"])

        internal_job_id_instance = IntJobIDS(
            module=module,
            bucket_target_csv=bucket_target,
            filter_start_date=filter_start_date,
            filter_end_date=filter_end_date,
            target_csv=target_file_list,
            validation_count=validation_count,
            validation_mandatory=validation_mandatory,
            validation_comparison=validation_comparison,
            validation_fieldlength=validation_fieldlength
        )

        id = submit_internal_jobid_instance(internal_job_id_instance, module)
    
        return {'result': 'Job Submitted', 'Job id': id}
    except KeyError:
        return {'error': 'Invalid JSON Payload'}, 400

@app.route("/submit_external", methods=["GET", "POST"])
def submit_external():
    print(request.values)
    application = request.values["application"]
    workflow = request.values["workflow"]
    module = request.values["module"]
    bucket_source = request.values["bucket_source"]
    bucket_target = request.values["bucket_target"]
    source_file_list = request.values["source_file_list"]
    target_file_list = request.values["target_file_list"]
    validation_count = int(request.values["validation_count"])
    validation_mandatory = int(request.values["validation_mandatory"])
    validation_comparison = int(request.values["validation_comparison"])
    validation_fieldlength = int(request.values["validation_fieldlength"])

    external_job_id_instance = ExtJobIDS(
        module=module,
        bucket_source_csv=bucket_source,
        bucket_target_csv=bucket_target,
        source_csv=source_file_list,
        target_csv=target_file_list,
        validation_count=validation_count,
        validation_mandatory=validation_mandatory,
        validation_comparison=validation_comparison,
        validation_fieldlength=validation_fieldlength,
    )

    id = submit_external_jobid_instance(external_job_id_instance)

    return render_template(
        "job_submitted/external.html",
        title="External Job",
        application=application,
        workflow=workflow,
        module=module,
        bucket_target=bucket_target,
        bucket_source=bucket_source,
        source_file_list=source_file_list,
        target_file_list=target_file_list,
        id=id,
        validation_count="Yes" if validation_count == 1 else "No",
        validation_mandatory="Yes" if validation_mandatory == 1 else "No",
        validation_comparison="Yes" if validation_comparison == 1 else "No",
        validation_fieldlength="Yes" if validation_fieldlength == 1 else "No",
        subheader='Job Submitted'
    )


@app.route("/submit_quantexa", methods=["GET", "POST"])
def submit_quantexa():
    print(request.values)
    application = request.values["application"]
    workflow = request.values["workflow"]
    bucket_source = request.values["bucket_source"]
    source_file_list = request.values.getlist("source_file_list")
    bucket_processed = request.values["bucket_processed"]
    path_procpq = request.values["path_procpq"]
    bucket_target = request.values["bucket_target"]
    elastic_index = request.values["elastic_index"]
    path_rawpq = request.values["path_rawpq"]
    validation_count = int(request.values["validation_count"])
    validation_mandatory = int(request.values["validation_mandatory"])
    validation_comparison = int(request.values["validation_comparison"])
    validation_csv_pq = int(request.values["validation_csv_pq"])
    validation_pq_pro = int(request.values["validation_pq_pro"])
    validation_pro_quan = int(request.values["validation_pro_quan"])
    
    job_id_instance = QuanJobIDS(
        module=workflow,
        bucket_source=bucket_source,
        bucket_target=bucket_target,
        bucket_processed=bucket_processed,
        source_file_list=source_file_list,
        path_procpq=path_procpq,
        elastic_index=elastic_index,
        path_rawpq=path_rawpq,
        validation_count=validation_count,
        validation_mandatory=validation_mandatory,
        validation_comparison=validation_comparison,
        validation_csv_pq=validation_csv_pq,
        validation_pq_pro=validation_pq_pro,
        validation_pro_quan=validation_pro_quan
    )

    id = submit_quantexa_jobid_instance(job_id_instance, workflow)
    
    return render_template(
        "job_submitted/quantexa.html",
        title="Quantexa Job",
        application=application,
        workflow=workflow,
        bucket_source=bucket_source,
        bucket_processed=bucket_processed,
        bucket_target=bucket_target,
        source_file_list=source_file_list,
        path_procpq=path_procpq,
        path_rawpq=path_rawpq,
        id=id,
        validation_count="Yes" if validation_count == 1 else "No",
        validation_mandatory="Yes" if validation_mandatory == 1 else "No",
        validation_comparison="Yes" if validation_comparison == 1 else "No",
        validation_csv_pq="Yes" if validation_csv_pq == 1 else "No",
        validation_pq_pro="Yes" if validation_pq_pro == 1 else "No",
        validation_pro_quan="Yes" if validation_pro_quan == 1 else "No",
        subheader='Job Submitted'
    )


@app.route("/submit_internal", methods=["GET", "POST"])
def submit_internal():
    print(request.values)
    application = request.values["application"]
    workflow = request.values["workflow"]
    module = request.values["module"]
    bucket_target = request.values["bucket_target"]
    target_file_list = request.values.getlist("target_file_list")
    filter_start_date = datetime.strptime(
        request.values["filter_start_date"], "%Y-%m-%d"
    )
    filter_end_date = datetime.strptime(request.values["filter_end_date"], "%Y-%m-%d")
    validation_count = int(request.values["validation_count"])
    validation_mandatory = int(request.values["validation_mandatory"])
    validation_comparison = int(request.values["validation_comparison"])

    internal_job_id_instance = IntJobIDS(
        module=module,
        bucket_target_csv=bucket_target,
        filter_start_date=filter_start_date,
        filter_end_date=filter_end_date,
        target_csv=target_file_list,
        validation_count=validation_count,
        validation_mandatory=validation_mandatory,
        validation_comparison=validation_comparison,
    )

    id = submit_internal_jobid_instance(internal_job_id_instance, module)

    return render_template(
        "job_submitted/internal.html",
        title="Internal Job",
        application=application,
        workflow=workflow,
        module=module,
        bucket_target=bucket_target,
        filter_start_date=filter_start_date.strftime("%d-%m-%Y"),
        filter_end_date=filter_end_date.strftime("%d-%m-%Y"),
        target_file_list=list(target_file_list),
        id=id,
        validation_count="Yes" if validation_count == 1 else "No",
        validation_mandatory="Yes" if validation_mandatory == 1 else "No",
        validation_comparison="Yes" if validation_comparison == 1 else "No",
        subheader='Job Submitted'
    )
