from app import db
from datetime import datetime
from enum import Enum

class StatusChoices(Enum):
    SUBMITTED = 'Submitted'
    STARTED = 'Started'
    COMPLETED = 'Completed'

class AwsBucket(db.Model):
    __tablename__ = "aws_bucket"

    bucket_name = db.Column(
        db.String(64), primary_key=True, unique=True, nullable=False
    )
    bucket_value = db.Column(db.String(64), unique=True, nullable=False)


class AWSEnvDetails(db.Model):
    __tablename__ = "aws_env_details"

    id = db.Column(db.Integer, primary_key=True)
    name =  db.Column(db.String(64), db.ForeignKey('aws_bucket.bucket_name'), nullable=True)
    internal_target = db.Column(db.String(64))
    external_source = db.Column(db.String(64))
    external_target = db.Column(db.String(64))
    q_csv = db.Column(db.String(64))
    q_pq = db.Column(db.String(64))
    q_proc_pq = db.Column(db.String(64))


class ExtJobIDS(db.Model):
    __tablename__ = "external_job_ids"

    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(20), default='External')
    submitted_on = db.Column(db.DateTime, nullable=False, default=datetime.now)
    status = db.Column(db.Enum(StatusChoices), default=StatusChoices.SUBMITTED)

    module = db.Column(db.String(32), nullable=False)

    bucket_source_csv = db.Column(db.String(32), nullable=False)
    bucket_target_csv = db.Column(db.String(32), nullable=False)

    source_csv = db.Column(db.String(120), nullable=False)
    target_csv = db.Column(db.String(120), nullable=False)

    validation_count = db.Column(db.Boolean, default=True)
    validation_mandatory = db.Column(db.Boolean, default=True)
    validation_comparison = db.Column(db.Boolean, default=True)
    validation_fieldlength = db.Column(db.Boolean, default=True)


class IntJobIDS(db.Model):
    __tablename__ = "internal_job_ids"

    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(20), default='Internal')
    submitted_on = db.Column(db.DateTime, nullable=False, default=datetime.now)
    status = db.Column(db.Enum(StatusChoices), default=StatusChoices.SUBMITTED)

    module = db.Column(db.String(32), nullable=False)

    bucket_target_csv = db.Column(db.String(32), nullable=False)
    target_csv = db.Column(db.JSON, nullable=False)

    filter_start_date = db.Column(db.Date, nullable=False)
    filter_end_date = db.Column(db.Date, nullable=False)

    validation_count = db.Column(db.Boolean, default=True)
    validation_mandatory = db.Column(db.Boolean, default=True)
    validation_comparison = db.Column(db.Boolean, default=True)
    validation_fieldlength = db.Column(db.Boolean, default=True)


class QuanJobIDS(db.Model):
    __tablename__ = "quantexa_job_ids"

    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(20), default='Quantexa')

    submitted_on = db.Column(db.DateTime, nullable=False, default=datetime.now)
    status = db.Column(db.Enum(StatusChoices), default=StatusChoices.SUBMITTED)
    module = db.Column(db.String(32), nullable=False)

    bucket_source = db.Column(db.String(32), nullable=False)
    bucket_target = db.Column(db.String(32), nullable=False)
    bucket_processed = db.Column(db.String(32), nullable=False)

    source_file_list = db.Column(db.JSON, nullable=False)
    path_procpq = db.Column(db.String(32), nullable=False)
    path_rawpq = db.Column(db.String(32), nullable=False)

    elastic_index = db.Column(db.String(32), nullable=False)

    validation_csv_pq = db.Column(db.Boolean, default=True)
    validation_pq_pro = db.Column(db.Boolean, default=True)
    validation_pro_quan = db.Column(db.Boolean, default=True)
    validation_count = db.Column(db.Boolean, default=True)
    validation_mandatory = db.Column(db.Boolean, default=True)
    validation_comparison = db.Column(db.Boolean, default=True)

class RulesCountryRisk(db.Model):
    __tablename__ = "rules_country_risk"
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64))
    primary_key = db.Column(db.Boolean, default=False)

    mandatory = db.Column(db.Boolean, nullable=False)
    availability = db.Column(db.Boolean, nullable=False)
    comparison = db.Column(db.Boolean, nullable=False)
    field_length = db.Column(db.Integer)

    src_transformation = db.Column(db.String(200), nullable=True)

    n_source = db.Column(db.String(32), nullable=False)
    n_target = db.Column(db.String(32), nullable=False)

class RulesPaymentPmnt(db.Model):
    __tablename__ = "rules_payment_pmnt"
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True)
    primary_key = db.Column(db.Boolean, default=True)

    mandatory = db.Column(db.Boolean, nullable=False)
    availability = db.Column(db.Boolean, nullable=False)
    comparison = db.Column(db.Boolean, nullable=False)
    field_length = db.Column(db.Integer)
    
    src_transformation = db.Column(db.String(200), nullable=False)
    transformation = db.Column(db.String(200), nullable=False)

    n_source = db.Column(db.String(32), nullable=False)
    n_pq = db.Column(db.String(32), nullable=False)
    n_proc_pq = db.Column(db.String(32), nullable=False)
    n_es_quan = db.Column(db.String(32), nullable=False)


class RulesPaymentNad(db.Model):
    __tablename__ = "rules_payment_Nad"
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True)
    primary_key = db.Column(db.Boolean, default=True)

    mandatory = db.Column(db.Boolean, nullable=False)
    availability = db.Column(db.Boolean, nullable=False)
    comparison = db.Column(db.Boolean, nullable=False)
    field_length = db.Column(db.Integer)
    
    src_transformation = db.Column(db.String(200), nullable=False)
    transformation = db.Column(db.String(200), nullable=False)

    n_source = db.Column(db.String(32), nullable=False)
    n_pq = db.Column(db.String(32), nullable=False)
    n_proc_pq = db.Column(db.String(32), nullable=False)
    n_es_quan = db.Column(db.String(32), nullable=False)
