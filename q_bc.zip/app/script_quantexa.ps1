
$currentDirectory = Get-Location
$job_id=$args[0]
$job_type=$args[1]
$bypass=$args[2]

Write-Host "Current Directory: $currentDirectory"
Write-Host "Job ID: $job_id"
Write-Host "Job Type: $job_type"
Write-Host "Bypass Download: $bypass"
# Start-Sleep -Seconds 10


$output_path = './app/static/py_reports/Quantexa/' + $job_id

$sanity_path = $output_path + '/0_sanity'
$file_pull_path = $output_path + '/1_file_pull'
$file_pull_pq_path = $output_path + '/2_file_pull_proc_pq'
$csv_pq_path = $output_path + '/3_csv_pq_path'
$data_map_path = $output_path + '/4_data_map_path'
$null_check_path = $output_path + '/5_null_check_path'
$comp_check_path = $output_path + '/6_comp_check_path'
$count_check_path = $output_path + '/7_count_check_path'
$report_path = $output_path + '/extract_report_in_excel'

New-Item -ItemType Directory -Path $output_path -ErrorAction SilentlyContinue

$script_path = './tests/quantexa/test_connections.py'
$file_pull = './tests/quantexa/test_payment_1_file_pull.py'
$file_pull_pp_path = './tests/quantexa/test_payment_2_pq_processed.py'
$csv_pq = './tests/quantexa/test_payment_3_csv_to_pq.py'
$data_map = './tests/quantexa/test_payment_4_data_mapping.py'
$null_chk = './tests/quantexa/test_payment_5_null_checks.py'
$comp_chk = './tests/quantexa/test_payment_6_dir_comparisons.py'
$count_chk = './tests/quantexa/test_payment_7_count_validation.py'

.\venv\Scripts\Activate.ps1

$database = "./app/q_automation.db"
$start_sql = "UPDATE quantexa_job_ids SET status = 'STARTED' where id=$job_id;"

pytest $script_path --alluredir="$output_path/reports" --job_id $job_id > "$sanity_path.txt"

sqlite3.exe $database $start_sql

if ($LASTEXITCODE -eq 0) {
    pytest $file_pull --alluredir="$output_path/reports" --job_id $job_id > "$file_pull_path.txt"
    pytest $file_pull_pp_path --alluredir="$output_path/reports" --job_id $job_id > "$file_pull_pq_path.txt"
    pytest $csv_pq --alluredir="$output_path/reports" --job_id $job_id > "$csv_pq_path.txt"
    pytest $data_map --alluredir="$output_path/reports" --job_id $job_id > "$data_map_path.txt"
    pytest $null_chk --alluredir="$output_path/reports" --job_id $job_id > "$null_check_path.txt"
    pytest $comp_chk --alluredir="$output_path/reports" --job_id $job_id > "$comp_check_path.txt"
    pytest $count_chk --alluredir="$output_path/reports" --job_id $job_id > "$count_check_path.txt"
}

pytest .\tests\setup\test_write_summary.py --job_id $job_id --job_type "$job_type" > $report_path

$sql = "UPDATE quantexa_job_ids SET status = 'COMPLETED' where id=$job_id;"
sqlite3.exe $database $sql