from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Table, MetaData

from config_rules import PaymentFields
from .config import Config
from werkzeug.middleware.proxy_fix import ProxyFix


app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app)
app.config.from_object(Config)

db = SQLAlchemy(app)
metadata = MetaData()



# from app.models import ConfigFile
from app import routes, models
from app.models import RulesCountryRisk, RulesPaymentNad, RulesPaymentPmnt
from app import routes_workflow

def init_db():
    db.create_all()
    print('Created DB')

    rcr_country = RulesCountryRisk(name='Country', mandatory=True, availability=True, comparison=True, n_source='Country', n_target='COUNTRY_NAME')
    rcr_2_digit = RulesCountryRisk(name='ISO 2 Digit code', mandatory=True, availability=True, comparison=True, n_source='ISO 2 Digit code', n_target='CODE', field_length=2)
    rcr_3_digit = RulesCountryRisk(name='ISO 3 Digit code', mandatory=True, availability=False, comparison=False, n_source='ISO 3 Digit code', n_target='N|A')
    rcr_rating = RulesCountryRisk(name='Rating', mandatory=True, availability=True, comparison=True, n_source='~Rating', n_target='RISK_LEVEL')
    rcr_highrisk = RulesCountryRisk(name='High Risk', mandatory=True, availability=False, comparison=True, n_source='Mandatory High Risk Third Country', n_target='N|A')
    
    rpp_1 = RulesPaymentPmnt(name=PaymentFields.PAYMN_NUMBER.value, mandatory=True, availability=True, comparison=True, src_transformation='', transformation='', field_length='', n_source=PaymentFields.PAYMN_NUMBER.value, n_pq='PAYMN_NUMBER', n_proc_pq='PAYMN_NUMBER', n_es_quan='PAYMN_NUMBER')
    rpp_2 = RulesPaymentPmnt(name=PaymentFields.IFPAY_ACCTING_TYPE.value, mandatory=True, availability=True, comparison=True, src_transformation='', transformation='', field_length='', n_source=PaymentFields.IFPAY_ACCTING_TYPE.value, n_pq='IFPAY_ACCTING_TYPE', n_proc_pq='IFPAY_ACCTING_TYPE', n_es_quan='IFPAY_ACCTING_TYPE')
    rpp_3 = RulesPaymentPmnt(name=PaymentFields.IFPAY_PAYMN_REF.value, mandatory=True, availability=True, comparison=True, src_transformation='', transformation='', field_length='', n_source=PaymentFields.IFPAY_PAYMN_REF.value, n_pq='IFPAY_PAYMN_REF', n_proc_pq='IFPAY_PAYMN_REF', n_es_quan='IFPAY_PAYMN_REF')
    rpp_4 = RulesPaymentPmnt(name=PaymentFields.IFPAY_DIRECT_ID.value, mandatory=True, availability=True, comparison=True, src_transformation='', transformation='', field_length='3', n_source=PaymentFields.IFPAY_DIRECT_ID.value, n_pq='IFPAY_DIRECT_ID', n_proc_pq='IFPAY_DIRECT_ID', n_es_quan='IFPAY_DIRECT_ID')

    nad_1 = RulesPaymentNad(name=PaymentFields.PAYMN_NUMBER.value, mandatory=True, availability=True, comparison=True, src_transformation='', transformation='', field_length='', n_source=PaymentFields.PAYMN_NUMBER.value, n_pq='PAYMN_NUMBER', n_proc_pq='PAYMN_NUMBER', n_es_quan='PAYMN_NUMBER')
    nad_2 = RulesPaymentNad(name=PaymentFields.IFNAD_AWI_ADDR.value, mandatory=False, availability=True, comparison=True, src_transformation='', transformation='', field_length='', n_source=PaymentFields.IFNAD_AWI_ADDR.value, n_pq='IFNAD_AWI_ADDR', n_proc_pq='IFNAD_AWI_ADDR', n_es_quan='IFNAD_AWI_ADDR')
    nad_3 = RulesPaymentNad(name=PaymentFields.IFNAD_AWI_CITY.value, mandatory=False, availability=True, comparison=True, src_transformation='', transformation='', field_length='', n_source=PaymentFields.IFNAD_AWI_CITY.value, n_pq='IFNAD_AWI_CITY', n_proc_pq='IFNAD_AWI_CITY', n_es_quan='IFNAD_AWI_CITY')
    nad_4 = RulesPaymentNad(name=PaymentFields.IFNAD_AWI_CNTRY.value, mandatory=True, availability=True, comparison=True, src_transformation='', transformation='', field_length='2', n_source=PaymentFields.IFNAD_AWI_CNTRY.value, n_pq='IFNAD_AWI_CNTRY', n_proc_pq='IFNAD_AWI_CNTRY', n_es_quan='IFNAD_AWI_CNTRY')
    nad_5 = RulesPaymentNad(name=PaymentFields.IFNAD_AWI_NAT.value, mandatory=False, availability=True, comparison=False, src_transformation='', transformation='', field_length='', n_source=PaymentFields.IFNAD_AWI_CNTRY.value, n_pq='IFNAD_AWI_NAT', n_proc_pq='IFNAD_AWI_NAT', n_es_quan='IFNAD_AWI_NAT')

    # nad_list = [nad_1, nad_3, nad_4, nad_5, rpp_1, rpp_2, rpp_3, rpp_4]
    # rcs_list = [rcr_country, rcr_2_digit, rcr_3_digit, rcr_rating, rcr_highrisk]

    #Quantexa_CB/Rawdata/2023-03-11/Country_Risk_List
    #Quantexa_CB/Refdata/Country_Risk_List/

    # payment_pk_csv = models.PaymentConfig(prop_name='PAYMENT_PAYMN', prop_value='PAYMN_NUMBER')
    # payment_pk_final = models.PaymentConfig(prop_name='PAYMENT_TRANSID', prop_value='TRANSACTION_ID')

    uat_env_details = models.AWSEnvDetails(
        name='UAT-RAWDATA',
        internal_target = 'quantexa/Rawdata/',
        external_source = 'quantexa/Refdata/',
        external_target = 'quantexa/Rawdata/',
        q_csv = 'quantexa/Rawdata/',
        q_pq = 'quantexa/aggregatedtransaction//~~~~~/raw/parquet/',
        q_proc_pq = 'quantexa/aggregatedtransaction//~~~~~/DocumentDataModel/FlatTransaction.parquet/',
        )

    print('Adding AWS Entries')
    try:
        # db.session.add(aws_raw)
        # db.session.add(aws_archieve)
        db.session.commit()
    except Exception as e:
        print('Entries already added perhaps', e)
        db.session.rollback()
    print('Done')

    print('Adding Payment Entries')
    try:
        # db.session.add(payment_pk_csv)
        # db.session.add(payment_pk_final)
        # db.session.add(rpp_3)
        # db.session.add(rpp_4)
        db.session.commit()
    except Exception as e:
        print('Entries already added perhaps', e)
        db.session.rollback()
    print('Done')

    print('Adding Config Entries')
    try:
        # db.session.add(config_commit_name)
        # db.session.add(config_prefix_csv)
        # db.session.add(config_prefix_raw_pq)
        # db.session.add(config_prefix_proc_pq)
        # db.session.add(config_index_name)
        # db.session.add(COUN_RISK_SRC)
        # db.session.add(COUN_RISK_TAR)
        # for rcs in nad_list:
            # db.session.add(rcs)
        # db.session.add(uat_env_details)
        db.session.commit()
    except Exception as e:
        print('Entries already added perhaps', e)
        db.session.rollback()
    print('Done')


with app.app_context():
    print('Trying to create DB')
    init_db()

if __name__ == '__main__':
    init_db()
    app.run()