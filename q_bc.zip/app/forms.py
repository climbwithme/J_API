from flask_wtf import FlaskForm
from wtforms import (
    SelectField,
    StringField,
    SubmitField,
    SelectMultipleField,
    BooleanField,
    DateField,
    RadioField,
)
from wtforms.validators import DataRequired, InputRequired, ValidationError
from datetime import datetime, timedelta

from config_test import TestConfig


class MonthField(SelectField):
    def __init__(
        self,
        label=None,
        validators=None,
        coerce=...,
        choices=None,
        validate_choice=True,
        **kwargs,
    ):
        super().__init__(label, validators, coerce, choices, validate_choice, **kwargs)
        choices = []
        today = datetime.today().date()
        for i in range(12):
            date = today - timedelta(days=30 * i)
            month = date.strftime("%m")
            year = date.strftime("%Y")
            label = f"{year}-{month}"
            choices.append((f'{date.strftime("%B")} {year}', label))
        self.choices = choices


class ApplicationForm(FlaskForm):
    application = SelectField("Select Application")
    workflow = SelectField("Select Workflow Type")
    module = SelectField("Select Module")


class ExternalJConfigForm(FlaskForm):
    bucket_source = SelectField("Source Bucket:")
    bucket_target = SelectField("Target Bucket:")
    path_aws_source = StringField(
        "Source Path:",
        render_kw={
            "placeholder": "Enter Path to the source data in the selected bucket"
        },
    )
    path_aws_target = StringField(
        "Target Path:",
        render_kw={
            "placeholder": "Enter Path to the target data in the selected bucket"
        },
    )
    batch_date = DateField("Batch Date:", format="%d-%m-%Y")
    batch_month = MonthField("Batch Month", validators=[InputRequired()])


class ExternalVForm(FlaskForm):
    source_file_list = SelectField("Source File List")
    target_file_list = SelectField("Target File List")
    validation_count = RadioField("Count", choices=[(1, "Yes"), (0, "No")], default=1)
    validation_mandatory = RadioField(
        "Mandatory", choices=[(1, "Yes"), (0, "No")], default=1
    )
    validation_comparison = RadioField(
        "Comparison", choices=[(1, "Yes"), (0, "No")], default=1
    )
    validation_fieldlength = RadioField(
        "Field Length", choices=[(1, "Yes"), (0, "No")], default=0
    )


class InternalVForm(FlaskForm):
    target_file_list = SelectField("Target File List")
    validation_count = RadioField("Count", choices=[(1, "Yes"), (0, "No")], default=1)
    validation_mandatory = RadioField(
        "Mandatory", choices=[(1, "Yes"), (0, "No")], default=1
    )
    validation_comparison = RadioField(
        "Comparison", choices=[(1, "Yes"), (0, "No")], default=1
    )


class QuantexaVForm(FlaskForm):
    bucket_source = SelectField("Source CSV Bucket:")
    bucket_target = SelectField("Target Parquet Bucket:")
    bucket_processed = SelectField("Processed Parquet Bucket:")

    aws_commit_name = StringField("AWS Commit Name")
    elastic_index = StringField("Elastic Index Details")

    source_file_list = SelectField("Source File List")
    target_file_list = SelectField("Target File List")
    proc_pq_file_list = SelectField("Processed Parquet List")
    batch_date = StringField("Batch Date:")

    path_csv = StringField(
        "Target Path:", render_kw={"placeholder": "Enter Path to the csv file location"}
    )
    path_rawpq = StringField(
        "Target Path:", render_kw={"placeholder": "Enter Path to the csv file location"}
    )
    path_procpq = StringField(
        "Target Path:", render_kw={"placeholder": "Enter Path to the csv file location"}
    )

    validation_csv_pq = RadioField("CSV vs Parquet", choices=[(1, "Yes"), (0, "No")], default=1)
    validation_pq_pro = RadioField("Parquet vs Processed Parquet", choices=[(1, "Yes"), (0, "No")], default=1)
    validation_pro_quan = RadioField("Processed Parquet vs Quantexa", choices=[(1, "Yes"), (0, "No")], default=1)

    validation_count = RadioField("Count", choices=[(1, "Yes"), (0, "No")], default=1)
    validation_mandatory = RadioField("Mandatory", choices=[(1, "Yes"), (0, "No")], default=1)
    validation_comparison = RadioField("Comparison", choices=[(1, "Yes"), (0, "No")], default=1)


class InternalJConfigForm(FlaskForm):

    bucket_target = SelectField("Target Bucket:")
    path_aws_target = StringField(
        "Target Path:", render_kw={"placeholder": "Enter Path to the csv file location"}
    )

    filter_start_date = DateField("Hive Start Date:", validators=[InputRequired()])
    filter_end_date = DateField("Hive End Date:", validators=[InputRequired()])
    submit = SubmitField("Validate")

    def validate_filter_start_date(form, field):
        try:
            datetime.strftime(field.data, '%d-%m-%Y')
        except ValueError:
            raise ValidationError('Invalid date format: It should be DD-MM-YYYY')


class QuantexaJConfigForm(FlaskForm):
    application = ""
    workflow = ""

    batch_date = DateField("Batch Date:", format="%d-%m-%Y")
    aws_commit_name = StringField(
        "AWS Commit Name:", render_kw={"placeholder": "Example: 24thcommit-v2"}
    )

    bucket_source = SelectField("Source CSV Bucket:")
    bucket_target = SelectField("Target Parquet Bucket:")
    bucket_processed = SelectField("Processed Parquet Bucket:")


class QuantexaJConfigFormConfirm(FlaskForm):
    application = ""
    workflow = ""

    batch_date = DateField("Batch Date:", format="%d-%m-%Y")
    aws_commit_name = StringField(
        "AWS Commit Name:", render_kw={"placeholder": "Example: 24thcommit-v2"}
    )

    bucket_source = StringField("Source CSV Bucket:")
    bucket_target = StringField("Target Parquet Bucket:")
    bucket_processed = StringField("Processed Parquet Bucket:")

    path_csv = StringField(
        "Source Path:",
        render_kw={
            "placeholder": "Enter Path to the source csv data in the selected bucket"
        },
    )
    path_rawpq = StringField(
        "Target Pq Path:",
        render_kw={
            "placeholder": "Enter Path to the target parquet data in the selected bucket"
        },
    )
    path_procpq = StringField(
        "Proc Pq Path:",
        render_kw={
            "placeholder": "Enter Path to the processed parquet data in the selected bucket"
        },
    )


class BucketForm(FlaskForm):
    bucket_source_csv = SelectField("Source CSV:")
    bucket_raw_parquet = SelectField("Raw Parquet:")
    bucket_proc_parquet = SelectField("Processed:")

    # elastic_index = StringField('Elastic Search Index')
    submit = SubmitField("Get Details")


class PathSelForm(FlaskForm):
    source_csv_path = StringField("Source CSV Path")
    commit_name_aws = StringField("AWS Commit Name")
    testing_area = SelectField("Test Area", choices=["Payment"])

    payment_scope = SelectMultipleField(
        "Payment Scope", choices=TestConfig.SCOPE_PAYMENT_TYPE
    )

    bucket_source_csv = StringField("CSV Bucket")
    bucket_raw_parquet = StringField("Raw Parquet Bucket")
    bucket_proc_parquet = StringField("Processed Parquet Bucket")
    # raw_parquet = SelectField('Raw Parquet Path')
    # proc_parquet = SelectField('Processed Bucket Path')
    # elastic_index = StringField('Elastic Search Index')
    submit_job = SubmitField("Get Details")


class PathVerForm(FlaskForm):
    source_csv_fp = StringField("CSV Path")
    csv_file_list = SelectMultipleField("CSV File List")

    bucket_source_csv = StringField("CSV Bucket")
    bucket_raw_parquet = StringField("Raw Parquet Bucket")
    bucket_proc_parquet = StringField("Processed Parquet Bucket")

    csv_scope = BooleanField("Source CSV", default=True)
    raw_scope = BooleanField("Raw Parquet", default=True)
    proc_scope = BooleanField("Processed Parquet", default=True)
    es_scope = BooleanField("Elastic Search", default=True)

    raw_parquet_fp = StringField("Raw Parquet Path")
    proc_parquet_fp = StringField("Processed Bucket Path")
    elastic_index_index = StringField("Elastic Search Index")
    submit_job = SubmitField("Submit Job")

class ConfigForm(FlaskForm):
    config_type = SelectField("Select Config Type:")