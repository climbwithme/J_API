$currentDirectory = Get-Location
$job_id=$args[0]
$job_type=$args[1]
$module=$args[2]
$bypass=$args[3]

Write-Host "Current Directory: $currentDirectory"
Write-Host "Job ID: $job_id"
Write-Host "Module: $module"


$output_path = './app/static/py_reports/Internal/' + $job_id

$hive_pull_path = $output_path + '/1_hive_pull'
$hive_file_process_path = $output_path + '/2_hive_file_process'
$aws_file_pull_path = $output_path + '/3_aws_file_pull_path'
$pmt_count_path = $output_path + '/4_pmt_count_path'
$mandatory_path = $output_path + '/5_mandatory_path'
$comp_check_path = $output_path + '/6_comp_check_path'
$report_path = $output_path + '/extract_report_in_excel'

New-Item -ItemType Directory -Path $output_path -ErrorAction SilentlyContinue

$hive_pull = './tests/internal/test_1_hive_pull.py'
$hive_process = './tests/internal/test_2_pmt_hive_process.py'
$file_pull = './tests/internal/test_3_file_pull.py'
$pmt_count = './tests/internal/test_4_1_payment_count.py'
$mand_check = './tests/internal/test_5_mandatory.py'
$comp_check = './tests/internal/test_6_comparison.py'

.\venv\Scripts\Activate.ps1

$database = "./app/q_automation.db"
$start_sql = "UPDATE internal_job_ids SET status = 'STARTED' where id=$job_id;"

if ($bypass -ne "True") {
    pytest $hive_pull --alluredir="$output_path/reports" --job_id $job_id --job_type "$job_type" > "$hive_pull_path.txt"
}
sqlite3.exe $database $start_sql

if ($LASTEXITCODE -eq 0) {
    pytest $hive_process --alluredir="$output_path/reports" --job_id $job_id --job_type "$job_type" > "$hive_file_process_path.txt"
    pytest $file_pull --alluredir="$output_path/reports" --job_id $job_id --job_type "$job_type" > "$aws_file_pull_path.txt"
    if ($module -eq 'Payments') {
        pytest $pmt_count --alluredir="$output_path/reports" --job_id $job_id --job_type "$job_type" > "$pmt_count_path.txt"
    }
    pytest $mand_check --alluredir="$output_path/reports" --job_id $job_id --job_type "$job_type" > "$mandatory_path.txt"
    pytest $comp_check --alluredir="$output_path/reports" --job_id $job_id --job_type "$job_type" > "$comp_check_path.txt"
}

pytest .\tests\setup\test_write_summary.py --job_id $job_id --job_type "$job_type" > $report_path

$sql = "UPDATE internal_job_ids SET status = 'COMPLETED' where id=$job_id;"
sqlite3.exe $database $sql