from datetime import timedelta
import os

class Config(object):

    SECRET_KEY = os.environ.get('SECRET_KEY') or 'this-is-just - a back up for local dev'

    db_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'q_automation.db')
    print(db_path)

    SQLALCHEMY_DATABASE_URI = f'sqlite:///{db_path}'
    SQLALCHEMY_TRACK_MODIFICATIONS = False