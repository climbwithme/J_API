from collections import Counter
import os
import json
import pandas as pd

from app import app, db, metadata
from datetime import datetime
from itertools import chain
from app.forms import ConfigForm
from flask import render_template, request
from sqlalchemy import Table
from config_general import WorkFlowType

from config_test import TestConfig
from .models import IntJobIDS, ExtJobIDS, QuanJobIDS

from systems.reusables.oscommons import OsCommons



@app.route("/reports")
def reports():
    job_ids = QuanJobIDS.query.all()
    external_job_ids = ExtJobIDS.query.all()
    internal_job_ids = IntJobIDS.query.all()
    job_ids = job_ids[::-1]
    external_job_ids = external_job_ids[::-1]
    internal_job_ids = internal_job_ids[::-1]
    return render_template(
        "reports.html",
        title="Reports",
        reports=True,
        job_ids=job_ids,
        external_job_ids=external_job_ids,
        internal_job_ids=internal_job_ids,
    )


@app.route("/focussedreport/<folder_path>/<job_id>")
def focussedreport(folder_path, job_id):
    job_id = int(job_id)
    if folder_path == WorkFlowType.External.value:
        table_data = ExtJobIDS.query.filter(ExtJobIDS.id == job_id).one()
    elif folder_path == WorkFlowType.Internal.value:
        table_data = IntJobIDS.query.filter(IntJobIDS.id == job_id).one()
    else:
        table_data = QuanJobIDS.query.filter(QuanJobIDS.id == job_id).one()
    print(table_data.result_mandatory)

    result_comparison = json.dumps(table_data.result_comparison)
    result_fieldlength = json.dumps(table_data.result_fieldlength)
    result_mandatory = json.dumps(table_data.result_mandatory)

    return render_template('focussedreport.html', title='Reports', reports=True, result_mandatory=result_mandatory)


@app.route("/fullreport/<folder_path>/<job_id>")
def fullreport(folder_path, job_id):
    static_path = f"py_reports/{folder_path}/{job_id}/"
    parent_path = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        f'static\\{static_path}',
    )
    # parent_path = f'./py_reports/{job_id}'
    table_name = f'{folder_path}_job_ids'
    table = Table(table_name, metadata, autoload=True, autoload_with=db.engine)
    query = table.select().filter(table.columns.id == job_id)
    print(type(query))
    results = db.session.execute(query)
    rows = results.fetchall()
    results = [dict(zip([column for column in results.keys()], row)) for row in rows][0]
    print(parent_path)

    final_rep_path = f"{parent_path}final_report\\"
    if os.path.exists(final_rep_path):
        final_report_files = [
            f for f in os.listdir(final_rep_path)
            if f.endswith(".xlsx")
        ]
    else:
        final_report_files= []

    json_files = [
        os.path.join(f"{parent_path}reports\\", f)
        for f in os.listdir(f"{parent_path}reports\\")
        if f.endswith(".json")
    ]
    print(json_files)
    df_list = []
    for file in json_files:
        with open(file, "r") as f:
            data = json.load(f)
            data["filename"] = file.rsplit("\\", maxsplit=1)[1].split(".")[0]
            df = pd.json_normalize(data)
            # data = pd.read_json(f, convert_dates=['start', 'stop'])
            df_list.append(df)
    df = pd.concat(df_list, ignore_index=True)
    df.dropna(subset=["name"], inplace=True)
    df.sort_values("start", inplace=True)
    df["start"] = pd.to_datetime(df["start"] / 1000, unit="s").dt.strftime(
        "%d-%m-%Y %H:%M:%S"
    )
    df["stop"] = pd.to_datetime(df["stop"] / 1000, unit="s").dt.strftime(
        "%d-%m-%Y %H:%M:%S"
    )

    statuses = dict(Counter(chain.from_iterable([df.status.values.tolist()])))

    text_contents = OsCommons().get_logs(parent_path)

    return render_template(
        "fullreport.html",
        title="Full Report",
        reports=True,
        job_id=job_id,
        text_contents=text_contents,
        df=df,
        statuses=statuses,
        folder_path=folder_path,
        results=results,
        final_report_files=final_report_files,
        static_path=static_path
    )


def put_mainstatus_in_map(map_name, map_value):
    print(map_value.keys())
    map_value["error_msg"] = ''
    map_name["name"] = map_value["name"]
    map_name["description"] = map_value["description"]
    map_name["status"] = map_value["status"]
    if map_name["status"] != 'passed':
        print(map_name["status"])
        map_name["error_msg"] = map_value["statusDetails.message"]
        map_name["error_trace"] = map_value["statusDetails.trace"]
    map_name["start"] = datetime.fromtimestamp(map_value["start"] / 1000).strftime(
        "%d-%m-%Y %H:%M:%S"
    )
    map_name["stop"] = datetime.fromtimestamp(map_value["stop"] / 1000).strftime(
        "%d-%m-%Y %H:%M:%S"
    )
    if "steps" in map_value.keys():
        map_name["steps"] = map_value["steps"]
    else:
        map_name["steps"] = []
    map_name["attachments"] = {}
    # print(map_name)
    return map_name


def put_status_in_map(map_name, map_value):
    # print(map_name.keys())
    # print(map_value)
    map_name["name"] = map_value["name"]
    map_name["status"] = map_value["status"]
    map_name["start"] = datetime.fromtimestamp(map_value["start"] / 1000).strftime(
        "%d-%m-%Y %H:%M:%S"
    )
    map_name["stop"] = datetime.fromtimestamp(map_value["stop"] / 1000).strftime(
        "%d-%m-%Y %H:%M:%S"
    )
    if "steps" in map_value.keys():
        map_name["steps"] = map_value["steps"]
        # print(map_name.keys())
    else:
        map_name["steps"] = {}
    if "attachments" in map_value.keys():
        map_name["attachments"] = map_value["attachments"]
    else:
        map_name["attachments"] = {}
    # print(map_name)
    return map_name


def add_attachment_to_report(map_name, attachments, parent_path):
    try:
        print(attachments.keys())
        if "attachments" in attachments.keys():
            for attachment in attachments["attachments"]:
                att_name = attachment["name"]
                att_path = attachment["source"]
                print(att_name, att_path)
                map_name["attachments"] = OsCommons().get_logs_from_file(
                    parent_path, att_path, map_name["attachments"], att_name
                )
    except Exception as e:
        print("Error attaching the file", e)
    return map_name


@app.route("/test_result/<folder_path>/<job_id>/<json_name>")
def test_result(folder_path, job_id, json_name):
    parent_path = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        f"static\\py_reports\\{folder_path}\\{job_id}\\reports",
    )
    json_path = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        f"static\\py_reports\\{folder_path}\\{job_id}\\reports\\{json_name}.json",
    )
    main_result = {}
    print(f"PARENT PATH: {parent_path}")
    print(f"JSON PATH: {json_path}")
    with open(json_path, "r") as f:
        data = json.load(f)
        df = pd.json_normalize(data)
        try:
            steps_df = pd.json_normalize(data["steps"])
        except:
            steps_df = pd.DataFrame()

    # print(steps_df.columns)

    results = {}
    sub_result = {}

    # print(df.columns)

    for key, row in df.iterrows():
        main_result = put_mainstatus_in_map(main_result, row)
        results[key] = {}
        # results[key] = put_status_in_map(results[key], row)
        main_result = add_attachment_to_report(main_result, row, parent_path)
        sub_steps = {}
        if "steps" in row.keys():
            for skey, item in enumerate(row["steps"]):
                sub_steps = {}
                sub_steps = put_status_in_map(sub_steps, item)
                sub_steps = add_attachment_to_report(sub_steps, item, parent_path)
                results[skey] = sub_steps
                #             # print(results[skey])
                if "steps" in results[skey].keys():
                    sub_res_list = []
                    for sec_key, sec_item in enumerate(results[skey]["steps"]):
                        # for sec_su_item in sec_item["steps"]:
                        print(f"\t {sec_item}")
                        sec_steps = {}
                        sec_steps = put_status_in_map(sec_steps, sec_item)
                        print("SECONDARY STARTS", sec_item)
                        sec_steps = add_attachment_to_report(
                            sec_steps, sec_item, parent_path
                        )
                        sub_steps[sec_key] = sec_steps
                        sub_res_list.append(sec_steps)
                    sub_result[skey] = sub_res_list
                    # print(sub_steps[sec_key])
                    # for ter_key, ter_item in enumerate(results[skey]["steps"]):
                    # print(ter_key, ter_item)
        # print(results)

    print(job_id, folder_path)

    return render_template(
        "test_result.html",
        title="Test Result",
        reports=True,
        job_id=job_id,
        df=df,
        results=results,
        sub_result=sub_result,
        main_result=main_result,
        folder_path=folder_path,
    )


@app.route("/configs", methods=["GET", "POST"])
def configs():
    print(request.values)
    form = ConfigForm()
    my_map: dict = TestConfig.DB_TABLE_MAP
    form.config_type.choices = my_map.keys()
    if request.method == "POST":
        selected_value = request.values["config_type"]
    else:
        selected_value = list(my_map.keys())[0]
    table_name = my_map[selected_value]
    table = Table(table_name, metadata, autoload=True, autoload_with=db.engine)
    query = table.select()
    results = db.session.execute(query)

    return render_template(
        "configs.html",
        title="Configs",
        config_page=True,
        form=form,
        selected_value=selected_value,
        results=results,
        configs=True,
    )
