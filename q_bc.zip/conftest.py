import os

from config_rules import PaymentTypes

def pytest_addoption(parser):
    parser.addoption(
        "--job_id", action="store", default="local",
        help="job_id: For the UI Initiated scripts. Defaults to 'cmd' for indicating ran from command line"
    )
    parser.addoption(
        "--job_type", action="store", default="local",
        help="job_type: Workflow Type"
    )

def pytest_generate_tests(metafunc):
    # print(metafunc.fixturenames)
    if 'payment_type' in metafunc.fixturenames:
        payment_type = [
            PaymentTypes.PMTR, PaymentTypes.PMTN, 
            PaymentTypes.PMTQ, PaymentTypes.NADR, 
            PaymentTypes.NADN, PaymentTypes.NADQ
        ]
        metafunc.parametrize('payment_type', payment_type)
    if 'payment_type_pairs' in metafunc.fixturenames:
        payment_type_pairs = [
            (PaymentTypes.PMTR, PaymentTypes.NADR), 
            (PaymentTypes.PMTN, PaymentTypes.NADN), 
            (PaymentTypes.PMTQ, PaymentTypes.NADQ)
        ]
        metafunc.parametrize('payment_type_pairs', payment_type_pairs)
    if 'internal_target_csv' in metafunc.fixturenames:
        job_id = metafunc.config.getoption('job_id')
        print(job_id)
        file_names = os.listdir(f'files/Internal/{job_id}/target_csv/')
        metafunc.parametrize('internal_target_csv', file_names)
    if 'q_source_csv' in metafunc.fixturenames:
        job_id = metafunc.config.getoption('job_id')
        print(job_id)
        file_names = os.listdir(f'files/quantexa/{job_id}/source_csv/')
        metafunc.parametrize('q_source_csv', file_names)
    if 'proc_pq_file_name' in metafunc.fixturenames:
        job_id = metafunc.config.getoption('job_id')
        print(job_id)
        file_names = os.listdir(f'files/{job_id}/mapped_proc_pq_path/')
        metafunc.parametrize('proc_pq_file_name', file_names)
    if 'source_csv_in_pq' in metafunc.fixturenames:
        job_id = metafunc.config.getoption('job_id')
        print(job_id)
        file_names = os.listdir(f'files/quantexa/{job_id}/source_csv_in_pq/')
        metafunc.parametrize('source_csv_in_pq', file_names)
