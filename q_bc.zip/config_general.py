import os
from enum import Enum


class WorkFlowType(Enum):
    External = "External"
    Internal = "Internal"
    Quantexa = "Quantexa"


class GnConfig(object):
    # Store your LDAP Credentials in the Environment Variables - This is used for proxy authentication
    user = os.environ.get("MY_USER")
    password = os.environ.get("MY_PASS")

    proxies = {
        "http": f"http://{user}:{password}@userproxy.rbsgrp.net:8080",
        "https": f"http://{user}:{password}@userproxy.rbsgrp.net:8080",
    }

    # DB PATH
    DB_PATH_RULES = ".\\app\\q_automation.db"

    # File Download Paths
    report_path = "app\\static\\py_reports\\"
    download_file_paths = "files\\"
    converted_csv_file_path = "\\source_csv_in_pq\\"
    mapped_raw_pq_path = "\\mapped_raw_pq_path\\"
    mapped_proc_pq_path = "\\mapped_proc_pq_path\\"
    es_storage_path = "\\elastic_search_data\\"

    hive_storage_path = "\\hive\\"
    csv_storage_path = "\\source_csv\\"
    csv_target_storage_path = "\\target_csv\\"
    parquet_storage_path = "\\source_parquet\\"
    processed_pq_storage_path = "\\processed_parquet\\"
    elasticsearch_storage_path = "\\elastic_search_data\\"

    # Separators
    SEP_PAYMENT = "\\|~\\|"
    sep_wc = "\t"

    PQ_PARTITION_SIZE = "50MB"
