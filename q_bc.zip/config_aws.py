import os

class AWSConfig(object):

    # AWS CONFIGURATIONS
    region_name = 'eu-west-1'
    storage_type = 's3'

    # AWS ACCESS - Configured at the Site - 
    aws_access_key_id = os.environ.get("AWS_ACCESS_KEY")
    aws_secret_access_key = os.environ.get("AWS_SECRET_KEY")

    # SSL
    verify = False

    # SIT Buckets
    bucket_name = 'recp-entres-cb-rawdata-sit'
    archieve_bucket_name = 'recp-entres-cb-archive-sit'