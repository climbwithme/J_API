from config_aws import AWSConfig
from config_rules import ExternalFilterType
from rules.payments.field_sources import FIELD_SOURCES

import os

class TestConfig(object):

    ##################
    ### APPLICATIONS
    ##  
    # 
    # APPLICATIONS = ['Informatica BDM']
    # WORKFLOW = {'Informatica BDM': ['Internal', 'External']}
    APPLICATIONS_MODULE = {'Informatica BDM': {'Internal': ['Payments'], 'External': ['Country Risk']}, 'Quantexa CB': ['Payments']}
    EXTERNAL_TYPE = {'Country Risk': ExternalFilterType.MONTH}

    DB_TABLE_MAP = {
        'AWS Buckets': 'aws_bucket',
        'AWS Path Configs': 'aws_env_details',
        'Rules: Country Risk': 'rules_country_risk',
        'Rules: Payment - PMT': 'rules_payment_pmnt',
        'Rules: Payment - NAD': 'rules_payment_nad',
    }

    ##################
    ### AWS
    ##  
    # Bucket Mapping
    BUCKET_CSV = AWSConfig.archieve_bucket_name
    BUCKET_RAW_PQ = AWSConfig.bucket_name
    BUCKET_PROC_PQ = AWSConfig.bucket_name
    ## PREFIX
    # S3 File Container Path || No need to include the Bucket name - provide it from the next folder
    # PAYMENT
    PREFIX_CSV = 'Quantexa_CB/Rawdata/' 
    PREFIX_RAW_PQ = 'sitcycle2/aggregatedtransaction/24thcommit-v2/raw/parquet/'
    PREFIX_PROC_PQ = 'sitcycle2/aggregatedtransaction/24thcommit-v2/DocumentDataModel/FlatTransaction.parquet/'
    # WORLD CHECK
    wc_pq_bucket = AWSConfig.bucket_name
    wc_parquet_prefix = 'sitcycle2/worldcheckpep/20230129/raw/parquet/worldcheckpep.parquet/'

    wc_csv_bucket = AWSConfig.archieve_bucket_name
    wc_raw_csv_prefix= 'Quantexa_CB/Rawdata/2023-03-04/World_Check_PEP/'

    PREFIX_CSV = 'Quantexa_CB/Rawdata/2023-03-04/World_Check_PEP/'
    PREFIX_RAW_PQ = 'sitcycle2/worldcheckpep/20230129/raw/parquet/worldcheckpep.parquet/'
    ##################

    SRC_PATH = os.path.abspath(os.path.dirname(__file__))
    DB_PATH = './app/q_automation.db'
    ##################
    ### Elastic Search
    ##  
    ES_INDEX_NAME = '15thcommit-flat-transaction/_search'
    ##################

    ##################
    ### Primary Keys
    ## Payments
    PK_PAYMENT_PAYMN = 'PAYMN_NUMBER'
    PK_PAYMENT_TRANSID = 'TRANSACTION_ID'
    ##################

    ##################
    ### SCOPE
    ##  
    # Test Scope || PMTR or ...
    SCOPE_PAYMENT_TYPE = ['PMTR', 'PMTN']
    SCOPE_E2E_COMPARISON = [FIELD_SOURCES.CSV, FIELD_SOURCES.PROC_PARQUET]
    SCOPE_STANDALONE_CHECKS = [FIELD_SOURCES.CSV, FIELD_SOURCES.PROC_PARQUET]
    ##################

    ##################
    ### GUI Statics
    ##
    BUCKET_CHOICES = [(AWSConfig.bucket_name, AWSConfig.bucket_name), (AWSConfig.archieve_bucket_name, AWSConfig.archieve_bucket_name)]
