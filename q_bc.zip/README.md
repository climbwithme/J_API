# Quantexa Python Automation

## How To Set up this project

### Setting up Python

- Install Python 3.8 from Application Self Service
- Setup Path Variables for Python installation in Environment Variables
- Configure pip.ini file

### Create Virtual Environment
1. Clone the repository
2. Install Virtual Environment package if not present
3. Create a virtual environment in the project folder
```
python -m venv venv
```
4. Activate the virtual environment. Note: Activation is mandatory for every test run / report generation
```
.\venv\Scripts\Activate.ps1
```

### Installing the necessary package

Installing one package at a time:

```
python -m pip install --no-index --find-links=<Path_to_wheel_files> package_name
# package_name can be a comma separated multiple packages as well
```

Below are the list of packages used in this project. 
Note: Necessary dependencies will be automatically installed if the same is also present in the wheel files location folder specified above

```
** Packages & their use **
boto3           |   AWS Cloud connectivity
requests        |   Access Data from Elastic Search Instance via API
pandas          |   Data Analysis Library
dask            |   Memory management & parallel computing
pyarrow         |   Paquet File Dependency of Pandas
pytest          |   Test Framework
pytest-allure   |   Reporting
Black           |   Code Linter
```

## Understanding the configuration

## How To Run tests