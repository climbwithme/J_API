from enum import Enum


class ExternalFilterType(Enum):
    DATE = "DATE"
    MONTH = "MONTH"


class ExternalWF(Enum):
    COUNTRYRISK = "Country Risk"


class InternalWF(Enum):
    PAYMENTS = "Payments"


class TableJobs(Enum):
    EXTERNAL = "external_job_ids"
    INTERNAL = "internal_job_ids"
    QUANTEXA = "quantexa_job_ids"


class PaymentTypes(Enum):
    PMTR = "PMTR"
    PMTN = "PMTN"
    PMTQ = "PMTQ"
    NADR = "NADR"
    NADN = "NADN"
    NADQ = "NADQ"


class ExternalPaths(Enum):
    SOURCE = "source"
    TARGET = "target"


internal_path_hive = ["n_source", "Hive"]
internal_path_src = ["n_source", "source"]


class InternalPaths(Enum):
    HIVE_SRC = internal_path_hive
    SOURCE = internal_path_src


class TableGenColNames(Enum):
    LABEL = "name"
    BUCKET_SOURCE_CSV = "bucket_source_csv"
    BUCKET_TARGET_CSV = "bucket_target_csv"
    SOURCE_CSV = "source_csv"
    TARGET_CSV = "target_csv"
    MODULE = "module"

    TRANS_SRC = "src_transformation"
    TRANS_TAR = "transformation"

    ES_INDEX = "elastic_index"
    Q_BUCKET_SRC = "bucket_source"
    Q_BUCKET_TARGET = "bucket_target"
    Q_BUCKET_PROCPQ = "bucket_processed"
    Q_PROCPQ = "path_procpq"
    Q_FILE_LIST = "source_file_list"
    Q_RAWPQ = "path_rawpq"
    Q_PQ = "n_pq"
    Q_ES = "n_es_quan"
    Q_TPROCPQ = "n_proc_pq"
    Q_SRC_CSV = "n_source"

    VAL_MANDATORY = "validation_mandatory"
    VAL_COMPARISON = "validation_comparison"
    VAL_FIELDLENGTH = "validation_fieldlength"
    VAL_COUNT = "validation_count"
    VAL_ES = "validation_pro_quan"

    RES_MANDATORY = "result_mandatory"
    RES_COMPARISON = "result_comparison"
    RES_FIELDLENGTH = "result_fieldlength"
    RES_COUNT = "result_count"

    EX_TARGET = "n_target"
    EX_SOURCE = "n_source"

    IN_SOURCE = "n_source"
    IN_TARGET_CSV = "target_csv"
    IN_FIL_ST_DT = "filter_start_date"
    IN_FIL_ED_DT = "filter_end_date"


class ExternalRE(Enum):
    COUNTRYRISK = "rules_country_risk"


class InternalRE(Enum):
    PAYMENTS_PMT = "rules_payment_pmnt"
    PAYMENTS_NAD = "rules_payment_nad"


class ExternalFirstRowSrc(Enum):
    COUNTRYRISK = 1


class InternalFirstRowSrc(Enum):
    PAYMENTS = 0


class ExternalFirstRowTarget(Enum):
    COUNTRYRISK = 0


class InternalFirstRowTarget(Enum):
    PAYMENTS = 0


class ExternalColOVerrideSrc(Enum):
    COUNTRYRISK = True


class ExternalColOVerrideTarget(Enum):
    COUNTRYRISK = False


class PaymentFields(Enum):
    PAYMN_NUMBER = "PAYMN_NUMBER"
    IFPAY_ACCTING_TYPE = "IFPAY_ACCTING_TYPE"
    IFNAD_ACCTING_TYPE = "IFNAD_ACCTING_TYPE"
    IFPAY_PAYMN_REF = "IFPAY_PAYMN_REF"
    IFPAY_DIRECT_ID = "IFPAY_DIRECT_ID"
    IFPAY_CAPTURE_DATE = "IFPAY_CAPTURE_DATE"
    IFPAY_REG_CURR = "IFPAY_REG_CURR"
    IFPAY_ORG_CURR = "IFPAY_ORG_CURR"
    IFPAY_ORG_AMOUNT = "IFPAY_ORG_AMOUNT"
    IFPAY_DEB_ACCOUNT = "IFPAY_DEB_ACCOUNT"
    IFPAY_CRE_ACCOUNT = "IFPAY_CRE_ACCOUNT"
    IFPAY_REF_TRAN_DEB = "IFPAY_REF_TRAN_DEB"
    IFPAY_REF_TRAN_CRE = "IFPAY_REF_TRAN_CRE"
    IFPAY_BEN_ACCOUNT = "IFPAY_BEN_ACCOUNT"
    IFPAY_PAYMN_DETAIL = "IFPAY_PAYMN_DETAIL"
    IFPAY_SEN_CNTRY = "IFPAY_SEN_CNTRY"
    IFPAY_REC_CNTRY = "IFPAY_REC_CNTRY"
    IFPAY_EXEC_DATE = "IFPAY_EXEC_DATE"
    IFPAY_PAYM_CURR = "IFPAY_PAYM_CURR"
    IFPAY_PAYM_AMNT = "IFPAY_PAYM_AMNT"
    IFPAY_OCU_ACCOUNT = "IFPAY_OCU_ACCOUNT"
    IFPAY_MT202COV_TAG21 = "IFPAY_MT202COV_TAG21"
    SRC_SYS_ID = "SRC_SYS_ID"
    SERVICING_FIN_INSTN = "SERVICING_FIN_INSTN"
    IFNAD_AWI_BIC = "IFNAD_AWI_BIC"
    IFNAD_AWI_ADDR = "IFNAD_AWI_ADDR"
    IFNAD_AWI_CITY = "IFNAD_AWI_CITY"
    IFNAD_AWI_CNTRY = "IFNAD_AWI_CNTRY"
    IFNAD_AWI_NAT = "IFNAD_AWI_NAT"
    IFNAD_CRE_NAME = "IFNAD_CRE_NAME"
    IFNAD_CRE_CUST_ID = "IFNAD_CRE_CUST_ID"
    IFNAD_IIN_NAME = "IFNAD_IIN_NAME"
    IFNAD_SCO_NATP = "IFNAD_SCO_NATP"
    TRANSACTION_ID = "TRANSACTION_ID"
    IFPAY_REG_AMOUNT = "IFPAY_REG_AMOUNT"
    IFNAD_DEB_CITY = "IFNAD_DEB_CITY"
    IFNAD_RCO_BIC = "IFNAD_RCO_BIC"
    IFNAD_RCO_CNTRY = "IFNAD_RCO_CNTRY"
    IFNAD_IIN_BIC = "IFNAD_IIN_BIC"
    IFNAD_IIN_CNTRY = "IFNAD_IIN_CNTRY"
    IFNAD_TRI_BIC = "IFNAD_TRI_BIC"
    IFNAD_TRI_CNTRY = "IFNAD_TRI_CNTRY"
    IFNAD_SEN_CNTRY = "IFNAD_SEN_CNTRY"
    IFNAD_SEN_BIC = "IFNAD_SEN_BIC"
    IFNAD_CRE_BIC = "IFNAD_CRE_BIC"
    IFNAD_CRE_CNTRY = "IFNAD_CRE_CNTRY"
    IFNAD_DIN_BIC = "IFNAD_DIN_BIC"
    IFNAD_DIN_CNTRY = "IFNAD_DIN_CNTRY"
    IFNAD_BFT_BIC = "IFNAD_BFT_BIC"
    IFNAD_BFT_CNTRY = "IFNAD_BFT_CNTRY"
    IFNAD_BCU_BIC = "IFNAD_BCU_BIC"
    IFNAD_BCU_NAME = "IFNAD_BCU_NAME"
    IFNAD_OCU_NAME = "IFNAD_OCU_NAME"
    IFNAD_DEB_BIC = "IFNAD_DEB_BIC"
    IFNAD_DEB_CNTRY = "IFNAD_DEB_CNTRY"
    IFNAD_DEB_NAME = "IFNAD_DEB_NAME"
    IFNAD_OIN_BIC = "IFNAD_OIN_BIC"
    IFNAD_OIN_CNTRY = "IFNAD_OIN_CNTRY"
    IFNAD_SCO_BIC = "IFNAD_SCO_BIC"
    IFNAD_SCO_CNTRY = "IFNAD_SCO_CNTRY"


class PaymentMapping:
    NWB_LIST_ISO = ["NatWest Bank PLC"]
    RBS_LIST_ISO = ["Royal Bank of Scotland PLC"]
    UB_LIST_ISO = ["Ulster Bank Republic of Ireland", "Ulster Bank Northern Ireland"]

    NWB_LIST_NONISO = ["NWB"]
    RBS_LIST_NONISO = ["RBS"]
    UB_LIST_NONISO = ["UBR", "UBN"]

    pdl_ppy_fund_transfer_evnt_v = "b"
    pdl_fund_transfer_evnt_v = "a"

    MAPPING_DICT_ISO_PMT = {
        "evnt_hkey": PaymentFields.PAYMN_NUMBER.value,
        "pmnt_sts": PaymentFields.IFPAY_ACCTING_TYPE.value,
        "uetr": PaymentFields.IFPAY_PAYMN_REF.value,
        "dirctn": PaymentFields.IFPAY_DIRECT_ID.value,
        "intrbnk_stlmnt_dt": [PaymentFields.IFPAY_CAPTURE_DATE.value, PaymentFields.IFPAY_EXEC_DATE.value],
        "instrctd_ccy_cd": [PaymentFields.IFPAY_REG_CURR.value, PaymentFields.IFPAY_ORG_CURR.value],
        "servicing_fin_instn": PaymentFields.SERVICING_FIN_INSTN.value,
        "instrctd_amt": [PaymentFields.IFPAY_REG_AMOUNT.value, PaymentFields.IFPAY_ORG_AMOUNT.value],
        "ifpay_cre_acct": PaymentFields.IFPAY_CRE_ACCOUNT.value,
        "msg_idnt": PaymentFields.IFPAY_REF_TRAN_DEB.value,
        "outgng_msg_idnt": PaymentFields.IFPAY_REF_TRAN_CRE.value,
        "ifpay_ben_acct": PaymentFields.IFPAY_BEN_ACCOUNT.value,
        "ifpay_paymn_detail": PaymentFields.IFPAY_PAYMN_DETAIL.value,
        "ifpay_sen_cntry": PaymentFields.IFPAY_SEN_CNTRY.value,
        "ifpay_rec_cntry": PaymentFields.IFPAY_REC_CNTRY.value,
        "intrbnk_stlmnt_ccy_cd": PaymentFields.IFPAY_PAYM_CURR.value,
        "intrbnk_stlmnt_amt": PaymentFields.IFPAY_PAYM_AMNT.value,
        "ifpay_ocu_acct": PaymentFields.IFPAY_OCU_ACCOUNT.value,
        "txn_idnt": PaymentFields.IFPAY_MT202COV_TAG21.value,
    }

    MAPPING_DICT_ISO_NAD = {
        "evnt_hkey": PaymentFields.PAYMN_NUMBER.value,
        "pmnt_sts": PaymentFields.IFNAD_ACCTING_TYPE.value,
        "ifnad_awi_bic": PaymentFields.IFNAD_AWI_BIC.value,
        "ifnad_awi_addr": PaymentFields.IFNAD_AWI_ADDR.value,
        "ifnad_awi_city": PaymentFields.IFNAD_AWI_CITY.value,
        "ifnad_awi_cntry": PaymentFields.IFNAD_AWI_CNTRY.value,
        "ifnad_awi_nat": PaymentFields.IFNAD_AWI_NAT.value,
        "servicing_fin_instn": PaymentFields.SERVICING_FIN_INSTN.value,
        "ifnad_deb_city": PaymentFields.IFNAD_DEB_CITY.value,
        "ifnad_rco_bic": PaymentFields.IFNAD_RCO_BIC.value,
        "ifnad_rco_cntry": PaymentFields.IFNAD_RCO_CNTRY.value,
        "ifnad_iin_bic": PaymentFields.IFNAD_IIN_BIC.value,
        "ifnad_iin_cntry": PaymentFields.IFNAD_IIN_CNTRY.value,
        "ifnad_tri_bic": PaymentFields.IFNAD_TRI_BIC.value,
        "ifnad_tri_cntry": PaymentFields.IFNAD_TRI_CNTRY.value,
        "ifnad_sen_cntry": PaymentFields.IFNAD_SEN_CNTRY.value,
        "ifnad_sen_bic": PaymentFields.IFNAD_SEN_BIC.value,
        "ifnad_cre_bic": PaymentFields.IFNAD_CRE_BIC.value,
        "ifnad_cre_cntry": PaymentFields.IFNAD_CRE_CNTRY.value,
        "ifnad_din_bic": PaymentFields.IFNAD_DIN_BIC.value,
        "ifnad_din_cntry": PaymentFields.IFNAD_DIN_CNTRY.value,
        "ifnad_bft_bic": PaymentFields.IFNAD_BFT_BIC.value,
        "ifnad_bft_cntry": PaymentFields.IFNAD_BFT_CNTRY.value,
        "ifnad_bcu_bic": PaymentFields.IFNAD_BCU_BIC.value,
        "ifnad_bcu_nm": PaymentFields.IFNAD_BCU_NAME.value,
        "ifnad_ocu_nm": PaymentFields.IFNAD_OCU_NAME.value,
        "ifnad_deb_bic": PaymentFields.IFNAD_DEB_BIC.value,
        "ifnad_deb_cntry": PaymentFields.IFNAD_DEB_CNTRY.value,
        "ifnad_deb_nm": PaymentFields.IFNAD_DEB_NAME.value,
        "ifnad_oin_bic": PaymentFields.IFNAD_OIN_BIC.value,
        "ifnad_oin_cntry": PaymentFields.IFNAD_OIN_CNTRY.value,
        "ifnad_sco_bic": PaymentFields.IFNAD_SCO_BIC.value,
        "ifnad_sco_cntry": PaymentFields.IFNAD_SCO_CNTRY.value,
    }

    NON_ISO_MAPPING_DICT = {
        f"{pdl_ppy_fund_transfer_evnt_v}.paymn_number": PaymentFields.PAYMN_NUMBER.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_accting_type": PaymentFields.IFPAY_ACCTING_TYPE.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_paymn_ref": PaymentFields.IFPAY_PAYMN_REF.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_direct_id": PaymentFields.IFPAY_DIRECT_ID.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_capture_dt": PaymentFields.IFPAY_CAPTURE_DATE.value,
        f"{pdl_fund_transfer_evnt_v}.fin_evnt_cury_cd": PaymentFields.IFPAY_REG_CURR.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.src_sys_inst_id": PaymentFields.SERVICING_FIN_INSTN.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_accting_typ": PaymentFields.IFNAD_ACCTING_TYPE.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_awi_addr": PaymentFields.IFNAD_AWI_ADDR.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_cre_nm": PaymentFields.IFNAD_CRE_NAME.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_cre_cust_id": PaymentFields.IFNAD_CRE_CUST_ID.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_iin_nm": PaymentFields.IFNAD_IIN_NAME.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_sco_natp": PaymentFields.IFNAD_SCO_NATP.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_awi_bic": PaymentFields.IFNAD_AWI_BIC.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_awi_addr": PaymentFields.IFNAD_AWI_ADDR.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_awi_city": PaymentFields.IFNAD_AWI_CITY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_awi_cntry": PaymentFields.IFNAD_AWI_CNTRY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_awi_nat": PaymentFields.IFNAD_AWI_NAT.value,
        f"{pdl_fund_transfer_evnt_v}.fin_evnt_amt": PaymentFields.IFPAY_REG_AMOUNT.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_deb_city": PaymentFields.IFNAD_DEB_CITY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_rco_bic": PaymentFields.IFNAD_RCO_BIC.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_rco_cntry": PaymentFields.IFNAD_RCO_CNTRY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_iin_bic": PaymentFields.IFNAD_IIN_BIC.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_iin_cntry": PaymentFields.IFNAD_IIN_CNTRY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_tri_bic": PaymentFields.IFNAD_TRI_BIC.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_tri_cntry": PaymentFields.IFNAD_TRI_CNTRY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_sen_cntry": PaymentFields.IFNAD_SEN_CNTRY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_sen_bic": PaymentFields.IFNAD_SEN_BIC.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_cre_bic": PaymentFields.IFNAD_CRE_BIC.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_cre_cntry": PaymentFields.IFNAD_CRE_CNTRY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_din_bic": PaymentFields.IFNAD_DIN_BIC.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_din_cntry": PaymentFields.IFNAD_DIN_CNTRY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_bft_bic": PaymentFields.IFNAD_BFT_BIC.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_bft_cntry": PaymentFields.IFNAD_BFT_CNTRY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_bcu_bic": PaymentFields.IFNAD_BCU_BIC.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_bcu_nm": PaymentFields.IFNAD_BCU_NAME.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_ocu_nm": PaymentFields.IFNAD_OCU_NAME.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_deb_bic": PaymentFields.IFNAD_DEB_BIC.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_deb_cntry": PaymentFields.IFNAD_DEB_CNTRY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_deb_nm": PaymentFields.IFNAD_DEB_NAME.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_oin_bic": PaymentFields.IFNAD_OIN_BIC.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_oin_cntry": PaymentFields.IFNAD_OIN_CNTRY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_sco_bic": PaymentFields.IFNAD_SCO_BIC.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifnad_sco_cntry": PaymentFields.IFNAD_SCO_CNTRY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_org_curr": PaymentFields.IFPAY_ORG_CURR.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_org_amt": PaymentFields.IFPAY_ORG_AMOUNT.value,
        f"{pdl_fund_transfer_evnt_v}.fnd_xfer_cr_acct_num": PaymentFields.IFPAY_CRE_ACCOUNT.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_ref_tran_deb": PaymentFields.IFPAY_REF_TRAN_DEB.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_ref_tran_cre": PaymentFields.IFPAY_REF_TRAN_CRE.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_ben_acct": PaymentFields.IFPAY_BEN_ACCOUNT.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_paymn_detail": PaymentFields.IFPAY_PAYMN_DETAIL.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_sen_cntry": PaymentFields.IFPAY_SEN_CNTRY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_rec_cntry": PaymentFields.IFPAY_REC_CNTRY.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_exec_date": PaymentFields.IFPAY_EXEC_DATE.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_paym_curr": PaymentFields.IFPAY_PAYM_CURR.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_paym_amnt": PaymentFields.IFPAY_PAYM_AMNT.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_ocu_acct": PaymentFields.IFPAY_OCU_ACCOUNT.value,
        f"{pdl_ppy_fund_transfer_evnt_v}.ifpay_mt202cov_tag21": PaymentFields.IFPAY_MT202COV_TAG21.value,
    }

    FIELD_LIST_PMT = [
        PaymentFields.PAYMN_NUMBER.value,
        PaymentFields.IFPAY_ACCTING_TYPE.value,
        PaymentFields.IFPAY_PAYMN_REF.value,
        PaymentFields.IFPAY_DIRECT_ID.value,
        PaymentFields.IFPAY_CAPTURE_DATE.value,
        PaymentFields.IFPAY_REG_CURR.value,
        PaymentFields.SERVICING_FIN_INSTN.value,
        PaymentFields.IFPAY_REG_AMOUNT.value,
        PaymentFields.IFPAY_ORG_CURR.value,
        PaymentFields.IFPAY_ORG_AMOUNT.value,
        PaymentFields.IFPAY_CRE_ACCOUNT.value,
        PaymentFields.IFPAY_REF_TRAN_DEB.value,
        PaymentFields.IFPAY_REF_TRAN_CRE.value,
        PaymentFields.IFPAY_BEN_ACCOUNT.value,
        PaymentFields.IFPAY_PAYMN_DETAIL.value,
        PaymentFields.IFPAY_SEN_CNTRY.value,
        PaymentFields.IFPAY_REC_CNTRY.value,
        PaymentFields.IFPAY_EXEC_DATE.value,
        PaymentFields.IFPAY_PAYM_CURR.value,
        PaymentFields.IFPAY_PAYM_AMNT.value,
        PaymentFields.IFPAY_OCU_ACCOUNT.value,
        PaymentFields.IFPAY_MT202COV_TAG21.value,
    ]

    FIELD_LIST_NAD = [
        PaymentFields.PAYMN_NUMBER.value,
        PaymentFields.IFNAD_ACCTING_TYPE.value,
        PaymentFields.IFNAD_AWI_BIC.value,
        PaymentFields.IFNAD_AWI_ADDR.value,
        PaymentFields.IFNAD_AWI_CITY.value,
        PaymentFields.IFNAD_AWI_CNTRY.value,
        PaymentFields.IFNAD_AWI_NAT.value,
        PaymentFields.IFNAD_DEB_CITY.value,
        PaymentFields.IFNAD_RCO_BIC.value,
        PaymentFields.IFNAD_RCO_CNTRY.value,
        PaymentFields.IFNAD_IIN_BIC.value,
        PaymentFields.IFNAD_IIN_CNTRY.value,
        PaymentFields.IFNAD_TRI_BIC.value,
        PaymentFields.IFNAD_TRI_CNTRY.value,
        PaymentFields.IFNAD_SEN_CNTRY.value,
        PaymentFields.IFNAD_SEN_BIC.value,
        PaymentFields.IFNAD_CRE_BIC.value,
        PaymentFields.IFNAD_CRE_CNTRY.value,
        PaymentFields.IFNAD_DIN_BIC.value,
        PaymentFields.IFNAD_DIN_CNTRY.value,
        PaymentFields.IFNAD_BFT_BIC.value,
        PaymentFields.IFNAD_BFT_CNTRY.value,
        PaymentFields.IFNAD_BCU_BIC.value,
        PaymentFields.IFNAD_BCU_NAME.value,
        PaymentFields.IFNAD_OCU_NAME.value,
        PaymentFields.IFNAD_DEB_BIC.value,
        PaymentFields.IFNAD_DEB_CNTRY.value,
        PaymentFields.IFNAD_DEB_NAME.value,
        PaymentFields.IFNAD_OIN_BIC.value,
        PaymentFields.IFNAD_OIN_CNTRY.value,
        PaymentFields.IFNAD_SCO_BIC.value,
        PaymentFields.IFNAD_SCO_CNTRY.value,
    ]
