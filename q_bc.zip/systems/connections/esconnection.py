import requests
import json
import allure
import urllib3

from config_elastic import ESConfig
from config_general import GnConfig
from config_test import TestConfig

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class EsConnection:

    def __init__(self, index_name, env) -> None:
        self.env = env
        if self.env == "SIT":
            self.payment_endpoint = f'{ESConfig.endpoint_sit}path={index_name}/_search&method=GET'
        elif self.env == "NFT":
            self.payment_endpoint = f'{ESConfig.endpoint_nft}path={index_name}/_search&method=GET'
        print(self.payment_endpoint)
    
    def setPaymentPayload(self, list_of_values=[]):
        # print({"query": {"terms": {"TRANSACTION_ID.keyword": list_of_values}}, "track_total_hits": True})
        # print(json.dumps({"query": {"terms": {"TRANSACTION_ID.keyword": list_of_values}}, "track_total_hits": True}))
        self.payload_transaction_ids = list_of_values
        # self.payload = json.dumps({"query": {"terms": {"TRANSACTION_ID.keyword": list_of_values}}, "track_total_hits": True})
    
    def post_payment_request(self, path_value, file_name='', write_file=True):
        password = ESConfig.es_password if self.env == 'SIT' else ESConfig.es_password_nft
        with allure.step("Making the API Call"):
            chunk_size = 10000
            counter = 1
            total_identified_records = 0
            chunks = [self.payload_transaction_ids[i:i+chunk_size] for i in range(0, len(self.payload_transaction_ids), chunk_size)]
            json_data = []
            for chunk in chunks:
                print(f"Chunk Length - {len(chunk)}")
                payload_local = json.dumps({"query": {"terms": {"TRANSACTION_ID.keyword": chunk}}, "size": chunk_size})
                response = requests.request(
                    "POST",
                    self.payment_endpoint,
                    headers=ESConfig.headers,
                    data=payload_local,
                    auth=(ESConfig.es_user, password),
                    verify=False
                    )
                if response.status_code == 200:
                    response_json = response.json()
                    data = response_json["hits"]["hits"]
                    json_data.extend(data)
                    counter+=chunk_size
                    total_records = response_json["hits"]["total"]["value"]
                    total_identified_records += response_json["hits"]["total"]["value"]
                else:
                    print(f"Response Failed with error code {response.status_code}")
            if write_file:
                with open(f'{path_value}/response_{file_name}.json', 'w') as outfile:
                    json.dump(json_data, outfile)
        print(f'Total Found records - {total_identified_records}')