import boto3
import urllib3

from config_aws import AWSConfig
from config_general import GnConfig
from botocore.config import Config
from boto3.s3.transfer import TransferConfig

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class AwsConnection:
    def __init__(self) -> None:
        self.aws_config = Config(region_name=AWSConfig.region_name, proxies=GnConfig.proxies)
        self.boto_client = None

    def createClient(self) -> None:
        print("Creating a Client with credentials of AWS")
        self.boto_client = boto3.client(
            AWSConfig.storage_type,
            aws_access_key_id=AWSConfig.aws_access_key_id,
            aws_secret_access_key=AWSConfig.aws_secret_access_key,
            config=self.aws_config,
            verify=AWSConfig.verify,
        )
    

    def setTransferConfig(self) -> None:
        self.transfer_config = TransferConfig(
            multipart_threshold=500*(1024 ** 3), 
            max_io_queue=500, 
            max_concurrency=10
        )
