from systems.reusables.sqlcommons import SqlCommons
from config_rules import (
    ExternalRE,
    ExternalFirstRowSrc,
    ExternalFirstRowTarget,
    ExternalColOVerrideSrc,
    ExternalColOVerrideTarget,
    ExternalWF,
    InternalFirstRowSrc,
    InternalFirstRowTarget,
    InternalRE,
    InternalWF,
    TableGenColNames,
)
from enum import Enum


class Rules(Enum):
    Mandatory = "mandatory == 1"
    Availability = "availability == 1"
    COMPARE = "comparison == 1"
    FIELDLENGTH = "field_length > 0"
    SRC_TRANSFORMATION = "src_transformation"


def rule_combiner(list_of_rules):
    if len(list_of_rules) > 0:
        return f'where {" and ".join(list_of_rules)}'
    else:
        return ""


def override_cols(df, tablename):
    sql = SqlCommons(tablename)
    results = sql.getColumnValues(TableGenColNames.LABEL.value)
    col_names = [result[0] for result in results]
    df = df[0 : len(col_names)]
    df.columns = col_names
    return df


class RuleCommons:
    def get_db_name_external(module):
        if module == "Country Risk":
            return ExternalRE.COUNTRYRISK.value

    def get_db_name_quantexa(file_name):
        if "_PMT" in file_name:
            return InternalRE.PAYMENTS_PMT.value
        else:
            return InternalRE.PAYMENTS_NAD.value

    def get_db_name_internal(module):
        if module == "Payments":
            return InternalRE.PAYMENTS_PMT.value

    def get_skiprow_external_src(module):
        if module == "Country Risk":
            return ExternalFirstRowSrc.COUNTRYRISK.value

    def get_skiprow_external_target(module):
        if module == "Country Risk":
            return ExternalFirstRowTarget.COUNTRYRISK.value

    def get_skiprow_internal_src(module):
        if module == InternalWF.PAYMENTS.value:
            return InternalFirstRowSrc.PAYMENTS.value

    def get_skiprow_internal_target(module):
        if module == InternalWF.PAYMENTS.value:
            return InternalFirstRowTarget.PAYMENTS.value

    def get_skiprow_internal_src(module):
        if module == "Payments":
            return InternalFirstRowSrc.PAYMENTS.value

    def get_skiprow_internal_target(module):
        if module == "Payments":
            return InternalFirstRowTarget.PAYMENTS.value

    def get_srctransformations_of_field(col_name, tablename, trans_col="src_transformation"):
        sql = SqlCommons(tablename)
        results = sql.getColumnValues(
            trans_col, f"where name = '{col_name}'"
        )
        return results[0][0]

    def test_mandatory_fields(col_name, tablename):
        sql = SqlCommons(tablename)
        results = sql.getColumnValues(
            col_name, rule_combiner([Rules.Mandatory.value, Rules.Availability.value])
        )
        return [result[0] for result in results]

    def test_field_length(col_name, tablename):
        sql = SqlCommons(tablename)
        results = sql.getColumnValues(
            col_name, rule_combiner([Rules.FIELDLENGTH.value])
        )
        return [result[0] for result in results]

    def get_override_info_src(module):
        if module == ExternalWF.COUNTRYRISK.value:
            return ExternalColOVerrideSrc.COUNTRYRISK.value

    def get_override_info_target(module):
        if module == ExternalWF.COUNTRYRISK.value:
            return ExternalColOVerrideTarget.COUNTRYRISK.value

    def get_comparison_fields(col_name, tablename) -> list:
        sql = SqlCommons(tablename)
        results = sql.getColumnValues(
            f"id, {col_name}",
            rule_combiner([Rules.COMPARE.value, Rules.Availability.value]),
        )
        return [
            int(result[0]) - 1 if result[1].startswith("~") else result[1]
            for result in results
        ]

    def get_column_names_native(tablename):
        sql = SqlCommons(tablename)
        results = sql.getColumnValues(TableGenColNames.LABEL.value, rule_combiner([]))
        return [result[0] for result in results]

    def get_column_names_target(tablename):
        sql = SqlCommons(tablename)
        results = sql.getColumnValues(TableGenColNames.LABEL.value, rule_combiner([Rules.Availability.value]))
        return [result[0] for result in results]

    def get_comparison_fields_native(tablename):
        sql = SqlCommons(tablename)
        results = sql.getColumnValues(
            TableGenColNames.LABEL.value, rule_combiner([Rules.COMPARE.value, Rules.Availability.value])
        )
        return [result[0] for result in results]

    def check_colname_override_src(module, df, tablename):
        print("Overriding")
        sql = SqlCommons(tablename)
        results = sql.getColumnValues(TableGenColNames.LABEL.value)
        col_names = [result[0] for result in results]
        print(col_names)
        df = df.iloc[:, 0 : len(col_names)]
        df.columns = col_names
        print(df.head(1))
        return df

    def check_colname_override_target(module, df, tablename):
        if module == "Country Risk":
            override = ExternalColOVerrideTarget.COUNTRYRISK.value

        if override == True:
            return override_cols(df, tablename)
