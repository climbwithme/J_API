import sqlite3

from config_test import TestConfig
from enum import Enum


class BUCKET_SRC(Enum):
    CSV = "bucket_source_csv"
    RAW_PARQUET = "bucket_raw_parquet"
    PROC_PARQUET = "bucket_proc_parquet"


class SqlCommons:
    def __init__(self):
        self.conn = sqlite3.connect(TestConfig.DB_PATH)
        self.cursor = self.conn.cursor()

    def __init__(self, table_name):
        self.conn = sqlite3.connect(TestConfig.DB_PATH)
        self.cursor = self.conn.cursor()
        self.table = table_name

    def getBucketSrc(self, bucket_src: BUCKET_SRC):
        if bucket_src == BUCKET_SRC.CSV:
            return BUCKET_SRC.CSV.value
        elif bucket_src == BUCKET_SRC.RAW_PARQUET:
            return BUCKET_SRC.RAW_PARQUET.value
        else:
            return BUCKET_SRC.PROC_PARQUET.value

    def connClose(self):
        self.cursor.close()
        self.conn.close()
    
    def getColumnValue(self, job_id, colname):

        self.cursor.execute(f"select {colname} from {self.table} where id = {job_id}")
        results = self.cursor.fetchall()
        return results[0][0]
    
    def setColumnValue(self, value, colname, job_id):
        self.cursor.execute(f"UPDATE {self.table} set {colname} = '{value}' where id = {job_id}")
        self.conn.commit()
    
    def getPrimaryKey(self, table_name):
        self.cursor.execute(f"select name from {table_name} where primary_key=True")
        results = self.cursor.fetchall()
        return results[0][0]
    
    def getColumnValues(self, colname, rule=''):
        self.cursor.execute(f"select {colname} from {self.table} {rule}")
        results = self.cursor.fetchall()
        return results

    # def getcsvList(self, job_id):
    #     self.cursor.execute(f"select csv_file_list from job_ids where id = {job_id}")
    #     results = self.cursor.fetchall()
    #     return results[0][0]

    # def getESIndexName(self, job_id):
    #     self.cursor.execute(f"select es_index from job_ids where id = {job_id}")
    #     results = self.cursor.fetchall()
    #     return results[0][0]

    # def getScopeCSV(self, job_id):
    #     self.cursor.execute(f"select csv_scope from job_ids where id = {job_id}")
    #     results = self.cursor.fetchall()
    #     return results[0][0]

    # def getrawPQPath(self, job_id):
    #     self.cursor.execute(f"select raw_parquet_fp from job_ids where id = {job_id}")
    #     results = self.cursor.fetchall()
    #     return results[0][0]

    # def getprocPQPath(self, job_id):
    #     self.cursor.execute(f"select proc_parquet_fp from job_ids where id = {job_id}")
    #     results = self.cursor.fetchall()
    #     return results[0][0]

    # def getBucket(self, job_id, bucket_src: BUCKET_SRC):
    #     self.cursor.execute(
    #         f"select {self.getBucketSrc(bucket_src)} from job_ids where id = {job_id}"
    #     )
    #     results = self.cursor.fetchall()
    #     return results[0][0]
