import allure
import logging


class SoftError:
    def __init__(self) -> None:
        self.error_list = []
        self.pass_list = []
        self.info_list = []

    def add_to_error(self, message):
        self.error_list.extend([f"Failed: {message}"])

    def add_to_passlist(self, message):
        self.pass_list.extend([f"{message}"])
    
    def add_to_infolist(self, message):
        self.info_list.append(f'INFO: {message}')

    def log_all_error_to_report(self):
        with allure.step(f"Soft Error Validations:"):
            print('Information:(if any)')
            for info_msg in self.info_list:
                with allure.step(f"{info_msg}"):
                    print(f'\t{info_msg}')
                    logging.info(info_msg)
            print('Pass Messages:(if any)')
            for pass_msg in self.pass_list:
                with allure.step(f"{pass_msg}"):
                    print(f'\t{pass_msg}')
            print('Error Messages:(if any)')
            for error in self.error_list:
                with allure.step(f"{error}"):
                    logging.error(error)
                    print(f'\t{error}')
            if len(self.error_list) > 0:
                raise Exception(";\n".join(self.error_list))
