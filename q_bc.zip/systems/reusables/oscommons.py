import glob
import os
import json

from config_general import GnConfig, WorkFlowType


class OsCommons:
    def create_path(self, path):
        try:
            os.makedirs(path)
        except:
            pass

    def delete_and_create_path(self, path):
        try:
            os.removedirs(path)
        except:
            pass
        self.create_path(path)

    def getQuantexaPaths(self, job_id, sub_path, create=False):
        path = f"{GnConfig.download_file_paths}{WorkFlowType.Quantexa.value}\\{job_id}\\{sub_path}"
        if create:
            self.create_path(path)
            print(f"Path Created - {path}")
        return path

    def getQuantexaProcPQPath(self, job_id, create=False):
        path = f"{GnConfig.download_file_paths}{WorkFlowType.Quantexa.value}\\{job_id}\\{GnConfig.processed_pq_storage_path}"
        if create:
            self.create_path(path)
            print(f"Path Created - {path}")
        return path

    def getsourceCSVPath(self, workflowtype: WorkFlowType, job_id, create=False):
        path = f"{GnConfig.download_file_paths}{workflowtype.value}\\{job_id}\\{GnConfig.csv_storage_path}"
        if create:
            self.create_path(path)
            print(f"Path Created - {path}")
        return path

    def gettargetCSVPath(self, workflowtype: WorkFlowType, job_id, create=False):
        source_folder = (
            WorkFlowType.External.value
            if workflowtype == WorkFlowType.External
            else WorkFlowType.Internal.value
        )
        path = f"{GnConfig.download_file_paths}{source_folder}\\{job_id}{GnConfig.csv_target_storage_path}"
        if create:
            self.create_path(path)
            print(f"Path Created - {path}")
        return path

    def gettargetHivePath(self, workflowtype: WorkFlowType, job_id):
        path = f"{GnConfig.download_file_paths}{workflowtype.value}\\{job_id}\\{GnConfig.hive_storage_path}"
        return path

    def get_logs(self, parent_path):
        text_files = glob.glob(parent_path + "/*.txt")
        csv_files = glob.glob(parent_path + "/*.csv")
        text_contents = {}

        print(text_files)

        for file_path in text_files:
            fname = file_path.rsplit("\\", maxsplit=1)[1].split(".")[0]
            with open(file_path, "r") as f:
                try:
                    file_contents = f.read()
                except:
                    file_contents = ""
                text_contents[fname] = file_contents
        for file_path in csv_files:
            fname = file_path.rsplit("\\", maxsplit=1)[1].split(".")[0]
            with open(file_path, "r") as f:
                try:
                    file_contents = f.read()
                except:
                    file_contents = ""
                text_contents[fname] = file_contents

        return text_contents

    def get_logs_from_file(self, parent_path, fname, text_contents, dname):
        print(fname)
        dname = dname.replace(" ", "_")
        file_path = parent_path + f"\\{fname}"
        fname = file_path.rsplit("\\", maxsplit=1)[1].split(".")[0]
        with open(file_path, "r") as f:
            print(f"\t{file_path}")
            try:
                file_contents = f.read()
            except:
                file_contents = ""
            text_contents[dname] = "\n" + file_contents

        return text_contents

    def write_data_to_file(self, file_path, content, append_data=False):
        content = json.loads(content)
        if append_data:
            if not os.path.exists(file_path):
                existing_data = content
            else:
                with open(file_path, "r") as f:
                    existing_data = json.loads(f.read())
                existing_data.extend(content)
            with open(file_path, "w") as f:
                json.dump(existing_data, f)
        else:
            with open(file_path, "w") as f:
                json.dump(content, f)
