import os
import allure
import json

from config_general import GnConfig


class Commons:
    def __init__(self) -> None:
        pass

    def write_text_to_file(self, list_of_values, path):
        with open(path, "w") as f:
            f.write(",".join(list_of_values))
            f.close()

    def getListOfFiles_from_jobid(self, job_id, extension=".csv"):
        csv_pq_file_paths = (
            f"{GnConfig.download_file_paths}{job_id}{GnConfig.converted_csv_file_path}"
        )
        extension = f".{extension}"
        list_of_results = []
        for file in os.listdir(csv_pq_file_paths):
            if file.endswith(extension):
                list_of_results.extend([f"{csv_pq_file_paths}\{file}"])
        return list_of_results

    def getListOfFiles(self, path, extension):
        extension = f".{extension}"
        list_of_results = []
        for file in os.listdir(path):
            if file.endswith(extension):
                list_of_results.extend([f"{path}\{file}"])
        return list_of_results

    def read_itemsfrom_file(self, path, folder_list, extension=".parquet"):
        items = []
        for sub_folder in folder_list:
            print(sub_folder)
            file_path = f"{path}/{sub_folder}/"
            for file_item in os.listdir(file_path):
                if file_item.endswith(extension):
                    items.extend([(sub_folder, file_item.split(".")[0])])
                    break
        return items

    def read_file_from_folders(self, path, extension=".parquet"):
        items = []
        for file_item in os.listdir(path):
            if file_item.endswith(extension):
                items.extend([file_item.split(".")[0]])
        return items

    def attachjson_to_allure_astextfile(self, json_value, name_to_appear=""):
        allure.attach(
            json.dumps(json_value, default=str),
            name=name_to_appear,
            attachment_type=allure.attachment_type.TEXT,
        )

    def attach_text_to_allure(self, text, name_to_appear=""):
        allure.attach(text, name=name_to_appear)

    def attach_textfile_to_allure(self, text, name_to_appear=""):
        allure.attach(
            text, name=name_to_appear, attachment_type=allure.attachment_type.TEXT
        )

    def attach_csvfile_to_allure(self, csv_value, name_to_appear=""):
        allure.attach(
            csv_value, name=name_to_appear, attachment_type=allure.attachment_type.CSV
        )
