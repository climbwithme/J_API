from systems.connections.awsconnection import AwsConnection
from config_test import TestConfig

import os

from systems.reusables.oscommons import OsCommons


class AwsCommons:
    def __init__(self) -> None:
        self.aws = AwsConnection()
        self.aws.createClient()

    def get_list_of_buckets(self):
        return self.aws.boto_client.list_buckets()

    def get_list_of_objects(self, bucket, prefix):
        return self.aws.boto_client.list_objects_v2(Bucket=bucket, Prefix=prefix)

    def download_particular_csv_file(self, bucket, key, fp):
        file_path = os.path.join(TestConfig.SRC_PATH, f'{fp}{key.rsplit("/", maxsplit=1)[1]}')
        self.aws.setTransferConfig()
        print(file_path)
        print(type(self.aws.boto_client))
        # with open(file_path, 'wb') as f:
        # self.aws.boto_client.download_fileobj(bucket, key, f, Config=self.aws.transfer_config)
        self.aws.boto_client.download_file(
            Bucket=bucket, Key=key, Filename=file_path, Config=self.aws.transfer_config
        )

    def download_files_from_aws(self, bucket, response, storage_path, endswith='.csv', containing=''):
        content_key = 'Contents'
        obj_key = 'Key'
        counter = 0
        self.aws.setTransferConfig()
        for obj in response[content_key]:
            key = obj[obj_key]
            # print(key)
            if key.__contains__(containing) and key.endswith(endswith):
                counter+=1
                if endswith == '.parquet':
                    fp = f'{storage_path}/{key.rsplit("/", maxsplit=2)[1]}'
                    print(fp)
                    OsCommons().create_path(fp)
                else:
                    fp = storage_path
                with open(f'{fp}/{key.rsplit("/", maxsplit=1)[1]}', 'wb') as f:
                    self.aws.boto_client.download_fileobj(bucket, key, f, Config=self.aws.transfer_config)
                    print(f'Downloaded file - {key}')
        print(f'No. of files downloaded: {counter}')
        assert(counter>0, f'No. of files downloaded: {counter}')
