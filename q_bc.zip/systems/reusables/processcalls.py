import pytest
import json

from pandas import DataFrame
from config_rules import ExternalPaths, InternalPaths, TableGenColNames
from systems.reusables.dfcommons import DfCommons
from systems.reusables.oscommons import OsCommons
from systems.reusables.rulecommons import RuleCommons
from systems.reusables.softerror import SoftError
from systems.reusables.sqlcommons import SqlCommons
from config_general import GnConfig


class ProcessCalls:
    def check_skip_tests(self, job_id: int, sql: SqlCommons, col_name: str):
        if sql.getColumnValue(job_id, col_name) == 0:
            pytest.skip("Validation skipped as per configuration")

    def check_mandatory_in_df(self, df: DataFrame, col_name: str, table_name: str, softerror: SoftError, fname="", silent = True):
        mandatory_columns = RuleCommons.test_mandatory_fields(col_name, table_name)
        df = DfCommons.validateMandatoryColumns(df, mandatory_columns, softerror, fname, silent)
        if len(fname) > 0:
            df["FNAME"] = fname
            mandatory_columns.insert(0, "FNAME")
        return df[mandatory_columns]

    def check_flength_in_df(self, df: DataFrame, col_name: str, table_name: str, softerror: SoftError, sql: SqlCommons):
        primary_key = sql.getPrimaryKey(table_name)
        filt_columns = RuleCommons.test_field_length(col_name, table_name)
        df_list = DfCommons.validateFieldLength(df, filt_columns, softerror, sql)
        return self.merged_dfs(df_list, primary_key)

    def writeResultToDB(self, df: DataFrame, result_col: str, job_id: int, sql: SqlCommons):
        json_data = df.to_json(orient="records")
        escaped_json = json.dumps(json.loads(json_data)).replace("'", "''")
        # print(escaped_json)
        sql.setColumnValue(escaped_json, result_col, job_id)

    def writeResultToFile(self, df: DataFrame, file_name: str, job_id: int, module_name: str, append_data=False):
        json_data = df.to_json(orient="records")
        file_path = f'{GnConfig.report_path}\\{module_name}\\{job_id}\\summary'
        OsCommons().create_path(file_path)
        file_path = f'{file_path}\\{file_name}.json'
        OsCommons().write_data_to_file(file_path=file_path, content=json_data, append_data=append_data)

    def writeJsonToFile(self, dict_data: dict, file_name: str, job_id: int, module_name: str, append_data=False):
        dict_data = json.dumps(dict_data)
        file_path = f'{GnConfig.report_path}\\{module_name}\\{job_id}\\summary'
        OsCommons().create_path(file_path)
        file_path = f'{file_path}\\{file_name}.json'
        OsCommons().write_data_to_file(file_path=file_path, content=dict_data, append_data=append_data)

    def getDfFromPath_ForExternal(self, path: str, module: str, model: ExternalPaths, new_columns_names, compare_columns):
        if model == ExternalPaths.SOURCE:
            skiprows = RuleCommons.get_skiprow_external_src(module)
            header = None if RuleCommons.get_override_info_src(module) else "infer"
        elif model == ExternalPaths.TARGET:
            skiprows = RuleCommons.get_skiprow_external_target(module)
            header = None if RuleCommons.get_override_info_src(module) else "infer"
        df = DfCommons.readCsvOverrideNA(path, skiprows=skiprows, header=header)
        df.dropna(axis=1, how="all", inplace=True)
        # df = df[compare_columns]
        df.columns = new_columns_names
        return df[compare_columns]

    def getDfFromPath_ForInternal(self, path: str, module: str, model: InternalPaths, compare_columns):
        if model == InternalPaths.SOURCE or InternalPaths.HIVE_SRC:
            skiprows = RuleCommons.get_skiprow_external_src(module)
            header = None if RuleCommons.get_override_info_src(module) else "infer"
        if model == InternalPaths.SOURCE:
            sep = GnConfig.SEP_PAYMENT
            df = DfCommons.readCsvOverrideNA(path, skiprows=skiprows, header=header, sep=sep)
        else:
            df = DfCommons.readCsvOverrideNA(path, skiprows=skiprows, header=header)
        return df[compare_columns]

    def compareTwoDataFrames(
        self,
        df_src: DataFrame,
        df_target: DataFrame,
        compare_columns,
        table_name: str,
        sql: SqlCommons,
        softerror: SoftError,
        file_name = "",
        transfrom_ind = TableGenColNames.TRANS_SRC, suffix_x="source", suffix_y="target", how="left", primary_key = ""
    ):
        if primary_key == "":
            primary_key = sql.getPrimaryKey(table_name)
        df_list = []
        for col in compare_columns:
            print(f"\tValidating Field Matching for column {col}")
            if transfrom_ind == TableGenColNames.TRANS_SRC:
                transform = RuleCommons.get_srctransformations_of_field(col, table_name)
                df_src = DfCommons.applyTransformations(df_src, col, transform)
            elif  transfrom_ind == TableGenColNames.TRANS_TAR:
                transform = RuleCommons.get_srctransformations_of_field(col, table_name, trans_col=transfrom_ind.value)
                df_src = DfCommons.applyTransformations(df_src, col, transform)
            df_mismatched = DfCommons.compareTwoDataframes(
                df_src, df_target, primary_key, col, suffix_x=suffix_x, suffix_y=suffix_y, how=how
            )
            DfCommons.logMisMatchedEntries(df_mismatched, col, softerror, msg=f'{file_name} - {col}')
            df_list.append(df_mismatched)
        df = self.merged_dfs(df_list, primary_key)
        if len(file_name) > 0:
            name_key = "FNAME"
            df[name_key] = file_name
            pop = df.pop(name_key)
            df.insert(0, name_key, pop)
        return df

    def merged_dfs(self, df_list: list, primary_key: str) -> DataFrame:
        merged_df = df_list[0]
        for df in df_list[1:]:
            merged_df = DfCommons.mergeDfs(merged_df, df, primary_key)
        if primary_key in merged_df.columns:
            pop = merged_df.pop(primary_key)
            merged_df.insert(0, primary_key, pop)
            # print(nonmatching_df.columns)
        return merged_df

    def renamePaymentDf(self, df: DataFrame, payment_mapping: dict):
        for old_col, new_col in payment_mapping.items():
            if isinstance(new_col, str):
                df = df.rename(columns={old_col: new_col})
            elif isinstance(new_col, list):
                for new_col_name in new_col:
                    df[new_col_name] = df[old_col]
        return df