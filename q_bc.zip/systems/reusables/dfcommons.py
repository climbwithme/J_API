import pandas as pd
import numpy as np
import allure

from pandas import DataFrame
from config_rules import TableGenColNames
from systems.reusables.commons import Commons
from systems.reusables.sqlcommons import SqlCommons
from systems.reusables.softerror import SoftError


class DfCommons:
    def readCsvAsPd(path_to_csv, sep=",", override_na=False) -> DataFrame:
        if override_na:
            return pd.read_csv(
                path_to_csv,
                sep=sep,
                engine="python",
                keep_default_na=False,
                na_values=[""],
            )
        else:
            return pd.read_csv(path_to_csv, sep=sep, engine="python")

    def readCsvOverrideNA(path_to_csv, skiprows=None, header="infer", sep=None) -> DataFrame:
        if header is None:
            if skiprows is None:
                skiprows = 1
            else:
                skiprows += 1
        if sep is None:
            print("reading as non")
            return pd.read_csv(
                path_to_csv,
                keep_default_na=False,
                na_values=[""],
                skiprows=skiprows,
                header=header,
                sep=","
            )
        return pd.read_csv(
            path_to_csv,
            keep_default_na=False,
            na_values=[""],
            skiprows=skiprows,
            header=header,
            sep=sep,
            engine="python",
        )

    def readCsvWithEncoding(path_to_csv, encoding=None) -> DataFrame:
        if encoding:
            return pd.read_csv(path_to_csv, engine="python", encoding=encoding, dtype="object")
        else:
            return pd.read_csv(path_to_csv, engine="python")  # ISO-8859-1

    def getNumberOfRows(df: DataFrame):
        return df.shape[0]

    def applyTransformations(df: DataFrame, col, transformations):
        if transformations:
            for transform in transformations.split("|||"):
                print(f'Applying transformation {transform}')
                if transform == "strip":
                    df[col] = df[col].str.strip()
                if transform == "case_sentence":
                    df[col] = df[col].str.capitalize()
                if transform == "case_lower":
                    df[col] = df[col].str.lower()
                if transform == "case_upper":
                    df[col] = df[col].str.upper()
                if transform == "fillna":
                    df[col].fillna("", inplace=True)
                if transform == "makeemptynull":
                    df[col] = df[col].replace("", np.nan)
        return df

    def getUniqueValues(df: DataFrame, col) -> list:
        return list(df[col].unique())

    def validateMandatoryColumns(df: DataFrame, mandatory_columns: list, softerror: SoftError, fname="", silent = False) -> DataFrame:
        result_df = df[mandatory_columns].isnull().sum()

        null_columns = []
        with allure.step(f"Validating count of null rows"):
            for column, count in result_df.iteritems():
                if count == 0:
                    if not silent:
                        softerror.add_to_passlist(f"Column {column} has no empty fields ~ {fname}")
                else:
                    null_columns.append(column)
                    if not silent:
                        softerror.add_to_error(f"Column {column} has {count} empty fields ~ {fname}")

        null_check = df[mandatory_columns].isnull()
        with allure.step(f"Extracting null values"):
            for column in null_columns:
                null_rows = df[null_check[column]]
                Commons().attach_csvfile_to_allure(null_rows.to_csv(), f"{column} - Null Rows")
        df = df[mandatory_columns]
        return df[null_check.any(axis=1)]

    def validateFieldLength(df: DataFrame, filt_columns, softerror: SoftError, sql: SqlCommons) -> list:
        df_list = []
        for col in filt_columns:
            print(f"Validating column {col}")
            length_of_field = int(
                sql.getColumnValues("field_length", f'where {TableGenColNames.EX_TARGET.value}="{col}"')[0][0]
            )
            lengths = df[col].str.len()
            mask = lengths != length_of_field
            filtered_rows = df[mask]
            new_df = pd.DataFrame(filtered_rows)
            df_list.append(new_df)
            num_of_records = new_df.shape[0]
            if new_df.shape[0] == 0:
                softerror.add_to_passlist(f"Column {col} has correct field length {length_of_field}")
            else:
                fail_msg = f"{num_of_records} rows have Column {col} length other than {length_of_field} "
                Commons().attach_csvfile_to_allure(new_df.to_csv(), fail_msg)
                softerror.add_to_error(fail_msg)
            print("Violated Data:")
            print(new_df.head())
        return df_list

    def compareTwoDataframes(df_source, df_target, key, col, suffix_x, suffix_y, how) -> DataFrame:
        # print(key)
        col_filt_src_df = df_source[list(set([key, col]))]
        col_filt_tar_df = df_target[list(set([key, col]))]
        direct_comb_df = pd.merge(
            col_filt_src_df,
            col_filt_tar_df,
            on=key,
            how=how,
            suffixes=(f'___{suffix_x}', f'___{suffix_y}'),
        )
        combined_df = pd.concat([col_filt_src_df, col_filt_tar_df], axis=0, ignore_index=True)
        duplicates = combined_df.duplicated(keep=False)
        nonmatching_df = direct_comb_df[~duplicates]
        # subset = nonmatching_df[:, 1:3]
        # nonmatching_df = nonmatching_df.dropna(subset=subset.columns)
        return nonmatching_df

    def compareCountTwoDataframes(df_source, df_target, softerror: SoftError) -> tuple:
        count_source = DfCommons.getNumberOfRows(df_source)
        count_target = DfCommons.getNumberOfRows(df_target)
        if count_source != count_target:
            fail_msg = f"Source: {count_source} | Target: {count_target} - Mismatch in Count"
            softerror.add_to_error(fail_msg)
        else:
            softerror.add_to_passlist(f"Count Matched {count_source}")
        return (count_source, count_target)

    def logMisMatchedEntries(df_mismatched: DataFrame, col, softerror: SoftError, msg="") -> None:
        mis_match_count = df_mismatched.shape[0]

        if mis_match_count > 0:
            fail_msg = f"{col} has {mis_match_count} - Total Differences found; {msg}"
            Commons().attach_csvfile_to_allure(df_mismatched.to_csv(), fail_msg)
            softerror.add_to_error(fail_msg)
        else:
            softerror.add_to_passlist(f"All Records matched + {msg}")

    def mergeDfs(df_src: DataFrame, df_target: DataFrame, primary_key: str, how="outer") -> DataFrame:
        return pd.merge(df_src, df_target, on=primary_key, how=how)
