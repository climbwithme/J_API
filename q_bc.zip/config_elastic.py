import os


class ESConfig(object):

    ## ELASTIC SEARCH CONFIGURATIONS
    es_server_name_sit = "https://kb-sit.sit01-qtxcb.shared.banksvcs.net"
    es_server_name_nft = "https://kb-nft.nft01-qtxcb.shared.banksvcs.net"

    # Elastic Search Credentials
    es_user = os.environ.get("ES_USER")
    es_password = os.environ.get("ES_PASS")
    es_password_nft = os.environ.get("ES_PASS_NFT")

    # Query Search Endpoint
    endpoint_sit = f"{es_server_name_sit}/api/console/proxy?"
    endpoint_nft = f"{es_server_name_nft}/api/console/proxy?"

    # Headers
    headers = {
        "kbn-xsrf": "kibana",
        "Content-Type": "application/json"
    }
