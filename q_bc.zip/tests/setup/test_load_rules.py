import os 
import pandas as pd

from sqlalchemy import create_engine

from config_general import GnConfig

class TestLoadRules:
    def test_load_data(self):
        
        engine = create_engine(f'sqlite:///{GnConfig.DB_PATH_RULES}')
        curr_path = os.path.dirname(os.path.abspath(__file__))

        for file_name_with_ext in os.listdir(curr_path):
            if file_name_with_ext.endswith('.csv'):
                try:
                    file_name = file_name_with_ext.split('.')[0]
                    curr_file = os.path.join(curr_path, f'{file_name}.csv')
                    df = pd.read_csv(curr_file)
                    print(df.head())
                    df.to_sql(name=file_name, con=engine, if_exists="replace", index=False)
                except Exception as e:
                    print(f'File load failed for {file_name_with_ext} - {e}')