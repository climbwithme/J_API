import os
import glob
import json
import pandas as pd
import numpy as np
from concurrent.futures import ProcessPoolExecutor

from config_general import GnConfig
from systems.reusables.oscommons import OsCommons
from tests.base_fix import BaseFix


def diff_color(val):
    # print(val)
    color = "LightGreen"
    if all([value is None for value in val]):
        color = "LightGreen"
    if any([value is None for value in val]):
        color = "LightGreen"
    if val[0] != val[1]:
        color = "LightCoral"

    background = ["background-color: {}".format(color) for _ in val]
    return background


def mandatory_color(val):
    if val == np.nan or val == "" or val == None:
        return "background-color: LightCoral"


class TestWriteResults(BaseFix):
    def test_mandatory_results(self, job_id, job_type):
        folder_path = f"app\\static\\py_reports\\{job_type}\\{job_id}\\summary\\"
        output_path = f"app\\static\\py_reports\\{job_type}\\{job_id}\\final_report\\"
        output_file = f"{output_path}\\Failure Report Mandatory"
        output_html = f"{output_path}\\Failure_Report_Mandatory.html"
        sheet_name="Mandatory"
        OsCommons().create_path(output_path)
        json_files = glob.glob(f"{folder_path}\\result_mandatory*.json")
        
        if job_type not in ["External", "external"]:
            if job_type in ["Quantexa", "quantexa"]:
                csv_pq_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.csv_storage_path)
            else:
                csv_pq_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.csv_target_storage_path)
            for filename in os.listdir(csv_pq_file_paths):
                filename = filename.split('.')[0]
                print(filename)
                json_files = glob.glob(f"{folder_path}\\result_mandatory_{filename}*")
                if len(json_files) > 0:
                    json_data = []
                    for file in json_files:
                        with open(file) as f:
                            data = json.load(f)
                            json_data.extend(data)
                    df = pd.DataFrame(json_data)
                    if df.shape[0] > 0:
                        print("Data present to write")
                        styled_df = df.style.applymap(mandatory_color)
                        styled_df.to_excel(f'{output_file}_{filename}.xlsx', index=False, sheet_name=sheet_name)
        else:
            json_data = []
            for file in json_files:
                with open(file) as f:
                    data = json.load(f)
                    json_data.extend(data)
                fname = file.split(".")[0]
                fname = fname.split("result_mandatory")[1]
                df = pd.DataFrame(json_data)
                print(df.head())

                if df.shape[0] > 0:
                    styled_df = df.style.applymap(mandatory_color)
                    styled_df.to_excel(f'{output_file}_{fname}.xlsx', index=False, sheet_name=sheet_name)

    def test_comparison_results(self, job_id, job_type):
        
        folder_path = f"app\\static\\py_reports\\{job_type}\\{job_id}\\summary\\"
        output_path = f"app\\static\\py_reports\\{job_type}\\{job_id}\\final_report\\"
        output_file = f"{output_path}\\Failure Report Comparison"
        output_html = f"{output_path}\\Failure_Report_Comparison.html"
        sheet_name="Comparison"
        OsCommons().create_path(output_path)
        json_files = glob.glob(f"{folder_path}\\result_comparison*.json")

        for file in json_files:
            with open(file) as f:
                data = json.load(f)
                # json_data.extend(data)

            fname = file.split(".")[0]
            fname = fname.split("result_comparison")[1]

            df = pd.DataFrame(data)
            df.fillna('', inplace=True)
            # print(df.head())

            if df.shape[0] > 0:
                columns = list(df.columns)

                filtered_col = set(
                    [x.rsplit('___', maxsplit=1)[0] for x in columns if '___' in x]
                )
                # print(columns)
                # print(filtered_col)
                filtered_col = list(filtered_col)
                compare_cols = [x for x in columns if filtered_col[0] in x]
                # print("Filtered cols: ", filtered_col)
                # print("Compared cols: ", compare_cols)
                print(file, df.shape)
                chunk_size = 50000
                total_records = len(df)
                num_chunks = (total_records-1) // chunk_size + 1
                chunks = [df[i * chunk_size: (i+1) * chunk_size] for i in range(num_chunks)]
                for i,chunk in enumerate(chunks):
                    new_df = pd.DataFrame(chunk)
                    styled_df = new_df.style.apply(
                        diff_color, subset=compare_cols, axis=1
                    )
                    for col in filtered_col[1:]:
                        under_val = [x for x in columns if col in x]
                        print(col, under_val)
                        styled_df.apply(diff_color, subset=under_val, axis=1)
                    styled_df.to_excel(f'{output_file}_{fname}_{i+1}_of_{num_chunks}.xlsx', index=False, sheet_name=sheet_name)
                # df.to_excel(f'{output_file}_{fname}.xlsx', index=False, sheet_name=sheet_name)
        

    def test_count_results(self, job_id, job_type):
        
        folder_path = f"app\\static\\py_reports\\{job_type}\\{job_id}\\summary\\"
        output_path = f"app\\static\\py_reports\\{job_type}\\{job_id}\\final_report\\"
        output_file = f"{output_path}\\Failure Report Count Validation"
        sheet_name="Count Validation"
        OsCommons().create_path(output_path)
        file =f"{folder_path}\\result_count.json"

        # for file in json_files:
        with open(file) as f:
            data = json.load(f)
            # json_data.extend(data)

        # fname = file.split(".")[0]
        # fname = fname.split("result_comparison_")[1]

        df = pd.DataFrame(data)
        df = df.set_index('name').T
        df.fillna('', inplace=True)
        print(df.head())

        columns = list(df.columns)

        filtered_col = set(
            [x.rsplit('___', maxsplit=1)[0] for x in columns if '___' in x]
        )
        print(columns)
        print(filtered_col)
        filtered_col = list(filtered_col)
        compare_cols = [x for x in columns if filtered_col[0] in x]
        print("Filtered cols: ", filtered_col)
        print("Compared cols: ", compare_cols)
        styled_df = df.style.apply(
            diff_color, subset=compare_cols, axis=1
        )
        for col in filtered_col[1:]:
            under_val = [x for x in columns if col in x]
            print(col, under_val)
            styled_df.apply(diff_color, subset=under_val, axis=1)
        styled_df.to_excel(f'{output_file}.xlsx', index=False, sheet_name=sheet_name)
        