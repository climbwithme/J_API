import dask.dataframe as dd
import csv
import pytest
import allure

from config_test import TestConfig
from config_general import GnConfig
from systems.reusables.commons import Commons


class TestWCCsvToPq:

    @allure.feature("World Check Files to Parquet")
    @allure.suite("World Check Files to Parquet Convertion")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.tag("World Check -> Parquet")
    @pytest.mark.parametrize('file_name', Commons().read_file_from_folders(f'{GnConfig.download_file_paths}\World_Check\{GnConfig.csv_storage_path}', extension='.csv'))
    def test_wc_pq_conversion(self, file_name):
        allure.dynamic.tag(file_name)
        allure.dynamic.description(f"Convert all CSV Files of type World Check")

        with allure.step(f"Convert all World Check files From CSV -> Parquet"):
            download_file_paths = f'{GnConfig.download_file_paths}/World_Check/{GnConfig.csv_storage_path}'
            write_file_path = f'{GnConfig.converted_csv_file_path}/World_Check'
            Commons().create_path(write_file_path)

            csv_df = dd.read_csv(
                f"{download_file_paths}/{file_name}.csv", 
                sep=GnConfig.sep_wc, 
                engine="python", 
                dtype='object',
                quoting=csv.QUOTE_NONE
            )

            csv_df.repartition(partition_size="2MB")
            csv_df.to_parquet(f'{write_file_path}/{file_name.split(".")[0]}.parquet', engine='pyarrow', compression='snappy')