import pytest
import sqlite3

class BaseFix:
    @pytest.fixture(scope="session")
    def job_id(self, pytestconfig):
        # job_id = pytestconfig.getoption("--job_id")
        return pytestconfig.getoption("--job_id")

    @pytest.fixture(scope="session")
    def job_type(self, pytestconfig):
        return pytestconfig.getoption("--job_type")
