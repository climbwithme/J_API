import dask.dataframe as dd
import csv
import pytest
import allure

from config_test import TestConfig
from config_general import GnConfig
from systems.reusables.commons import Commons
from tests.base_fix import BaseFix


class Test(BaseFix):
    def test_new(self, job_id):
        print(job_id)
