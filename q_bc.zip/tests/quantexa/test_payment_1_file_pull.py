import urllib3
import allure
from config_rules import TableGenColNames, TableJobs

from config_general import GnConfig
from systems.reusables.awscommons import AwsCommons
from systems.reusables.commons import Commons
from systems.reusables.oscommons import OsCommons
from systems.reusables.sqlcommons import SqlCommons
from tests.base_fix import BaseFix


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class TestPayments(BaseFix):

    @allure.suite("Quantexa File Tests")
    @allure.feature("AWS CSV File Download")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.description(f"Retrieve the CSV Files")
    def test_csv_downloads(self, job_id):

        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            sql = SqlCommons(TableJobs.QUANTEXA.value)
            csv_lists = sql.getColumnValue(job_id, TableGenColNames.Q_FILE_LIST.value)[1:-1].split(', ')
            csv_bucket = sql.getColumnValue(job_id, TableGenColNames.Q_BUCKET_SRC.value)
            storage_path_target = OsCommons().getQuantexaPaths(job_id, GnConfig.csv_storage_path, create=True)

        for csv_file_name in csv_lists:
            csv_file_name = csv_file_name[1:-1]
            csv_file_name = csv_file_name.replace("'", "")
            print(csv_file_name)
            with allure.step(f"Pull {csv_file_name} Data From AWS S3"):
                aws_commons = AwsCommons()
                aws_commons.download_particular_csv_file(csv_bucket, csv_file_name, storage_path_target)
        
        
    @allure.suite("Quantexa File Tests")
    @allure.feature("AWS Raw Parquet File Download")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.description(f"Retrieve the Parquet Files")
    def test_raw_pq_downloads(self, job_id):
        
        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            sql = SqlCommons(TableJobs.QUANTEXA.value)
            csv_lists = sql.getColumnValue(job_id, TableGenColNames.Q_FILE_LIST.value)[1:-1].split(', ')
            raw_pq_bucket = sql.getColumnValue(job_id, TableGenColNames.Q_BUCKET_TARGET.value)
            prefix = sql.getColumnValue(job_id, TableGenColNames.Q_RAWPQ.value)
            storage_path_target = OsCommons().getQuantexaPaths(job_id, GnConfig.parquet_storage_path, create=True)
       

        for csv_file_name in csv_lists:
            csv_file_name = csv_file_name[1:-1].rsplit('/', maxsplit=1)[1].split('.')[0]
            with allure.step(f"Pull {csv_file_name} Data From AWS S3"):
                # prefix = TestConfig.PREFIX_RAW_PQ
                print(csv_file_name, raw_pq_bucket, prefix)

                aws_commons = AwsCommons()
                response = aws_commons.get_list_of_objects(raw_pq_bucket, prefix)
                aws_commons.download_files_from_aws(raw_pq_bucket, response, storage_path_target, endswith='.parquet', containing=csv_file_name)
                Commons().attachjson_to_allure_astextfile(response, name_to_appear='AWS Client Response')
