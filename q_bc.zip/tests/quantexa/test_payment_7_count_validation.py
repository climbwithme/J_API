import dask.dataframe as dd
import allure

from config_general import GnConfig, WorkFlowType
from config_rules import InternalWF, TableGenColNames, TableJobs
from systems.reusables.softerror import SoftError
from systems.reusables.oscommons import OsCommons
from systems.reusables.processcalls import ProcessCalls
from systems.reusables.rulecommons import RuleCommons
from systems.reusables.softerror import SoftError
from systems.reusables.sqlcommons import SqlCommons

from tests.base_fix import BaseFix


class TestComparisonPqElastic(BaseFix):
    @allure.suite("Quantexa File Tests")
    @allure.feature("Quantexa Flow: CSV vs Raw Parquet")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.tag("Count Validation")
    @allure.description("Count Validation - CSV vs Raw Parquet")
    def test_file_compare_csv_rawpq(self, q_source_csv, job_id):
        softerror = SoftError()

        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            table_job = TableJobs.QUANTEXA.value

            sql = SqlCommons(table_job)
            ProcessCalls().check_skip_tests(job_id, sql, TableGenColNames.VAL_COUNT.value)
            module = sql.getColumnValue(job_id, TableGenColNames.MODULE.value)
            print(q_source_csv, job_id)
            fname = q_source_csv.split(".")[0]

            csv_pq_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.mapped_raw_pq_path)
            proc_pq_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.mapped_proc_pq_path)

        with allure.step(f"Get Module Rules For: {module}"):
            if module == InternalWF.PAYMENTS.value:
                table_name = RuleCommons.get_db_name_quantexa(q_source_csv)
            else:
                table_name = RuleCommons.get_db_name_internal(module)
            target_col_name = TableGenColNames.Q_PQ.value
            columns_to_validate = RuleCommons.test_mandatory_fields(target_col_name, table_name)

        print(columns_to_validate, table_name)
        src_path = f"{csv_pq_file_paths}\\{fname}.parquet\\"
        proc_path = f"{proc_pq_file_paths}\\{fname}.parquet\\"
        print(src_path)
        print(proc_path)

        with allure.step(f"Read the File under validation: {q_source_csv} - Rules - {table_name}"):
            df_src = dd.read_parquet(f"{src_path}\\*.parquet")
            df_target = dd.read_parquet(f"{proc_path}\\*.parquet")

            count_src = df_src.shape[0].compute()
            count_target = df_target.shape[0].compute()

        with allure.step(f"Write result to File:"):
            result_dict = [
                {"name": f"{fname}___Hive Data", "value": count_src},
                {"name": f"{fname}___Target Data", "value": count_target},
            ]
            res_col = TableGenColNames.RES_COUNT.value
            ProcessCalls().writeJsonToFile(result_dict, res_col, job_id, WorkFlowType.Quantexa.value, append_data=True)
        
        if count_src != count_target:
            fail_msg = f"Count Mismatch Found for {fname}"
            softerror.add_to_error(fail_msg)
        else:
            softerror.add_to_passlist(f"Count Matched - {count_src}")

        softerror.log_all_error_to_report()
