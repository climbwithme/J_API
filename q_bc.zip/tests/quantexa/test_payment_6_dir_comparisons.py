import pandas as pd
import allure
import os
import json

from config_general import GnConfig, WorkFlowType
from config_rules import InternalWF, PaymentFields, PaymentTypes, TableGenColNames, TableJobs
from systems.reusables.softerror import SoftError
from systems.reusables.oscommons import OsCommons
from systems.reusables.processcalls import ProcessCalls
from systems.reusables.rulecommons import RuleCommons
from systems.reusables.softerror import SoftError
from systems.reusables.sqlcommons import SqlCommons

from tests.base_fix import BaseFix


class TestComparisonPqElastic(BaseFix):
    @allure.suite("Quantexa File Tests")
    @allure.feature("Quantexa Flow: Raw vs Proc Parquet")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.tag("Field Comparison")
    @allure.description("Field Comparison - Raw vs Proc Parquet")
    def test_file_compare_rawpq_procpq(self, q_source_csv, job_id):
        softerror = SoftError()

        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            table_job = TableJobs.QUANTEXA.value

            sql = SqlCommons(table_job)
            ProcessCalls().check_skip_tests(job_id, sql, TableGenColNames.VAL_COMPARISON.value)
            module = sql.getColumnValue(job_id, TableGenColNames.MODULE.value)
            print(q_source_csv, job_id)
            fname = q_source_csv.split(".")[0]

            csv_pq_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.mapped_raw_pq_path)
            proc_pq_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.mapped_proc_pq_path)

        with allure.step(f"Get Module Rules For: {module}"):
            if module == InternalWF.PAYMENTS.value:
                table_name = RuleCommons.get_db_name_quantexa(q_source_csv)
            else:
                table_name = RuleCommons.get_db_name_internal(module)
            target_col_name = TableGenColNames.Q_PQ.value
            columns_to_validate = RuleCommons.test_mandatory_fields(target_col_name, table_name)

        print(columns_to_validate, table_name)
        src_path = f"{csv_pq_file_paths}\\{fname}.parquet\\"
        proc_path = f"{proc_pq_file_paths}\\{fname}.parquet\\"
        print(src_path)
        print(proc_path)
        total_scanned_records_in_raw_pq = 0
        total_scanned_records_in_proc_pq = 0

        df_list = []

        with allure.step(f"Read the File under validation: {q_source_csv} - Rules - {table_name}"):
            trans_id = PaymentFields.TRANSACTION_ID.value

            for file in os.listdir(src_path):
                print(f"Validating {file} of {q_source_csv}")
                print(f'\tSRC PATH: "{src_path}\\{file}')
                print(f'\tTARGET PATH: "{proc_path}\\{file}')
                df_src = pd.read_parquet(f"{src_path}\\{file}")
                df_target = pd.read_parquet(f"{proc_path}\\{file}")

                total_scanned_records_in_raw_pq += df_src.shape[0]
                total_scanned_records_in_proc_pq += df_target.shape[0]

                compare_cols_source = RuleCommons.get_comparison_fields(TableGenColNames.Q_PQ.value, table_name)
                compare_cols_target = RuleCommons.get_comparison_fields(TableGenColNames.Q_TPROCPQ.value, table_name)
                new_col_names = RuleCommons.get_comparison_fields_native(table_name)

                compare_cols_target.append(trans_id)
                new_col_names.append(trans_id)

                df_src = df_src[compare_cols_source]
                df_target = df_target[compare_cols_target]
                payment_type = fname.split("_")[1]
                if payment_type == PaymentTypes.PMTR.value or payment_type == PaymentTypes.NADR.value:
                    suffix = "RBS"
                elif payment_type == PaymentTypes.PMTN.value or payment_type == PaymentTypes.NADN.value:
                    suffix = "NWB"
                else:
                    suffix = "QMU"

                if payment_type.startswith("P"):
                    acc_type = PaymentFields.IFPAY_ACCTING_TYPE.value
                else:
                    acc_type = PaymentFields.IFNAD_ACCTING_TYPE.value

                trans_id_value = (
                    df_src[PaymentFields.PAYMN_NUMBER.value].astype(str) + df_src[acc_type].astype(str) + suffix
                )
                df_src[trans_id] = trans_id_value
                list_of_values = df_src[trans_id].unique()

                filtered_df = df_target[df_target[trans_id].isin(list_of_values)]

                with allure.step(f"Compare two Data frames - RAW PQ vs Processed PQ"):
                    df_src.columns = new_col_names
                    filtered_df.columns = new_col_names
                    compare_columns = RuleCommons.get_comparison_fields_native(table_name)
                    df_result = ProcessCalls().compareTwoDataFrames(
                        df_src,
                        filtered_df,
                        compare_columns,
                        table_name,
                        sql,
                        softerror,
                        file_name=f"{fname}_{file}",
                        suffix_x="raw_pq",
                        suffix_y="proc_pq",
                        transfrom_ind="transformations",
                    )

                diff_count = df_result.shape[0]
                if diff_count > 0:
                    df_list.append(df_result)

        if len(df_list) > 0:
            merged_dfs = pd.concat(df_list)

            with allure.step(f"Write result to File:"):
                res_col = f"{TableGenColNames.RES_COMPARISON.value}_{fname}_CsvVsRawPq"
                ProcessCalls().writeResultToFile(merged_dfs, res_col, job_id, WorkFlowType.Quantexa.value)

        softerror.add_to_infolist(f"Total Records validated in RAW PQ {total_scanned_records_in_raw_pq}")
        softerror.add_to_infolist(f"Total Records validated in PROC QA {total_scanned_records_in_raw_pq}")
        softerror.log_all_error_to_report()

    @allure.suite("Quantexa File Tests")
    @allure.feature("Quantexa Flow: CSV vs Raw Parquet")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.tag("Field Comparison")
    @allure.description("Field Comparison - CSV vs Raw Parquet")
    def test_file_compare_csv_rawpq(self, q_source_csv, job_id):
        softerror = SoftError()

        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            table_job = TableJobs.QUANTEXA.value

            sql = SqlCommons(table_job)
            ProcessCalls().check_skip_tests(job_id, sql, TableGenColNames.VAL_COMPARISON.value)

            module = sql.getColumnValue(job_id, TableGenColNames.MODULE.value)
            print(q_source_csv, job_id)
            fname = q_source_csv.split(".")[0]

            csv_pq_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.mapped_raw_pq_path)
            raw_csv_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.converted_csv_file_path)

        with allure.step(f"Get Module Rules For: {module}"):
            if module == InternalWF.PAYMENTS.value:
                table_name = RuleCommons.get_db_name_quantexa(q_source_csv)
            else:
                table_name = RuleCommons.get_db_name_internal(module)
            target_col_name = TableGenColNames.Q_PQ.value
            columns_to_validate = RuleCommons.test_mandatory_fields(target_col_name, table_name)

        print(columns_to_validate, table_name)
        src_path = f"{raw_csv_file_paths}\\{fname}.parquet\\"
        proc_path = f"{csv_pq_file_paths}\\{fname}.parquet\\"
        print(src_path)
        # print(proc_path)

        df_list = []

        with allure.step(f"Read the File under validation: {q_source_csv} - Rules - {table_name}"):
            primary_key_value = PaymentFields.PAYMN_NUMBER.value

            for file in os.listdir(src_path):
                print(f"Validating {file} of {raw_csv_file_paths}")
                print(f'\tSRC PATH: "{src_path}\\{file}')
                print(f'\tTARGET PATH: "{proc_path}\\{file}')
                df_src = pd.read_parquet(f"{src_path}\\{file}")
                df_target = pd.read_parquet(f"{proc_path}\\{file}")

                compare_cols_source = RuleCommons.get_comparison_fields(TableGenColNames.Q_SRC_CSV.value, table_name)
                compare_cols_target = RuleCommons.get_comparison_fields(TableGenColNames.Q_PQ.value, table_name)

                new_col_names = RuleCommons.get_comparison_fields_native(table_name)

                df_src = df_src.loc[:, compare_cols_source]
                df_src.columns = new_col_names

                df_target = df_target.loc[:, compare_cols_target]
                df_target.columns = new_col_names

                with allure.step(f"Compare two Data frames - CSV vs Parquet File"):
                    compare_columns = RuleCommons.get_comparison_fields_native(table_name)
                    df_result = ProcessCalls().compareTwoDataFrames(
                        df_src,
                        df_target,
                        compare_columns,
                        table_name,
                        sql,
                        softerror,
                        file_name=f"{q_source_csv}_{file}",
                        suffix_x="src_csv",
                        suffix_y="raw_pq",
                    )
                diff_count = df_result.shape[0]
                if diff_count > 0:
                    df_list.append(df_result)

        # print(len(df_list))
        if len(df_list) > 0:
            merged_dfs = pd.concat(df_list)

            with allure.step(f"Write result to File:"):
                res_col = f"{TableGenColNames.RES_COMPARISON.value}_{fname}_PqVsProcpq"
                ProcessCalls().writeResultToFile(merged_dfs, res_col, job_id, WorkFlowType.Quantexa.value)
                # print(f'Differences found on {q_source_csv} - {file} is {diff_count}')

        softerror.log_all_error_to_report()

    @allure.suite("Quantexa File Tests")
    @allure.feature("Quantexa Flow: Processed Parquet vs QuantexaES")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.tag("Field Comparison")
    @allure.description("Field Comparison - Processed Parquet vs QuantexaES")
    def test_file_compare_procpq_es(self, q_source_csv, job_id):
        softerror = SoftError()

        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            table_job = TableJobs.QUANTEXA.value

            sql = SqlCommons(table_job)
            ProcessCalls().check_skip_tests(job_id, sql, TableGenColNames.VAL_COMPARISON.value)

            module = sql.getColumnValue(job_id, TableGenColNames.MODULE.value)
            print(q_source_csv, job_id)
            fname = q_source_csv.split(".")[0]

            proc_pq_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.mapped_proc_pq_path)
            es_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.es_storage_path)

        with allure.step(f"Get Module Rules For: {module}"):
            if module == InternalWF.PAYMENTS.value:
                table_name = RuleCommons.get_db_name_quantexa(q_source_csv)
            else:
                table_name = RuleCommons.get_db_name_internal(module)
            target_col_name = TableGenColNames.Q_PQ.value
            columns_to_validate = RuleCommons.test_mandatory_fields(target_col_name, table_name)

        target_path = f"{es_file_paths}\\{fname.split('.')[0]}\\"
        src_path = f"{proc_pq_file_paths}\\{fname}.parquet\\"
        print(src_path)
        print(target_path)

        df_list = []
        total_scanned_records_in_es = 0
        total_scanned_records_in_proc_pq = 0

        with allure.step(f"Read the File under validation: {q_source_csv} - Rules - {table_name}"):
            primary_key_value = PaymentFields.TRANSACTION_ID.value

            for file in os.listdir(src_path):
                print(f"Validating {file} of {es_file_paths}")
                print(f'\tSRC PATH: "{src_path}\\{file}')
                print(f'\tTARGET PATH: "{target_path}\\{file}')
                df_src = pd.read_parquet(f"{src_path}\\{file}")

                total_scanned_records_in_proc_pq += df_src.shape[0]

                with open(f"{target_path}\\response_{file}.json", "r") as f:
                    json_data = json.load(f)
                    source_list = [d["_source"] for d in json_data]
                    total_scanned_records_in_es += len(source_list)
                df_target = pd.json_normalize(source_list)

                # df_target = pd.read_json(f"{target_path}\\response_{file}.json")

                compare_cols_source = RuleCommons.get_comparison_fields(TableGenColNames.Q_TPROCPQ.value, table_name)
                compare_cols_target = RuleCommons.get_comparison_fields(TableGenColNames.Q_ES.value, table_name)
                new_col_names = RuleCommons.get_comparison_fields_native(table_name)

                compare_cols_source.insert(0, primary_key_value)
                compare_cols_target.insert(0, primary_key_value)
                new_col_names.insert(0, primary_key_value)

                df_src = df_src.loc[:, compare_cols_source]
                df_src.columns = new_col_names

                df_target = df_target.loc[:, compare_cols_target]
                df_target.columns = new_col_names

                with allure.step(f"Compare two Data frames - CSV vs Parquet File"):
                    compare_columns = RuleCommons.get_comparison_fields_native(table_name)
                    df_result = ProcessCalls().compareTwoDataFrames(
                        df_src,
                        df_target,
                        compare_columns,
                        table_name,
                        sql,
                        softerror,
                        file_name=f"{q_source_csv}_{file}",
                        suffix_x="proc_pq",
                        suffix_y="quantexa_es",
                        primary_key=primary_key_value,
                    )
                diff_count = df_result.shape[0]
                if diff_count > 0:
                    df_list.append(df_result)

        if len(df_list) > 0:
            merged_dfs = pd.concat(df_list)

            with allure.step(f"Write result to File:"):
                res_col = f"{TableGenColNames.RES_COMPARISON.value}_{fname}_ProcpqVsES"
                ProcessCalls().writeResultToFile(merged_dfs, res_col, job_id, WorkFlowType.Quantexa.value)

        softerror.add_to_infolist(f"Total Records validated in PROC PQ {total_scanned_records_in_proc_pq}")
        softerror.add_to_infolist(f"Total Records validated in Quantexa {total_scanned_records_in_es}")
        softerror.log_all_error_to_report()
