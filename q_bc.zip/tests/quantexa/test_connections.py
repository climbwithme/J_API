import urllib3
import allure
from config_rules import TableGenColNames, TableJobs

from config_test import TestConfig
from systems.connections.esconnection import EsConnection
from systems.reusables.awscommons import AwsCommons
from systems.reusables.commons import Commons
from systems.reusables.processcalls import ProcessCalls
from systems.reusables.sqlcommons import SqlCommons
from tests.base_fix import BaseFix

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class TestConnections(BaseFix):

    @allure.suite("Connectivity Tests")
    @allure.feature("Connectivity Tests")
    @allure.tag("AWS")
    @allure.severity(allure.severity_level.BLOCKER)
    @allure.description("AWS Connection & retrieve the list of buckets")
    def test_aws_connection(self):

        with allure.step("Create a AWS conection"):
            aws = AwsCommons()
            response = aws.get_list_of_buckets()
            Commons().attachjson_to_allure_astextfile(response, name_to_appear='Bucket List Response')
    
    
    @allure.suite("Connectivity Tests")
    @allure.feature("Connectivity Tests")
    @allure.tag("Elasticsearch")
    @allure.severity(allure.severity_level.BLOCKER)
    @allure.description("Connect to Elastic Search")
    def test_es_connection(self, job_id):
        with allure.step("Create a Elastic Search conection"):
            sql = SqlCommons(TableJobs.QUANTEXA.value)
            ProcessCalls().check_skip_tests(job_id, sql, TableGenColNames.VAL_ES.value)

            index_name = sql.getColumnValue(job_id, TableGenColNames.ES_INDEX.value)
            proc_env = sql.getColumnValue(job_id, TableGenColNames.Q_BUCKET_PROCPQ.value)
            if proc_env.endswith("nft"):
                environment = "NFT"
            else:
                environment = "SIT"

            es = EsConnection(index_name, environment)
            es.setPaymentPayload()
            result = es.post_payment_request(path_value=TestConfig.ES_INDEX_NAME, write_file=False)
            Commons().attachjson_to_allure_astextfile(result, name_to_appear='Elasticsearch API Response')