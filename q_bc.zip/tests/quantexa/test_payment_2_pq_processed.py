import urllib3
import allure
from config_rules import TableGenColNames, TableJobs

from config_general import GnConfig
from systems.reusables.awscommons import AwsCommons
from systems.reusables.commons import Commons
from systems.reusables.oscommons import OsCommons
from systems.reusables.sqlcommons import SqlCommons
from tests.base_fix import BaseFix


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class TestPaymentsProcPQ(BaseFix):
    download_file_paths = GnConfig.download_file_paths

    @allure.suite("Quantexa File Tests")
    @allure.feature("AWS Processed Flat Transactions Download")
    @allure.tag("AWS", "PMT - Flat Transactions")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.description("Retrieve the Processed Payment PARQUET Files")
    def test_processed_pq_downloads(self, job_id):
        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            sql = SqlCommons(TableJobs.QUANTEXA.value)
            bucket = sql.getColumnValue(job_id, TableGenColNames.Q_BUCKET_PROCPQ.value)
            prefix = sql.getColumnValue(job_id, TableGenColNames.Q_PROCPQ.value)
            storage_path_target = OsCommons().getQuantexaPaths(job_id, GnConfig.processed_pq_storage_path, create=True)

        with allure.step("Pull Processed Parquet data From AWS S3"):
            print(bucket, prefix, storage_path_target)
            aws_commons = AwsCommons()
            response = aws_commons.get_list_of_objects(bucket, prefix)
            aws_commons.download_files_from_aws(bucket, response, storage_path_target, endswith=".parquet")
            Commons().attachjson_to_allure_astextfile(response, name_to_appear="AWS Client Response")
