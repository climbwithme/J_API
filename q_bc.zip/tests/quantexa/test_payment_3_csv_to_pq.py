import dask.dataframe as dd
import allure

from config_general import GnConfig
from systems.reusables.oscommons import OsCommons
from tests.base_fix import BaseFix


class TestPaymentCsvToPq(BaseFix):
    @allure.suite("Quantexa File Tests")
    @allure.feature("CSV Files to Parquet")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.tag("CSV -> Parquet")
    def test_csv_pq_conversion(self, job_id, q_source_csv):
        allure.dynamic.description(f"Convert all CSV Files")

        read_file_path = OsCommons().getQuantexaPaths(job_id, GnConfig.csv_storage_path)
        write_file_path = OsCommons().getQuantexaPaths(job_id, GnConfig.converted_csv_file_path, create=True)

        with allure.step(f"Convert all {q_source_csv} files From CSV -> Parquet"):

            blocksize = GnConfig.PQ_PARTITION_SIZE
            csv_df = dd.read_csv(
                f"{read_file_path}/{q_source_csv}",
                sep=GnConfig.SEP_PAYMENT,
                engine="python",
                dtype="object",
                blocksize=blocksize
            )

            # csv_df.repartition(partition_size=GnConfig.PQ_PARTITION_SIZE)
            
            csv_df.to_parquet(
                f'{write_file_path}/{q_source_csv.split(".")[0]}.parquet',
                engine="pyarrow",
                compression="snappy",
            )
