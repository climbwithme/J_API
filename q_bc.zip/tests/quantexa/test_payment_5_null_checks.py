import pandas as pd
import allure
import os
from config_rules import InternalWF, TableGenColNames, TableJobs

from config_general import GnConfig, WorkFlowType
from systems.reusables.oscommons import OsCommons
from systems.reusables.processcalls import ProcessCalls
from systems.reusables.rulecommons import RuleCommons
from systems.reusables.softerror import SoftError
from systems.reusables.sqlcommons import SqlCommons
from tests.base_fix import BaseFix


class TestPaymentNullChecks(BaseFix):
    @allure.suite("Quantexa File Tests")
    @allure.feature("RAW CSV - Mandatory Checks Checks")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.tag("CSV", "NULL_CHECK")
    @allure.description("Null value check on the configured mandatory values")
    def test_csv_null_check(self, q_source_csv, job_id):
        softerror = SoftError()

        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            table_job = TableJobs.QUANTEXA.value

            sql = SqlCommons(table_job)
            ProcessCalls().check_skip_tests(job_id, sql, TableGenColNames.VAL_MANDATORY.value)
            module = sql.getColumnValue(job_id, TableGenColNames.MODULE.value)
            print(q_source_csv, job_id)
            fname = q_source_csv.split(".")[0]

            csv_pq_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.mapped_raw_pq_path)
            proc_pq_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.mapped_proc_pq_path)

        with allure.step(f"Get Module Rules For: {module}"):
            if module == InternalWF.PAYMENTS.value:
                table_name = RuleCommons.get_db_name_quantexa(q_source_csv)
            else:
                table_name = RuleCommons.get_db_name_internal(module)
            target_col_name = TableGenColNames.Q_PQ.value
            columns_to_validate = RuleCommons.test_mandatory_fields(target_col_name, table_name)

        print(columns_to_validate, table_name)

        with allure.step(f"Read the File under validation: {q_source_csv} - Rules - {table_name}"):
            total_records = 0
            processed_file_list = []
            file_list = []
            src_path = f"{csv_pq_file_paths}\\{fname}.parquet\\"
            counter = 0
            fail_count = 0
            for csv_file_name_pq in os.listdir(src_path):
                if csv_file_name_pq.endswith(".parquet"):
                    file_list.extend(csv_file_name_pq)
                    local_path = f"{src_path}{csv_file_name_pq}"
                    df = pd.read_parquet(local_path)
                    total_records += df.shape[0]
                    df_result = ProcessCalls().check_mandatory_in_df(df, target_col_name, table_name, softerror, fname=q_source_csv, silent = True)
                    res_col = f'{TableGenColNames.RES_MANDATORY.value}_{fname}_{counter}'
                    if df_result.shape[0] > 0:
                        ProcessCalls().writeResultToFile(df_result, res_col, job_id, WorkFlowType.Quantexa.value, append_data=True)
                        counter+=1
                        fail_count+=df_result.shape[0]
                    processed_file_list.extend(csv_file_name_pq)
        
        if len(processed_file_list) == 0:
            softerror.add_to_error("No Files were processed in this test")
        if len(processed_file_list) != len(file_list):
            softerror.add_to_error("Mismatch in the process - Not all files were analyzed for the provided validations")

        if fail_count > 0:
            softerror.add_to_error("Mandatory Field validations Failed")

        print(total_records)

        softerror.log_all_error_to_report()
