import pandas as pd
import dask.dataframe as dd
import allure
import os

from pandas import DataFrame

from config_rules import InternalRE, InternalWF, PaymentFields, PaymentTypes, TableGenColNames, TableJobs
from config_general import GnConfig
from systems.connections.esconnection import EsConnection
from systems.reusables.oscommons import OsCommons
from systems.reusables.sqlcommons import SqlCommons
from tests.base_fix import BaseFix
from systems.reusables.processcalls import ProcessCalls

class TestPaymentDataMapping(BaseFix):
    @allure.suite("Quantexa File Tests")
    @allure.feature("CSV Parquet -> RAW Parquet Mapping")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.tag("CSV -> Parquet Mapping")
    @allure.description("Map CSV to Raw Parquet")
    def test_csv_raw_pq_mapping(self, job_id, source_csv_in_pq):

        with allure.step(f"Setup Job configuration for - {job_id}"):
            sql = SqlCommons(TableJobs.QUANTEXA.value)
            module = sql.getColumnValue(job_id, TableGenColNames.MODULE.value)
            if module == InternalWF.PAYMENTS.value:
                if "_PMT" in source_csv_in_pq:
                    table_name = InternalRE.PAYMENTS_PMT.value
                else:
                    table_name = InternalRE.PAYMENTS_NAD.value
            
            csv_pq_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.converted_csv_file_path, create=True)
            pq_report_storage_path = OsCommons().getQuantexaPaths(job_id, GnConfig.parquet_storage_path, create=True)
            write_file_path = OsCommons().getQuantexaPaths(job_id, GnConfig.mapped_raw_pq_path, create=True)
            key = sql.getPrimaryKey(table_name)

        with allure.step(f"RAW Parquet Mapping:"):
            for filename in os.listdir(csv_pq_file_paths):
                pq_df = dd.read_parquet(f"{pq_report_storage_path}/{filename}/*.parquet")
                if filename == source_csv_in_pq:
                    file_path = f"{csv_pq_file_paths}\{filename}"
                    for file in os.listdir(file_path):
                        df = pd.read_parquet(f"{file_path}\{file}")
                        print(f'First 10 Primary Key values {df[key].unique()[0:10]}')
                        list_of_paymn_unique = df[key].unique()
                        filtered_pq_df : DataFrame = pq_df[pq_df[key].isin(list_of_paymn_unique)]
                        OsCommons().create_path(f"{write_file_path}/{filename}")
                        raw_pq_name = f"{write_file_path}/{filename}/{file}"
                        filtered_pq_df = filtered_pq_df.compute()
                        filtered_pq_df.to_parquet(raw_pq_name)
                        print(f"\tFiltered RAW Parquet size for {filename} {file} {filtered_pq_df.shape[0]} / {df.shape[0]}")

    @allure.suite("Quantexa File Tests")
    @allure.feature("CSV Parquet -> Processed Parquet Mapping")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.tag("CSV -> Processed Parquet Mapping")
    @allure.description("Map CSV to Processed Parquet")
    def test_csv_proc_pq_mapping(self, job_id, source_csv_in_pq):

        with allure.step(f"Setup Job configuration for - {job_id}"):
            sql = SqlCommons(TableJobs.QUANTEXA.value)
            module = sql.getColumnValue(job_id, TableGenColNames.MODULE.value)
            if module == InternalWF.PAYMENTS.value:
                if "_PMT" in source_csv_in_pq:
                    table_name = InternalRE.PAYMENTS_PMT.value
                else:
                    table_name = InternalRE.PAYMENTS_NAD.value
            csv_pq_file_paths = OsCommons().getQuantexaPaths(job_id, GnConfig.converted_csv_file_path, create=True)
            pq_report_storage_path = OsCommons().getQuantexaPaths(job_id, GnConfig.processed_pq_storage_path, create=True)
            write_file_path = OsCommons().getQuantexaPaths(job_id, GnConfig.mapped_proc_pq_path, create=True)
            key = sql.getPrimaryKey(table_name)

            
            pq_df = dd.read_parquet(f"{pq_report_storage_path}/FlatTransaction.parquet/*.parquet")

        with allure.step(f"Processed Parquet Mapping:"):
            for filename in os.listdir(csv_pq_file_paths):
                if filename == source_csv_in_pq:
                    file_path = f"{csv_pq_file_paths}\{filename}"
                    for file in os.listdir(file_path):
                        print(filename, f"{pq_report_storage_path}/FlatTransaction.parquet/*.parquet")
                        payment_type = filename.split('_')[1]
                        if payment_type == PaymentTypes.PMTR.value or  payment_type == PaymentTypes.NADR.value:
                            suffix = "RBS"
                        elif payment_type == PaymentTypes.PMTN.value or  payment_type == PaymentTypes.NADN.value:
                            suffix = "NWB"
                        else:
                            suffix = "QMU"
                        if payment_type.startswith("P"):
                            acc_type = PaymentFields.IFPAY_ACCTING_TYPE.value
                        else:
                            acc_type = PaymentFields.IFNAD_ACCTING_TYPE.value
                        
                        print(suffix, acc_type)

                        with allure.step(f"Reading parquet file - {filename} and saving as a dataframe"):
                            df = pd.read_parquet(f"{file_path}\{file}")
                            # df = pd.read_parquet(f"{csv_pq_file_paths}\{filename}")
                            trans_id = (
                                df[key].astype(str)
                                + df[acc_type].astype(str)
                                + suffix
                            )
                            trans_id.name = PaymentFields.TRANSACTION_ID.value
                            list_of_transid_unique = trans_id.unique()
                            print(list_of_transid_unique[0:10])
                            with allure.step(f"Mapping the RAW Parquet file corresponding to {filename}"):
                                filtered_pq_df = pq_df[pq_df[PaymentFields.TRANSACTION_ID.value].isin(list_of_transid_unique)]

                                # filtered_pq_df = filtered_pq_df.dropna(how="all")
                                # filtered_pq_df = filtered_pq_df.repartition(partition_size=GnConfig.PQ_PARTITION_SIZE)
                                OsCommons().create_path(f"{write_file_path}/{filename}")
                                proc_pq_name = f"{write_file_path}/{filename}/{file}"
                                filtered_pq_df = filtered_pq_df.compute()      
                                filtered_pq_df.to_parquet(proc_pq_name)
                                print(f"\tFiltered RAW Parquet size for {filename} {file} {filtered_pq_df.shape[0]} / {df.shape[0]}")
                                

    @allure.feature("CSV Parquet -> Elasticsearch Data Mapping")
    @allure.suite("CSV Parquet -> Elasticsearch Data Mapping")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.tag("CSV -> Elasticsearch Data Mapping")
    @allure.description("Map CSV to Elasticsearch Data")
    def test_csv_es_data_mapping(self, job_id, source_csv_in_pq):

        sql = SqlCommons(TableJobs.QUANTEXA.value)
        ProcessCalls().check_skip_tests(job_id, sql, TableGenColNames.VAL_ES.value)

        mapped_proc_pq_path = OsCommons().getQuantexaPaths(job_id, GnConfig.mapped_proc_pq_path, create=True)
        elasticsearch_storage_path = OsCommons().getQuantexaPaths(job_id, GnConfig.elasticsearch_storage_path, create=True)
        
        index_name = sql.getColumnValue(job_id, "elastic_index")


        proc_env = sql.getColumnValue(job_id, TableGenColNames.Q_BUCKET_PROCPQ.value)
        if proc_env.endswith("nft"):
            environment = "NFT"
        else:
            environment = "SIT"

        print(f'SRC: {source_csv_in_pq}')
        print(f'ENV: {environment}')

        esconnecton = EsConnection(index_name, environment)
                            
        for fn in os.listdir(mapped_proc_pq_path):
            if fn.endswith(".parquet") and source_csv_in_pq in fn:
                for filename in os.listdir(f"{mapped_proc_pq_path}/{fn}"):
                    if filename.endswith(".parquet"):
                        with allure.step(f"Reading parquet file - {filename}/{fn} and downloading data from Elasticsearch"):
                            pq_file_name = f"{mapped_proc_pq_path}\{fn}\{filename}"
                            print(filename, fn, pq_file_name)
                            df = dd.read_parquet(pq_file_name)
                            list_of_transid_unique = df["TRANSACTION_ID"].unique().compute()
                            list_of_transid_unique = set(list_of_transid_unique)
                            file_ref = f'{fn.split(".")[0]}'

                            OsCommons().delete_and_create_path(f"{elasticsearch_storage_path}/{file_ref}")
                            print(f"\tLength of Transaction IDs in Processed Parquet file for {file_ref} - {len(list_of_transid_unique)}")
                            esconnecton.setPaymentPayload(list(list_of_transid_unique))
                            esconnecton.post_payment_request(
                                path_value=f"{elasticsearch_storage_path}/{file_ref}",
                                file_name=filename,
                            )
