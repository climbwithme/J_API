import allure
import urllib3
from config_rules import TableGenColNames, TableJobs
from systems.reusables.awscommons import AwsCommons
from systems.reusables.oscommons import OsCommons

from systems.reusables.sqlcommons import SqlCommons
from config_general import WorkFlowType
from tests.base_fix import BaseFix

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class TestFilePull(BaseFix):

    @allure.suite("Internal File Tests")
    @allure.feature("AWS CSV File Download")
    @allure.severity(allure.severity_level.BLOCKER)
    @allure.description("Retrieve the CSV Files with API key from AWS")
    def test_csv_downloads(self, job_id):

        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            sql = SqlCommons(TableJobs.INTERNAL.value)
            bucket_target_csv = sql.getColumnValue(job_id, 'bucket_target_csv')
            csv_lists = sql.getColumnValue(job_id, TableGenColNames.IN_TARGET_CSV.value)[1:-1].split(', ')
            storage_path_target = OsCommons().gettargetCSVPath(WorkFlowType.Internal, job_id, create=True)

        with allure.step(f"Downloading Files from AWS from {bucket_target_csv}"):
            aws_commons = AwsCommons()
            for csv_file in csv_lists:
                csv_file = csv_file[1:-1]
                csv_file = csv_file.replace("'", "")
                print(f"Downloading Target CSV file {csv_file}")
                with allure.step(f"Downloading Target CSV file {csv_file}"):
                    print(bucket_target_csv, csv_file, storage_path_target)
                    aws_commons.download_particular_csv_file(bucket_target_csv, csv_file, storage_path_target)

