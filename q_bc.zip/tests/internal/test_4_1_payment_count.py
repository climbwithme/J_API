import os
import allure
import urllib3
import pytest
from config_rules import PaymentFields, PaymentTypes, TableGenColNames
from systems.reusables.dfcommons import DfCommons
from systems.reusables.oscommons import OsCommons
from systems.reusables.processcalls import ProcessCalls
from systems.reusables.softerror import SoftError
from config_general import GnConfig, WorkFlowType
from tests.base_fix import BaseFix

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class TestCountCheckPayment(BaseFix):
    @allure.suite("Internal File Tests")
    @allure.feature("Payment Files Total Records Count")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.description("Validate Hive vs AWS Data of Payments")
    def test_payment_counts(self, job_id, payment_type: PaymentTypes):
        softerror = SoftError()

        hive_source_path = OsCommons().gettargetHivePath(WorkFlowType.Internal, job_id)
        storage_path_target = OsCommons().gettargetCSVPath(WorkFlowType.Internal, job_id, create=True)

        print(f"Source: {hive_source_path}")
        print(f"Target: {storage_path_target}")

        target_count_of_rows = 0
        files_validated = 0

        for file in os.listdir(storage_path_target):
            if payment_type.value in file:
                files_validated += 1
                with allure.step(f"Reading Target File {file} & getting count of row"):
                    df_target = DfCommons.readCsvAsPd(f"{storage_path_target}{file}", sep=GnConfig.SEP_PAYMENT)
                    file_row_count = DfCommons.getNumberOfRows(df_target)
                    target_count_of_rows += file_row_count
                    print(f"\t {file} - Total Rows {file_row_count}")

                    paymn_list = DfCommons.getUniqueValues(df_target, PaymentFields.PAYMN_NUMBER.value)
                    if len(paymn_list) == file_row_count:
                        softerror.add_to_passlist(f"{file} has all unique PAYMN NUMBERS - Total {file_row_count}")
                    else:
                        softerror.add_to_error(f"{file} has duplicate PAYMN NUMBERS")

                print(f"Total Rows in target {payment_type.value} is {target_count_of_rows}")

                with allure.step(f"Reading Hive Output for {payment_type.value} & getting count of row"):
                    path_in_source = f"{hive_source_path}consolidated_{payment_type.value}.csv"
                    df_src = DfCommons.readCsvAsPd(path_in_source)
                    source_count_of_rows = DfCommons.getNumberOfRows(df_src)

                print(f"Total Rows in hive {payment_type.value} is {source_count_of_rows}")

                with allure.step(f"Count Comparison {payment_type.value}"):
                    (count_src, count_target) = DfCommons.compareCountTwoDataframes(df_src, df_target, softerror)

                with allure.step(f"Write result to File:"):
                    result_dict = [
                            {"name": f"{payment_type.value}___Source Data", "value": count_src},
                            {"name": f"{payment_type.value}___Target Data", "value": count_target},
                    ]
                    res_col = TableGenColNames.RES_COUNT.value
                    ProcessCalls().writeJsonToFile(result_dict, res_col, job_id, WorkFlowType.Internal.value, append_data=True)

        if files_validated == 0:
            pytest.skip("No Files to be validated")
        # if source_count_of_rows != target_count_of_rows:
        #     fail_msg = f"Count Mismatch Found for {payment_type}"
        #     softerror.add_to_error(fail_msg)
        # else:
        #     softerror.add_to_passlist(f"All Records matched - {target_count_of_rows}")

        softerror.log_all_error_to_report()

    @allure.suite("Internal File Tests")
    @allure.feature("Payment Files PAYMN NUMBER Match")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.description("Validate Hive vs AWS Data of Payments have same PAYMN Numbers")
    def test_payment_paymn_number_match(self, job_id, payment_type: PaymentTypes):
        softerror = SoftError()

        hive_source_path = OsCommons().gettargetHivePath(WorkFlowType.Internal, job_id)
        storage_path_target = OsCommons().gettargetCSVPath(WorkFlowType.Internal, job_id, create=True)

        print(f"Source: {hive_source_path}")
        print(f"Target: {storage_path_target}")

        target_paymn_numbers = []
        files_validated = 0

        for file in os.listdir(storage_path_target):
            if payment_type.value in file:
                files_validated += 1
                with allure.step(f"Reading Target File {file} & getting count of row"):
                    df = DfCommons.readCsvAsPd(f"{storage_path_target}{file}", sep=GnConfig.SEP_PAYMENT)
                    paymn_list = DfCommons.getUniqueValues(df, PaymentFields.PAYMN_NUMBER.value)
                    target_paymn_numbers.extend(paymn_list)

                with allure.step(f"Reading Hive Output for {file} & getting count of row"):
                    path_in_source = f"{hive_source_path}consolidated_{payment_type.value}.csv"
                    df = DfCommons.readCsvAsPd(path_in_source)

                if set(paymn_list) == set(target_paymn_numbers):
                    softerror.add_to_passlist(
                        f"Both Source and Target had the same PAYMN NUMBER List - Total {len(target_paymn_numbers)}"
                    )
                else:
                    fail_msg = f"PAYMN NUMBER has mismatch in this {payment_type.value} File"
                    softerror.add_to_error(fail_msg)
        if files_validated == 0:
            pytest.skip("No Files to be validated")

        softerror.log_all_error_to_report()
