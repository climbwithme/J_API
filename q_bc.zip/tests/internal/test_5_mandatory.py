import pytest
import allure
import urllib3
import pandas as pd
import os
from config_rules import InternalRE, InternalWF, TableGenColNames, TableJobs
from systems.reusables.dfcommons import DfCommons
from systems.reusables.oscommons import OsCommons
from systems.reusables.processcalls import ProcessCalls

from systems.reusables.rulecommons import RuleCommons
from systems.reusables.sqlcommons import SqlCommons
from systems.reusables.softerror import SoftError
from systems.reusables.commons import Commons
from config_general import GnConfig, WorkFlowType
from tests.base_fix import BaseFix

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class TestMandatory(BaseFix):
    @allure.suite("Internal File Tests")
    @allure.feature("Test Mandatory Fields")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.description("Validate Mandatory fields in the Target CSV")
    def test_external_mandatory(self, job_id, internal_target_csv):

        softerror = SoftError()

        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            sql = SqlCommons(TableJobs.INTERNAL.value)
            ProcessCalls().check_skip_tests(job_id, sql, TableGenColNames.VAL_MANDATORY.value)

            module = sql.getColumnValue(job_id, TableGenColNames.MODULE.value)

            storage_path_target = OsCommons().gettargetCSVPath(WorkFlowType.Internal, job_id)

        with allure.step(f"Get Module Rules For: {module}"):
            if module == InternalWF.PAYMENTS.value:
                table_name = RuleCommons.get_db_name_quantexa(internal_target_csv)
            else:
                table_name = RuleCommons.get_db_name_internal(module)
            target_col_name = TableGenColNames.IN_SOURCE.value

        with allure.step(f"Read the File under validation: {internal_target_csv} - Rules - {table_name}"):
            file_path = f"{storage_path_target}{internal_target_csv}"
            df = DfCommons.readCsvAsPd(file_path, sep=GnConfig.SEP_PAYMENT, override_na=True)

        with allure.step(f"Validate Mandatory Fields: {internal_target_csv}"):
            df_result = ProcessCalls().check_mandatory_in_df(df, target_col_name, table_name, softerror, fname=internal_target_csv, silent=False)

        if df_result.shape[0] > 0:
            with allure.step(f"Write result to DB:"):
                res_col = f'{TableGenColNames.RES_MANDATORY.value}_{internal_target_csv}'
                ProcessCalls().writeResultToFile(df_result, res_col, job_id, WorkFlowType.Internal.value, append_data=True)

        softerror.log_all_error_to_report()
