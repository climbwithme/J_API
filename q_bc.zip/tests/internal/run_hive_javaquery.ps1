

$currentDirectory = Get-Location
$job_id=$args[0]
$module=$args[1]
$filter_start_date=$args[2]
$filter_end_date=$args[3]


Write-Host "Current Directory: $currentDirectory"
Write-Host "Job ID: $job_id"

$output_path = './app/static/py_reports/internal/' + $job_id

New-Item -ItemType Directory -Path $output_path -ErrorAction SilentlyContinue

java -version


cd .\tests\hive\

$currentDirectory = Get-Location
Write-Host "Current Directory: $currentDirectory"

ls

java -version

javac -cp "lib\*" .\src\hive\HiveTestConnection.java
java -cp "lib\*;src" hive.HiveTestConnection $job_id $module $filter_start_date $filter_end_date

$LASTEXITCODE