import pytest
import allure
import urllib3
import pandas as pd
import os
from config_rules import (
    InternalPaths,
    InternalRE,
    InternalWF,
    PaymentFields,
    PaymentMapping,
    TableGenColNames,
    TableJobs,
)
from systems.reusables.dfcommons import DfCommons
from systems.reusables.oscommons import OsCommons
from systems.reusables.processcalls import ProcessCalls

from systems.reusables.rulecommons import RuleCommons
from systems.reusables.sqlcommons import SqlCommons
from systems.reusables.softerror import SoftError
from systems.reusables.commons import Commons
from config_general import GnConfig, WorkFlowType
from tests.base_fix import BaseFix

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class TestComparison(BaseFix):
    @allure.feature("Test Field Comparison")
    @allure.suite("Internal File Tests")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.description("Test Field comparison between Hive Query CSV and Target CSVs")
    def test_internal_compare(self, job_id, internal_target_csv):
        softerror = SoftError()

        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            sql = SqlCommons(TableJobs.INTERNAL.value)
            ProcessCalls().check_skip_tests(job_id, sql, TableGenColNames.VAL_COMPARISON.value)
            module = sql.getColumnValue(job_id, TableGenColNames.MODULE.value)

            ftype = internal_target_csv.split("_")[1]
            storage_path_target = OsCommons().gettargetCSVPath(WorkFlowType.Internal, job_id)
            storage_source_target = OsCommons().gettargetHivePath(WorkFlowType.Internal, job_id)
            source_file_name = f"{storage_source_target}consolidated_{ftype}.csv"
            target_file_name = f"{storage_path_target}{internal_target_csv}"

        with allure.step(f"Get Module Rules For: {module}"):
            if module == InternalWF.PAYMENTS.value:
                if "_PMT" in internal_target_csv:
                    table_name = InternalRE.PAYMENTS_PMT.value
                else:
                    table_name = InternalRE.PAYMENTS_NAD.value
            compare_cols_source = RuleCommons.get_comparison_fields(TableGenColNames.IN_SOURCE.value, table_name)
            compare_cols_target = RuleCommons.get_comparison_fields(TableGenColNames.IN_SOURCE.value, table_name)

        with allure.step(f"Read the Source File under validation: {source_file_name} - Rules - {table_name}"):
            df_src = ProcessCalls().getDfFromPath_ForInternal(
                source_file_name,
                module,
                InternalPaths.HIVE_SRC,
                compare_cols_source,
            )

        with allure.step(f"Read the Target File under validation: {target_file_name} - Rules - {table_name}"):
            df_target = ProcessCalls().getDfFromPath_ForInternal(
                target_file_name,
                module,
                InternalPaths.SOURCE,
                compare_cols_target,
            )

        with allure.step(f"Compare two Data frames - External Source vs Target"):
            compare_columns = RuleCommons.get_comparison_fields_native(table_name)
            df_result = ProcessCalls().compareTwoDataFrames(
                df_src,
                df_target,
                compare_columns,
                table_name,
                sql,
                softerror,
                file_name=internal_target_csv,
                suffix_x="_hive_data",
                suffix_y="target_csv",
            )

        if df_result.shape[0] > 0:
            with allure.step(f"Write result to File:"):
                res_col = f'{TableGenColNames.RES_COMPARISON.value}_{internal_target_csv}'
                ProcessCalls().writeResultToFile(df_result, res_col, job_id, WorkFlowType.Internal.value)

        softerror.log_all_error_to_report()
