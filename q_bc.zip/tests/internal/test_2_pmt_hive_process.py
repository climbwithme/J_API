import allure
import urllib3
import pandas as pd
import dask.dataframe as dd
from config_rules import PaymentFields, PaymentMapping, PaymentTypes

from systems.reusables.oscommons import OsCommons
from config_general import WorkFlowType
from systems.reusables.processcalls import ProcessCalls
from tests.base_fix import BaseFix

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class TestHiveProcess(BaseFix):

    @allure.suite("Internal File Tests")
    @allure.feature("Process Hive downloaded ISO CSV File")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.description("Process the ISO File to Comparable format of AWS Processed Data")
    def test_hive_iso_extract(self, job_id, payment_type: PaymentTypes):
        
        with allure.step(f"Load ISO CSV File From Hive"):
            storage_path_target = OsCommons().gettargetHivePath(WorkFlowType.Internal, job_id)
            if payment_type.value.startswith('PMT'):
                path_src = storage_path_target + 'ISO_PMT_Query.csv'
                payment_mapping = PaymentMapping.MAPPING_DICT_ISO_PMT
                filt_cols = PaymentMapping.FIELD_LIST_PMT
            else:
                path_src = storage_path_target + 'ISO_NAD_Query.csv'
                payment_mapping = PaymentMapping.MAPPING_DICT_ISO_NAD
                filt_cols = PaymentMapping.FIELD_LIST_NAD
            df = dd.read_csv(path_src, encoding='ISO-8859-1', engine="python", dtype="object")

        with allure.step(f"Filter Data With Payment Type {payment_type.value}"):
            df = df[list(payment_mapping.keys())]
            df = ProcessCalls().renamePaymentDf(df, payment_mapping)
            storage_path = storage_path_target + f'HIVE_ISO_{payment_type.value}.csv'

            if payment_type == PaymentTypes.PMTN or payment_type == PaymentTypes.NADN:
                df_filt_pmt = df[df[PaymentFields.SERVICING_FIN_INSTN.value].isin(PaymentMapping.NWB_LIST_ISO)]
            elif payment_type == PaymentTypes.PMTR or payment_type == PaymentTypes.NADR:
                df_filt_pmt = df[df[PaymentFields.SERVICING_FIN_INSTN.value].isin(PaymentMapping.RBS_LIST_ISO)]
            else:
                df_filt_pmt = df[df[PaymentFields.SERVICING_FIN_INSTN.value].isin(PaymentMapping.UB_LIST_ISO)]
        
        with allure.step(f"Write Filtered Data to Storage Path {storage_path}"):
            df_filt_pmt = df_filt_pmt[filt_cols]
            df_result = df_filt_pmt.compute()
            df_result.to_csv(storage_path, index=False)


    @allure.suite("Internal File Tests")
    @allure.feature("Process Hive downloaded NON ISO CSV File")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.description("Process the NON ISO File to Comparable format of AWS Processed Data")
    def test_hive_noniso_extract(self, job_id, payment_type: PaymentTypes):


        with allure.step(f"Load Non ISO CSV File From Hive"):
            storage_path_target = OsCommons().gettargetHivePath(WorkFlowType.Internal, job_id)
            non_iso = storage_path_target + 'NON_ISO_Query.csv'
            df = dd.read_csv(non_iso, encoding='ISO-8859-1', engine="python", dtype="object")
            df = df[list(PaymentMapping.NON_ISO_MAPPING_DICT.keys())]
            df = df.rename(columns=PaymentMapping.NON_ISO_MAPPING_DICT)

        with allure.step(f"Filter Data With Payment Type {payment_type.value}"):
            if payment_type.value.startswith('PMT'):
                payment_mapping = PaymentMapping.FIELD_LIST_PMT
            else:
                payment_mapping = PaymentMapping.FIELD_LIST_NAD
            storage_path = storage_path_target + f'HIVE_NONISO_{payment_type.value}.csv'

            if payment_type == PaymentTypes.PMTN or payment_type == PaymentTypes.NADN:
                df_filt_pmt = df[df[PaymentFields.SERVICING_FIN_INSTN.value].isin(PaymentMapping.NWB_LIST_NONISO)]
            elif payment_type == PaymentTypes.PMTR or payment_type == PaymentTypes.NADR:
                df_filt_pmt = df[df[PaymentFields.SERVICING_FIN_INSTN.value].isin(PaymentMapping.RBS_LIST_NONISO)]
            else:
                df_filt_pmt = df[df[PaymentFields.SERVICING_FIN_INSTN.value].isin(PaymentMapping.UB_LIST_NONISO)]

        with allure.step(f"Write Filtered Data to Storage Path {storage_path}"):
            df_filt_pmt = df_filt_pmt[payment_mapping]
            df_result = df_filt_pmt.compute()
            df_result.to_csv(storage_path, index=False)


    @allure.suite("Internal File Tests")
    @allure.feature("Consolidate ISO & Non ISO Data")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.description("Concatenate ISO & Non ISO Data")
    def test_hive_report_consolidation(self, job_id, payment_type: PaymentTypes):
        
        with allure.step(f"Consolidate ISO, Non ISO CSV File From Extracted File"):
            storage_path_target = OsCommons().gettargetHivePath(WorkFlowType.Internal, job_id)
            pmt_value = payment_type.value
            files = [f'HIVE_ISO_{pmt_value}.csv', f'HIVE_NONISO_{pmt_value}.csv']

            df_1 = pd.read_csv(f'{storage_path_target}{files[0]}', encoding='ISO-8859-1')
            df_2 = pd.read_csv(f'{storage_path_target}{files[1]}', encoding='ISO-8859-1')
            df = pd.concat([df_1, df_2])
            print(f'Original Row Counts - {df_1.shape[0]} & {df_2.shape[0]}')
            print(f'{pmt_value} Total Rows - {df.shape[0]}')

            df.to_csv(f'{storage_path_target}consolidated_{pmt_value}.csv', index=False)
