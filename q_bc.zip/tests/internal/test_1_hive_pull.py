import allure
import urllib3
import os
import subprocess
from config_rules import TableGenColNames, TableJobs

from systems.reusables.oscommons import OsCommons
from systems.reusables.softerror import SoftError
from systems.reusables.sqlcommons import SqlCommons
from config_general import GnConfig, WorkFlowType
from tests.base_fix import BaseFix

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class TestHivePull(BaseFix):

    @allure.suite("Internal File Tests")
    @allure.feature("Hive CSV File Download")
    @allure.severity(allure.severity_level.CRITICAL)
    @allure.description("Retrieve the CSV Files with Kerberos Authentication from Hive")
    def test_hive_query_downloads(self, job_id):
        softerror = SoftError()

        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            sql = SqlCommons(TableJobs.INTERNAL.value)
            module = sql.getColumnValue(job_id, TableGenColNames.MODULE.value)
        
        with allure.step(f"Get Module Rules For: {module}"):
            path = os.path.join(os.path.abspath(os.path.dirname(__file__)), "run_hive_javaquery.ps1")
            filter_start_date = sql.getColumnValue(job_id, TableGenColNames.IN_FIL_ST_DT.value)
            filter_end_date = sql.getColumnValue(job_id, TableGenColNames.IN_FIL_ED_DT.value)

        with allure.step(f"Trigger the Command: {module}"):
            cmd = [
                "powershell.exe",
                "-ExecutionPolicy",
                "Unrestricted",
                "-File",
                path,
                str(job_id),
                module,
                f"'{filter_start_date}'",
                f"'{filter_end_date}'",
            ]
            print(f'Command to invoke script: {cmd}')

        with allure.step(f"Creating necessary paths for logs and reports"):
            job_path = f"files//{WorkFlowType.Internal.value}//{job_id}"
            OsCommons().create_path(job_path)
            log_file = f"{job_path}//hive_logs.txt"
            log_error_file = f"{job_path}//hive_log_errors.txt"
        
        with allure.step(f"Calling JAVA Program to run Hive queries"):
            with open(log_file, "w") as log_file, open(log_error_file, "w") as log_error_file:
                process = subprocess.Popen(cmd, stdout=log_file, stderr=log_error_file)
            output = process.communicate()[0]
            exit_code = process.wait()

        if exit_code==0:
            softerror.add_to_passlist('JAVA program ran successful for Hive Queries')
        else:
            softerror.add_to_error(f'Process ended with error code {exit_code}')