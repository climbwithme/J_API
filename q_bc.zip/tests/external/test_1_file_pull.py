import allure
import urllib3
from config_rules import TableGenColNames, TableJobs
from systems.reusables.awscommons import AwsCommons
from systems.reusables.oscommons import OsCommons

from systems.reusables.sqlcommons import SqlCommons
from systems.reusables.commons import Commons
from config_general import WorkFlowType
from tests.base_fix import BaseFix

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class TestFilePull(BaseFix):
    @allure.suite("External File Tests")
    @allure.feature("AWS CSV File Download")
    @allure.severity(allure.severity_level.BLOCKER)
    @allure.description("Retrieve the CSV Files with API key from AWS")
    def test_csv_downloads(self, job_id):
        sql = SqlCommons(TableJobs.EXTERNAL.value)

        bucket_source_csv = sql.getColumnValue(
            job_id, TableGenColNames.BUCKET_SOURCE_CSV.value
        )
        bucket_target_csv = sql.getColumnValue(
            job_id, TableGenColNames.BUCKET_TARGET_CSV.value
        )

        source_csv = sql.getColumnValue(job_id, TableGenColNames.SOURCE_CSV.value)
        target_csv = sql.getColumnValue(job_id, TableGenColNames.TARGET_CSV.value)

        print(bucket_source_csv, bucket_target_csv)
        print(source_csv, target_csv)

        storage_path_src = OsCommons().getsourceCSVPath(
            WorkFlowType.External, job_id, create=True
        )
        storage_path_target = OsCommons().gettargetCSVPath(
            WorkFlowType.External, job_id, create=True
        )

        aws_commons = AwsCommons()
        with allure.step(f"Downloading Source CSV"):
            aws_commons.download_particular_csv_file(
                bucket_source_csv, source_csv, storage_path_src
            )
        with allure.step(f"Downloading Target CSV"):
            aws_commons.download_particular_csv_file(
                bucket_target_csv, target_csv, storage_path_target
            )
