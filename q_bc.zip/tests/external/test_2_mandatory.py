import allure
import urllib3
from config_rules import TableGenColNames, TableJobs
from systems.reusables.dfcommons import DfCommons
from systems.reusables.oscommons import OsCommons
from systems.reusables.processcalls import ProcessCalls

from systems.reusables.rulecommons import RuleCommons
from systems.reusables.sqlcommons import SqlCommons
from systems.reusables.softerror import SoftError
from config_general import WorkFlowType
from tests.base_fix import BaseFix

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class TestMandatory(BaseFix):
    @allure.suite("External File Tests")
    @allure.feature("Test Mandatory Fields")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.description("Validate Mandatory fields in the Target CSV")
    def test_external_mandatory(self, job_id):
        softerror = SoftError()

        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            target_col = TableGenColNames.TARGET_CSV.value
            sql = SqlCommons(TableJobs.EXTERNAL.value)
            ProcessCalls().check_skip_tests(job_id, sql, TableGenColNames.VAL_MANDATORY.value)

            module = sql.getColumnValue(job_id, TableGenColNames.MODULE.value)

            storage_path_target = OsCommons().gettargetCSVPath(WorkFlowType.External, job_id)
            fname = sql.getColumnValue(job_id, target_col).split("/")[-1]
            target_csv = storage_path_target + fname

        with allure.step(f"Get Module Rules For: {module}"):
            table_name = RuleCommons.get_db_name_external(module)
            target_col_name = TableGenColNames.EX_TARGET.value

        with allure.step(f"Read the File under validation: {target_csv} - Rules - {table_name}"):
            df = DfCommons.readCsvOverrideNA(target_csv)

        with allure.step(f"Validate Mandatory Fields: {target_csv}"):
            df_result = ProcessCalls().check_mandatory_in_df(df, target_col_name, table_name, softerror)

        if df_result.shape[0] > 0:
            with allure.step(f"Write result to File:"):
                res_col = TableGenColNames.RES_MANDATORY.value
                # ProcessCalls().writeResultToDB(df_result, res_col, job_id, sql)
                ProcessCalls().writeResultToFile(df_result, res_col, job_id, WorkFlowType.External.value)

        softerror.log_all_error_to_report()
