import pytest
import allure
import urllib3
import pandas as pd
import os
from config_rules import ExternalPaths, TableGenColNames, TableJobs
from systems.reusables.dfcommons import DfCommons
from systems.reusables.oscommons import OsCommons
from systems.reusables.processcalls import ProcessCalls

from systems.reusables.rulecommons import RuleCommons
from systems.reusables.sqlcommons import SqlCommons
from systems.reusables.softerror import SoftError
from systems.reusables.commons import Commons
from config_general import GnConfig, WorkFlowType
from tests.base_fix import BaseFix

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class TestComparison(BaseFix):
    @allure.feature("Test Count Check")
    @allure.suite("External File Tests")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.description("Test total records between Source and Target CSVs")
    def test_count_check(self, job_id):
        softerror = SoftError()

        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            sql = SqlCommons(TableJobs.EXTERNAL.value)
            ProcessCalls().check_skip_tests(job_id, sql, TableGenColNames.VAL_COMPARISON.value)
            module = sql.getColumnValue(job_id, TableGenColNames.MODULE.value)

            target_col = TableGenColNames.TARGET_CSV.value
            source_col = TableGenColNames.SOURCE_CSV.value

            target_csv = sql.getColumnValue(job_id, target_col).split("/")[-1]
            source_csv = sql.getColumnValue(job_id, source_col).split("/")[-1]

            storage_path_src = OsCommons().getsourceCSVPath(WorkFlowType.External, job_id)
            storage_path_target = OsCommons().gettargetCSVPath(WorkFlowType.External, job_id)
            source_csv = storage_path_src + source_csv
            target_csv = storage_path_target + target_csv

        with allure.step(f"Get Module Rules For: {module}"):
            table_name = RuleCommons.get_db_name_external(module)
            new_columns_src = RuleCommons.get_column_names_native(table_name)
            new_columns_target = RuleCommons.get_column_names_target(table_name)
            compare_columns = RuleCommons.get_comparison_fields_native(table_name)

        with allure.step(f"Read the Source File under validation: {source_csv} - Rules - {table_name}"):
            df_src = ProcessCalls().getDfFromPath_ForExternal(
                source_csv,
                module,
                ExternalPaths.SOURCE,
                new_columns_src,
                compare_columns,
            )

        with allure.step(f"Read the Target File under validation: {target_csv} - Rules - {table_name}"):
            df_target = ProcessCalls().getDfFromPath_ForExternal(
                target_csv,
                module,
                ExternalPaths.TARGET,
                new_columns_target,
                compare_columns,
            )

        with allure.step(f"Count Comparison {source_csv} vs {target_csv}"):
            (count_src, count_target) = DfCommons.compareCountTwoDataframes(df_src, df_target, softerror)

        with allure.step(f"Write result to File:"):
            result_dict = [
                [{"name": "Source Data", "value": count_src}, {"name": "Target Data", "value": count_target}]
            ]
            res_col = TableGenColNames.RES_COUNT.value
            ProcessCalls().writeJsonToFile(result_dict, res_col, job_id, WorkFlowType.External.value)

        softerror.log_all_error_to_report()
