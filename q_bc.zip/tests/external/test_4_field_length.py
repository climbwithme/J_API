import pytest
import allure
import urllib3
import pandas as pd
import json
from config_rules import TableGenColNames, TableJobs
from systems.reusables.dfcommons import DfCommons
from systems.reusables.oscommons import OsCommons
from systems.reusables.processcalls import ProcessCalls

from systems.reusables.rulecommons import RuleCommons
from systems.reusables.sqlcommons import SqlCommons
from systems.reusables.softerror import SoftError
from systems.reusables.commons import Commons
from config_general import GnConfig, WorkFlowType
from tests.base_fix import BaseFix

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class TestFieldLength(BaseFix):


    @allure.feature("Test Field's Length")
    @allure.suite("External File Tests")
    @allure.severity(allure.severity_level.NORMAL)
    @allure.description("Validate Field Length in the Target CSV")
    def test_field_length(self, job_id):
        softerror = SoftError()

        with allure.step(f"Get JOB Configurations for JOB: {job_id}"):
            target_col = TableGenColNames.TARGET_CSV.value
            sql = SqlCommons(TableJobs.EXTERNAL.value)
            ProcessCalls().check_skip_tests(job_id, sql, TableGenColNames.VAL_FIELDLENGTH.value)

            module = sql.getColumnValue(job_id, TableGenColNames.MODULE.value)

            storage_path_target = OsCommons().gettargetCSVPath(WorkFlowType.External, job_id)
            fname = sql.getColumnValue(job_id, target_col).split("/")[-1]
            target_csv = storage_path_target + fname

        with allure.step(f"Get Module Rules For: {module}"):
            table_name = RuleCommons.get_db_name_external(module)
            rules_sql = SqlCommons(table_name)
            target_col_name = TableGenColNames.EX_TARGET.value

        with allure.step(f"Read the File under validation: {target_csv} - Rules - {table_name}"):
            df = DfCommons.readCsvOverrideNA(target_csv)

        with allure.step(f"Validate FieldLength Fields: {target_csv}"):
            df_result = ProcessCalls().check_flength_in_df(df, target_col_name, table_name, softerror, rules_sql)

        with allure.step(f"Write result to File:"):
            res_col = TableGenColNames.RES_FIELDLENGTH.value
            ProcessCalls().writeResultToFile(df_result, res_col, job_id, WorkFlowType.External.value)

        softerror.log_all_error_to_report()