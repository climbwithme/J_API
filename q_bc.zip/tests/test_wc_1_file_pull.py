import pytest
import urllib3
import allure
import json

from config_test import TestConfig
from config_general import GnConfig
from systems.reusables.awscommons import AwsCommons
from systems.reusables.commons import Commons
from systems.reusables.oscommons import OsCommons


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class TestWCDownloads:

    @allure.feature("AWS World Check CSV File Download")
    @allure.suite("AWS World Check File Transfer Tests")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_wc_csv_downloads(self):
        # allure.dynamic.tag("AWS", payment_type)
        allure.dynamic.description(f"Retrieve the CSV Files of World Check")

        with allure.step(f"Pull World Check Data From AWS S3"):
            download_file_paths = f'{GnConfig.download_file_paths}/World_Check'
            bucket = TestConfig.wc_csv_bucket
            storage_path = download_file_paths + GnConfig.csv_storage_path
            prefix = TestConfig.wc_raw_csv_prefix
            OsCommons().create_path(storage_path)

            aws_commons = AwsCommons()
            response = aws_commons.get_list_of_objects(bucket, prefix)
            aws_commons.download_files_from_aws(bucket, response, storage_path, endswith='.csv')
            Commons().attachjson_to_allure_astextfile(response, name_to_appear='AWS Client Response')
    
    
    @allure.feature("AWS World Check Raw Parquet File Download")
    @allure.suite("AWS World Check File Transfer Tests")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_wc_raw_pq_downloads(self):
        # allure.dynamic.tag("AWS", payment_type)
        allure.dynamic.description(f"Retrieve the Parquet Files of World Check")

        with allure.step(f"Pull World Check Data From AWS S3"):
            download_file_paths = f'{GnConfig.download_file_paths}/World_Check'
            bucket = TestConfig.wc_pq_bucket
            storage_path = download_file_paths + GnConfig.parquet_storage_path
            prefix = TestConfig.wc_parquet_prefix
            Commons().create_path(storage_path)

            aws_commons = AwsCommons()
            response = aws_commons.get_list_of_objects(bucket, prefix)
            aws_commons.download_files_from_aws(bucket, response, storage_path, endswith='.parquet')
            Commons().attachjson_to_allure_astextfile(response, name_to_appear='AWS Client Response')
    
    