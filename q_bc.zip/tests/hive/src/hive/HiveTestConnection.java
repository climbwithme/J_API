package hive;

import com.opencsv.CSVWriter;
import org.apache.hadoop.security.UserGroupInformation;

import java.io.*;
import java.sql.*;

public class HiveTestConnection {
    public static Connection con = null;
    public static Statement stmt = null;

    public static void main(String[] args) {

        try {

            System.out.println(args[0]);
            System.out.println(args[1]);
            System.out.println(args[2]);
            System.out.println(args[3]);

            String job_id = args[0];
            String module = args[1];
            String filter_start_date = args[2];
            String filter_end_date = args[3];

            getResultCSV(job_id, module, filter_start_date, filter_end_date);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void getResultCSV(String job_id, String module, String filter_start_date, String filter_end_date) throws Exception {
        //set Hive connection
        setHiveConnection();
        String[] query_sources = {"ISO_NAD_Query", "ISO_PMT_Query", "NON_ISO_Query"};
//        String[] query_sources = {"ISO_PMT_Query"};
        String file_path = "../../files/Internal/" + job_id + "/Hive/";
        File f = new File(file_path);
        f.mkdir();
        for (String query_source : query_sources) {
            String file_name = file_path  + query_source + ".csv";
            String query = fetchQueryFrom("./" + query_source + ".txt");
            query = query.replace("start_date", filter_start_date);
            query = query.replace("end_date", filter_end_date);
            System.out.println(query_source);
            ResultSet rs = stmt.executeQuery(query);
            System.out.println("Result Set Obtained");

            FileWriter fileWriter = new FileWriter(file_name);
            CSVWriter csvWriter = new CSVWriter(fileWriter);
            System.out.println("Writing Data");
            csvWriter.writeAll(rs, true);
            System.out.println("Data written");

            csvWriter.close();
            fileWriter.close();


        }
        closeHiveConnection();
    }

    public static void executeDefaultQuery() throws SQLException {
        String setquery1 = "set hive.exec.dynamic.partition=true";
        String setQuery2 = "set hive.exec.dynamic.partition.mode=nonstrict";
        String setQuery3 = "set hive.mapred.mode=nonstrict";
        stmt.execute(setquery1);
        stmt.execute(setQuery2);
        stmt.execute(setQuery3);
    }

    public static void setHiveConnection() {

        String hive_user = "HIVE_USER";
        String hive_conf = "HIVE_CONF";
        String hive_keytab = "HIVE_KEYTAB";
        String truststore = "HIVE_TRUSTSTORE";
        String ssl_pass = "SSL_TS_PASS";

        String krb5_user = System.getenv(hive_user);
        String krb5_conf = System.getenv(hive_conf);
        String krb5_keytab = System.getenv(hive_keytab);

        String ssl_ts = System.getenv(truststore);
        String ssl_ts_pass = System.getenv(ssl_pass);

        System.setProperty("javax.security.auth.useSubjectCredsOnly", "true");
        System.setProperty("java.security.krb5.conf", krb5_conf);
        org.apache.hadoop.conf.Configuration conf = new org.apache.hadoop.conf.Configuration();
        conf.set("hadoop.security.authentication", "kerberos");
        UserGroupInformation.setConfiguration(conf);

        String connection_string = String.format("jdbc:hive2://www.stdbhhiv01n-f5.server.rbsgrp.mde:10000/bdn_eas;principal=service-hive-n/www.stdbhhiv01n-f5.server.rbsgrp.mde@M01EUROPA.M01RBSGRP.MDE;ssl=true;sslTrustStore=%s;trustStorePassword=%s", ssl_ts, ssl_ts_pass);
        System.out.println(connection_string);
        try {
            UserGroupInformation.loginUserFromKeytab(krb5_user, krb5_keytab);

            Class.forName("org.apache.hive.jdbc.HiveDriver");
			con = DriverManager.getConnection(connection_string);
            con.setAutoCommit(false);
            stmt = con.createStatement();
            System.out.println("connected");
            executeDefaultQuery();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public static void closeHiveConnection() throws SQLException {
        stmt.close();
        con.close();
    }

    public static String fetchQueryFrom(String file) throws Exception {
        Reader fileReader = new FileReader(file);
        BufferedReader bufReader = new BufferedReader(fileReader);
        StringBuilder sb = new StringBuilder();
        String line = bufReader.readLine();
        while (line != null) {
            sb.append(line).append(" ");
            line = bufReader.readLine();
        }
        bufReader.close();
		return sb.toString();
    }

}
