from restapi.silk_rest_api_conn import SilkRestAPIConn
from writers.file_writer import FileWriter
from .getdata import GetData
from configs.silkconfig import SilkConfig


class SilkGetData(GetData):

    def getTests(self, conn):
        response = conn.makeRequest(SilkConfig.EP_TESTS)
        assert(response.status_code == 200)
        FileWriter().writeAFile(SilkConfig.REPORT_PATH, SilkConfig.RP_TESTS, response.text, mode='w')