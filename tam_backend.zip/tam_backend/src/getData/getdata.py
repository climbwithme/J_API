from abc import ABC, abstractmethod


class GetData(ABC):

    @abstractmethod
    def getTests(self):
        pass