from configs.zephyrconfig import ZephyrConfig
from dataparser.jira_parseddata import JiraParsedData
from restapi.jira_rest_api_conn import JiraRestAPIConn
from restapi.zephyr_rest_api_conn import ZephyrRestAPIConn
from writers.file_writer import FileWriter
from .getdata import GetData
from configs.jiraconfig import JiraConfig
from multithread.mputil import MpUtil

import math


class JiraGetData(GetData):

    def getListOfIssuesByJQLQuery(self, conn, endpoint) -> list:
        list_of_issue_keys = []
        response = conn.makeRequest(endpoint)

        assert(response.status_code == 200)
        total = response.json().get('total')

        for x in range(0, math.ceil(total/1000)):
            range_endpt = endpoint + f'&maxResults={1000}&startAt={1000*x}'
            sub_response = conn.makeRequest(range_endpt)
            assert(sub_response.status_code == 200)
            json_obj = sub_response.json()
            for issue in json_obj['issues']:
                list_of_issue_keys.append(issue['key'])
        assert(total == len(list_of_issue_keys))
        return list_of_issue_keys

    def getListOfIssueKeysByJQLQuery(self, conn, endpoint) -> list:
        list_of_issue_keys = []
        response = conn.makeRequest(endpoint)

        assert(response.status_code == 200)
        total = response.json().get('total')

        for x in range(0, math.ceil(total/1000)):
            range_endpt = endpoint + f'&maxResults={1000}&startAt={1000*x}'
            sub_response = conn.makeRequest(range_endpt)
            assert(sub_response.status_code == 200)
            json_obj = sub_response.json()
            for issue in json_obj['issues']:
                list_of_issue_keys.append(issue['id'])
        assert(total == len(list_of_issue_keys))
        return list_of_issue_keys

    def getTests(self, conn: JiraRestAPIConn):
        endpoint = 'issuetype=Test+AND+%22Program%20Increment%22=PI8&fields=id,key'
        endpoint = JiraConfig.EP_SEARCH_JQL + \
            f'project={conn.project_id}+AND+' + endpoint
        list_of_test_ids = self.getListOfIssuesByJQLQuery(conn, endpoint)
        # list_of_test_ids = ['CDT-57334', 'CDT-45229']
        list_of_uris = [f"{JiraConfig.JIRA_BASEURI}/{JiraConfig.EP_ITEM}{url}" for url in list_of_test_ids]

        report_path = JiraConfig.REPORT_PATH + f'{conn.project_id}/{JiraConfig.NAME_TESTSPATH}'
        mp = MpUtil(conn.session, report_path)
        mp.setUpMultiURIDownload(list_of_uris)

        # print(mp.counter)

        data = JiraParsedData()
        data.parseTestsData(conn.project_id, report_path)

    def getExecutions(self, conn: JiraRestAPIConn, project_id):
        endpoint = 'issuetype=Test+AND+%22Program%20Increment%22=PI8&fields=id,key'
        endpoint = JiraConfig.EP_SEARCH_JQL + \
            f'project={conn.project_id}+AND+' + endpoint
        list_of_test_ids = self.getListOfIssueKeysByJQLQuery(conn, endpoint)
        # list_of_test_ids = ['CDT-57334', 'CDT-45229']
        print(len(list_of_test_ids))
        QUERY_STRING = f'issueId={list_of_test_ids[0]}&projectId={project_id}'
        zconn = ZephyrRestAPIConn(ZephyrConfig.EP_EXEC_DETAILS, QUERY_STRING)
        list_of_qs = [f'issueId={keys}&projectId={project_id}' for keys in list_of_test_ids]
        # list_of_uris = [ZephyrConfig.ZEPHYR_BASEURI + ZephyrConfig.EP_EXEC_DETAILS + '?' + QS for QS in list_of_qs ]
        report_path = JiraConfig.REPORT_PATH + f'{conn.project_id}/{JiraConfig.NAME_EXECPATH}'
        # for test_id in list_of_test_ids:
        #     QUERY_STRING = f'issueId={test_id}&projectId={project_id}'
        #     
        #     zconn.createSession()
        #     result = zconn.makeRequest()
        #     FileWriter().writeAFile(report_path, f"{test_id}.json", str(result.response), mode='w')

        # list_of_uris = [ZephyrConfig.ZEPHYR_BASEURI + ZephyrConfig.EP_EXEC_DETAILS + '?' + QUERY_STRING]
        
        mp = MpUtil(zconn.session, report_path)
        mp.setUpMultiURIDownloadZephyr(list_of_qs)

    def getDefects(self, conn: JiraRestAPIConn):
        endpoint = 'issuetype=Bug+AND+%22Program%20Increment%22=PI8&fields=id,key'
        endpoint = JiraConfig.EP_SEARCH_JQL + \
            f'project={conn.project_id}+AND+' + endpoint
        list_of_defect_ids = self.getListOfIssuesByJQLQuery(conn, endpoint)
        list_of_uris = [f"{JiraConfig.JIRA_BASEURI}/{JiraConfig.EP_ITEM}{url}" for url in list_of_defect_ids]
        report_path = JiraConfig.REPORT_PATH + f'{conn.project_id}/{JiraConfig.NAME_DEFECTSPATH}'
        
        mp = MpUtil(conn.session, report_path)
        mp.setUpMultiURIDownload(list_of_uris)

        data = JiraParsedData()
        data.parseDefectsData(conn.project_id, report_path)

    def getCycles(self, conn: JiraRestAPIConn):
        endpoint = JiraConfig.JIRA_BASEURI + JiraConfig.EP_CYCLE + conn.project_id
        print(endpoint)
        response = conn.makeRequest(endpoint)
        print(response)