from abc import ABC, abstractmethod


class ParseData(ABC):

    @abstractmethod
    def parseTestsData(self):
        pass