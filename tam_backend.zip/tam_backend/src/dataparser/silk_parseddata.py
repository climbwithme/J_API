from dataparser.parsedata import ParseData


class SilkParsedData(ParseData):

    def parseTestsData(self):
        pass