from configs.jiraconfig import JiraConfig
from configs.zephyrconfig import ZephyrConfig
from datamodels.cycles_model import CyclesModel
from datamodels.cycles_status_model import CyclesStatusModel
from datamodels.defects_model import DefectsModel
from datamodels.tests_model import TestsModel
from dataparser.parsedata import ParseData
from readers.csv_reader import CsvParser
from readers.json_reader import JsonParser
from writers.file_writer import FileWriter

import os
import json


class JiraParsedData(ParseData):

    def parseTestsData(self, project_id, report_path):
        file_name = f'{JiraConfig.NAME_TESTSPATH}.csv'
        path_of_output_file = f'{JiraConfig.REPORT_PATH}/{project_id}/processed'
        fw = FileWriter()
        fw.emptyAFile(path_of_output_file, file_name)
        testmodel = TestsModel(project_id)
        for item in os.listdir(report_path):
            try:
                file_path = report_path + '/' + item
                # print(file_path)

                # for key, value in testmodel.model_dict.items():
                # print(key, value.__str__())
                jsonparser = JsonParser(file_path)
                # print(jsonparser.json_str)
                csv_content = []
                for key, value in testmodel.model_dict.items():
                    if not value.mock:
                        value.value = jsonparser.getJsonValue(value.path)
                    csv_content.append(value.value)
                fw.writeCsvFileFromList(path_of_output_file, file_name, csv_content, mode='a')

                for key, value in testmodel.model_dict.items():
                    value.__reset__()
            except:
                for key, value in testmodel.model_dict.items():
                    value.__reset__()

    def parseDefectsData(self, project_id, report_path):
        file_name = f'{JiraConfig.NAME_DEFECTSPATH}.csv'
        path_of_output_file = f'{JiraConfig.REPORT_PATH}/{project_id}/processed'
        fw = FileWriter()
        fw.emptyAFile(path_of_output_file, file_name)

        defect_model = DefectsModel(project_id)
        for item in os.listdir(report_path):
            try:
                file_path = report_path + '/' + item
                jsonparser = JsonParser(file_path)
                csv_content = []
                for key, value in defect_model.model_dict.items():
                    if not value.mock:
                        value.value = jsonparser.getJsonValue(value.path)
                    csv_content.append(value.value)
                fw.writeCsvFileFromList(path_of_output_file, file_name, csv_content, mode='a')

                for key, value in defect_model.model_dict.items():
                    value.__reset__()
            except:
                for key, value in defect_model.model_dict.items():
                    value.__reset__()
    
    def parseCycleData(self, project_id, report_path):
        reader = CsvParser(report_path)
        for (i,content) in enumerate(reader.csv_content.split('\n')):
            if len(content) > 0:
                [version_id, released, rel_name] = content.split(sep=',', maxsplit=2)
                cycle_json_path = ZephyrConfig.REPORT_PATH + f'/{project_id}/cycles/{version_id}.json'
                
                jsonparser = JsonParser(cycle_json_path)

                for json_value in jsonparser.getJsonArray():
                    jsonparser.temp_str = json.dumps(json_value, indent = 4)
                    cycle_model = CyclesModel(project_id)
                    csv_content = []
                    for key, value in cycle_model.model_dict.items():
                        
                        if value.key == 'CycleName':
                            value.value = rel_name
                        elif value.key == 'released':
                            value.value = released
                        elif not value.mock:
                            try:
                                value.value = jsonparser.getJsonValue(value.path, temp_str=True)
                            except:
                                pass    # Jira migrated data from cloud sometimes dont have cloud field index
                        csv_content.append(value.value)
                    print(csv_content)

    def parseCycleStatusData(self, project_id, report_path):
        reader = CsvParser(report_path)
        for (i,content) in enumerate(reader.csv_content.split('\n')):
            if len(content) > 0:
                [version_id, released, rel_name] = content.split(sep=',', maxsplit=2)
                cycle_json_path = ZephyrConfig.REPORT_PATH + f'/{project_id}/cycles/{version_id}.json'
                
                jsonparser = JsonParser(cycle_json_path)
                for json_value in jsonparser.getJsonArray():
                    jsonparser.temp_str = json.dumps(json_value, indent = 4)
                    version_name = jsonparser.getJsonValue(['name'], temp_str=True)

                    exec_summary = json.dumps(json_value)
                    exec_jsonparser = JsonParser(exec_summary, json_str=True)
                    for ex_statuses in exec_jsonparser.getJsonArrayForIndex('executionSummaries'):
                        # print(ex_statuses)
                        exec_jsonparser.temp_str = json.dumps(ex_statuses, indent = 4)
                        cycle_status_model = CyclesStatusModel(project_id)
                        csv_content = []
                        for key, value in cycle_status_model.model_dict.items():
                            if value.key == 'CycleName':
                                value.value = rel_name
                            elif value.key == 'VersionId':
                                value.value = version_id
                            elif value.key == 'VersionName':
                                value.value = version_name
                            elif not value.mock:
                                try:
                                    value.value = exec_jsonparser.getJsonValue(value.path, temp_str=True)
                                except:
                                    pass    # Jira migrated data from cloud sometimes dont have cloud field index
                            csv_content.append(value.value)
                        print(csv_content)
                        # break