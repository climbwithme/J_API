import os

from .config import Config


class SilkConfig(object):

    SILK_BASEURI = 'http://www.silkcentral.web.rbsgrp.net'
    SILK_BEARERTOKEN = os.environ.get('LK_BEARER_TOKEN')
    SC_WS_TOKEN = os.environ.get('SC_WS_TOKEN')
    SILK_PROXY = Config.PROXY

    REPORT_ATTRIBUTE = 8545
    REPORT_TESTS = 6180

    EP_ATTRIBUTE = f'/servicesExchange?hid=reportData&reportFilterID={REPORT_ATTRIBUTE}&type=csv&includeHeaders=false&sid={SC_WS_TOKEN}&projectID=6'
    EP_TESTS = f'/servicesExchange?hid=reportData&reportFilterID={REPORT_TESTS}&type=csv&includeHeaders=false&sid={SC_WS_TOKEN}&projectID=6'

    REPORT_PATH = './results/SILK/'
    RP_TESTS = 'tests.csv'