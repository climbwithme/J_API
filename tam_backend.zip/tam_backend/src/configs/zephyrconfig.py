import os
import jwt
import time
import hashlib

from .config import Config


class ZephyrConfig(object):

    ZEPHYR_BASEURI = 'https://prod-api.zephyr4jiracloud.com/connect'
    ZEPHYR_PROXY = Config.PROXY

    ACCOUNT_ID = '6228bc4594f7e2006901c82d'
    ACCESS_KEY = 'NzZiNjZhZjEtYzEyOS0zNDU4LTk0ZjgtMzhmYThhZGY0MjZlIDYyMjhiYzQ1OTRmN2UyMDA2OTAxYzgyZCBVU0VSX0RFRkFVTFRfTkFNRQ'
    SECRET_KEY = '5Mk_7Hb9ZvEAoHgh2_Q-EosTWbDXTWMVLFIacapRiIM'
    # JWT EXPIRE how long token been to be active? 3600 == 1 hour
    JWT_EXPIRE = 3600

    def get_PAYLOAD_TOKEN(self, CANONICAL_PATH: str):
        return {
            'sub': self.ACCOUNT_ID,
            'qsh': hashlib.sha256(CANONICAL_PATH.encode('utf-8')).hexdigest(),
            'iss': self.ACCESS_KEY,
            'exp': int(time.time())+self.JWT_EXPIRE,
            'iat': int(time.time())
        }

    def getToken(self, CANONICAL_PATH: str):
        return jwt.encode(self.get_PAYLOAD_TOKEN(CANONICAL_PATH), self.SECRET_KEY, algorithm='HS256').strip().decode('utf-8')
    
    REPORT_PATH = './results/jira/zapi/'

    EP_ZQL_VALUES = '/public/rest/api/1.0/zql/fields/values'
    EP_CYCLE_DETAILS = '/public/rest/api/1.0/cycles/search'
    EP_EXEC_DETAILS = '/public/rest/api/1.0/executions'
