import os

class Config(object):

    USER = os.environ.get('LK_USER_NAME')
    PASSWORD = os.environ.get('LK_PASSWORD')
    PROXY = {
        'http': f"http://{USER}:{PASSWORD}@userproxy.rbsgrp.net:8080",
        'https': f"http://{USER}:{PASSWORD}@userproxy.rbsgrp.net:8080",
    }