import os

from .config import Config


class JiraConfig(object):

    JIRA_BASEURI = 'https://testmig2-natwest.atlassian.net' #UAT Environment
    JIRA_TOKEN = 'Basic bWFuanVuYXRoLnN1YnJhbWFuaS1jaGFuZHJhYm9zZS1wYW5kaWFyYWphbkBuYXR3ZXN0LmNvbTpjaTFuMTNEeGlMejM0dDZnaU94ZjcwMUE='   # os.get.env -> different for different users

    JIRA_USER = Config.USER
    JIRA_PASSWORD = Config.PASSWORD
    JIRA_PROXY = Config.PROXY

    NAME_TESTSPATH = 'Tests'
    NAME_EXECPATH = 'Executions'
    NAME_DEFECTSPATH = 'Defects'
    NAME_CYCLESPATH = 'Cycles'
    NAME_CYCLE_STATUS_PATH = 'CycleStatus'

    REPORT_PATH = './results/jira/'

    EP_ITEM = '/rest/agile/1.0/issue/'
    EP_SEARCH_JQL = '/rest/api/3/search?jql='
    EP_CYCLE = '/rest/zapi/latest/cycle?projectId='