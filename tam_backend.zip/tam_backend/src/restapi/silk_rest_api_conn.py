from requests import sessions
from requests.models import Response
from .rest_api_conn import RestAPIConn
from configs.silkconfig import SilkConfig

import requests


class SilkRestAPIConn(RestAPIConn):

    def __init__(self) -> None:
        self.baseURI = SilkConfig.SILK_BASEURI
        self.session = requests.Session()
    
    def createSession(self) -> sessions:
        self.session.headers = {'Authorization': SilkConfig.SILK_BEARERTOKEN}
        self.session.proxies = SilkConfig.SILK_PROXY
        self.session.verify = False

    def makeRequest(self, endpoint='') -> Response:
        return self.session.get(self.constructEndPoint(endpoint))
        

class BearerAuth(requests.auth.AuthBase):
    def __init__(self, token):
        self.token = token

    def __call__(self, r):
        r.headers["authorization"] = "Bearer " + self.token
        return r