from abc import ABC, abstractmethod
from requests.models import Response
from requests.sessions import Session


class RestAPIConn(ABC):

    session: Session
    baseURI: str
    project_id: str = None

    @abstractmethod
    def createSession(self) -> Session:
        pass

    @abstractmethod
    def makeRequest(self) -> Response:
        pass

    def constructEndPoint(self, endpoint) -> str:
        return f'{self.baseURI}/{endpoint}'
