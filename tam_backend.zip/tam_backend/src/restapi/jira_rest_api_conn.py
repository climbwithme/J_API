from requests.models import Response
from requests.sessions import Session
from .rest_api_conn import RestAPIConn
from configs.jiraconfig import JiraConfig

import requests


class JiraRestAPIConn(RestAPIConn):


    def __init__(self) -> None:
        self.baseURI = JiraConfig.JIRA_BASEURI
        self.session = requests.Session()
        

    def __init__(self, project_id) -> None:
        self.baseURI = JiraConfig.JIRA_BASEURI
        self.session = requests.Session()
        self.project_id = project_id

    def createSession(self) -> Session:
        self.session.headers = {'Authorization': JiraConfig.JIRA_TOKEN}
        self.session.proxies = JiraConfig.JIRA_PROXY
        self.session.verify = False

    def makeRequest(self, endpoint='') -> Response:
        return self.session.get(self.constructEndPoint(endpoint))
