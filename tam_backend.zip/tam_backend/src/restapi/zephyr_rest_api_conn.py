from requests.models import Response
from requests.sessions import Session
from .rest_api_conn import RestAPIConn
from configs.zephyrconfig import ZephyrConfig

import requests


class ZephyrRestAPIConn(RestAPIConn):

    CANONICAL_PATH: str
    QUERY_STRING: str
    HEADERS : dict
    JWT_FOR_SESSION: str
    RELATIVE_PATH: str

    def __init__(self, RELATIVE_PATH, QUERY_STRING, type='GET') -> None:
        self.baseURI = ZephyrConfig.ZEPHYR_BASEURI
        self.session = requests.Session()
        self.QUERY_STRING = QUERY_STRING
        self.RELATIVE_PATH = RELATIVE_PATH
        if type == 'GET':
            self.CANONICAL_PATH = 'GET&' + RELATIVE_PATH + '&' + QUERY_STRING
        else:
            pass # This tool is meant to retrieve data only and not update any data
        self.JWT_FOR_SESSION = ZephyrConfig().getToken(self.CANONICAL_PATH)
        self.HEADERS = {
            'Authorization': 'JWT '+ self.JWT_FOR_SESSION,
            'Content-Type': 'application/json',
            'zapiAccessKey': ZephyrConfig.ACCESS_KEY
        }
    
    def set_new_query_string(self, QUERY_STRING):
        self.QUERY_STRING = QUERY_STRING

    def makeRequest(self) -> Response:
        return requests.get(
            ZephyrConfig.ZEPHYR_BASEURI + self.RELATIVE_PATH + '?' + self.QUERY_STRING,
            headers=self.HEADERS,
            proxies=ZephyrConfig.ZEPHYR_PROXY,
            verify=False,
            json={}
        )

    def createSession(self) -> Session:
        self.session.headers = self.HEADERS
        self.session.proxies = ZephyrConfig.ZEPHYR_PROXY
        self.session.verify = False