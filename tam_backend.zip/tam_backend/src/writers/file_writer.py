import os
import csv

class FileWriter:

    def writeAFile(self, path, filename, data, mode='a'):
        if not os.path.exists(path):
            os.makedirs(path)
        
        file_path = f'{path}/{filename}'
        with open(file_path, mode, encoding='UTF8', newline='') as f:
            f.write(data)
        f.close()

    def writeCsvFileFromList(self, path, filename, list_of_data, mode='a'):
        if not os.path.exists(path):
            os.makedirs(path)
        
        file_path = f'{path}/{filename}'
        
        with open(file_path, mode, encoding='UTF8', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(list_of_data)
        f.close()
    

    def emptyAFile(self, path, filename):
        if not os.path.exists(path):
            os.makedirs(path)
        
        file_path = f'{path}/{filename}'
        with open(file_path, 'w', encoding='UTF8', newline='') as f:
            f.write('')
        f.close()