import multiprocessing
import json
import urllib3

from requests.sessions import Session
from configs.zephyrconfig import ZephyrConfig
from restapi.zephyr_rest_api_conn import ZephyrRestAPIConn
from writers.file_writer import FileWriter

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class MpUtil:

    # global counter 
    session: Session
    report_path: str
    # counter: int

    def __init__(self, session: Session, report_path: str) -> None:
        self.session = session
        self.response_json_list = []
        self.report_path = report_path
        # self.counter = 0

    def initialiser(self, counter_val):
        global counter
        counter = counter_val

    def setUpMultiURIDownload(self, endpoints):
        with multiprocessing.Pool(processes=25, initializer=self.initialiser, initargs=(0,)) as pool:
            pool.map(self.download_site, endpoints)

    def download_site(self, url: str):
        with self.session.get(url) as response:
            name = multiprocessing.current_process().name
            FileWriter().writeAFile(self.report_path, f'{url.rpartition("/")[2]}.txt', response.text, mode='w')
            # print(f"{name}:Read {response.status_code} from {url}")
            
            # assert(response.status_code == 200)
            # print(response.status_code)


    def setUpMultiURIDownloadZephyr(self, list_of_qs):
        with multiprocessing.Pool(processes=40, initializer=self.initialiser, initargs=(0,)) as pool:
            pool.map(self.download_siteZephyr, list_of_qs)

    def download_siteZephyr(self, QUERY_STRING: list):
        count = 0
        while True:
            if count > 2:
                break
            zconn = ZephyrRestAPIConn(ZephyrConfig.EP_EXEC_DETAILS, QUERY_STRING)
            response = zconn.makeRequest()
            if response.status_code == 200:
                fname = QUERY_STRING.split('=')[1]
                fname = fname.split('&')[0]
                FileWriter().writeAFile(self.report_path, f"{fname}.json", response.text, mode='w')
                count+=1
                break
            # print(f"{name}:Read {response.status_code} from {url}")
            
            # assert(response.status_code == 200)
            # print(response.status_code)
