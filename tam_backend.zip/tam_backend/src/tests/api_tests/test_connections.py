from configs.jiraconfig import JiraConfig
from configs.silkconfig import SilkConfig
from restapi.jira_rest_api_conn import JiraRestAPIConn
from restapi.silk_rest_api_conn import SilkRestAPIConn

import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class TestConnections:

    def test_jira_connection(self):
        conn = JiraRestAPIConn()
        conn.createSession()
        response = conn.makeRequest(JiraConfig.EP_ITEM + 'CDT-57553')
        assert(response.status_code == 200)


    def test_silk_connection(self):
        conn = SilkRestAPIConn()
        conn.createSession()
        response = conn.makeRequest(SilkConfig.EP_ATTRIBUTE)
        assert(response.status_code == 200)
