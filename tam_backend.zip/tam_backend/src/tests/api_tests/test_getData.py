from configs.zephyrconfig import ZephyrConfig
from configs.config import Config
from dataparser.jira_parseddata import JiraParsedData
from getData.jira_getdata import JiraGetData
from getData.silk_getdata import SilkGetData
from readers.csv_reader import CsvParser
from readers.json_reader import JsonParser
from restapi.jira_rest_api_conn import JiraRestAPIConn
from restapi.silk_rest_api_conn import SilkRestAPIConn

import urllib3
import json

from restapi.zephyr_rest_api_conn import ZephyrRestAPIConn
from writers.file_writer import FileWriter

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class TestGetData:


    def test_getSilkTestsData(self):        
        conn = SilkRestAPIConn()
        conn.createSession()
        SilkGetData().getTests(conn)

    def test_getJiraTestsData(self):
        conn = JiraRestAPIConn('41862')
        conn.createSession()
        JiraGetData().getTests(conn)

    def test_getJiraDefectsData(self):
        conn = JiraRestAPIConn('41862')
        conn.createSession()
        JiraGetData().getDefects(conn)

    def test_getJiraExecutionData(self):
        project_id = 41862
        conn = JiraRestAPIConn(project_id)
        conn.createSession()
        JiraGetData().getExecutions(conn, project_id)

    def test_getJiraCycleData(self):
        zephyr_values = 'zapi_values.json'
        project_id = 41862
        '''
        RELATIVE_PATH = ZephyrConfig.EP_ZQL_VALUES
        QUERY_STRING = ''

        conn = ZephyrRestAPIConn(RELATIVE_PATH, QUERY_STRING)
        result = conn.makeRequest()

        assert(result.status_code == 200)

        zapi_values = result.json()
        fw = FileWriter()
        fw.emptyAFile(ZephyrConfig.REPORT_PATH, zephyr_values)
        fw.writeAFile(ZephyrConfig.REPORT_PATH, zephyr_values, json.dumps(zapi_values, indent=4, sort_keys=True))
        '''
        
        first = True
        conn: ZephyrRestAPIConn
        CYCLE_REPORT_PATH = f'{ZephyrConfig.REPORT_PATH}/{project_id}/cycles/'

        json_read = JsonParser(f"{ZephyrConfig.REPORT_PATH}/{zephyr_values}")
        list_to_parse = ['fields', 'cycleName']
        list_to_parse_fv = ['fields', 'fixVersion']
        result_section = json_read.getJsonValue(list_to_parse)
        fixversion_section = json_read.getJsonValue(list_to_parse_fv)
        version_list = []
        for jarray_value in result_section:
            if jarray_value['projectId'] == project_id:
                # print(jarray_value)
                versionId = jarray_value['versionId']
                name = jarray_value['name']
                # version_list.append((versionId, name))
        for jarray_value in fixversion_section:
            if jarray_value['projectId'] == project_id:
                # print(jarray_value)
                versionId = jarray_value['id']
                name = jarray_value['name']
                released = jarray_value['released']
                version_list.append((versionId, name, released))
        version_list = set(version_list)
        # print(version_list)
        for versionId, name, released in version_list:
            QUERY_STRING = f'expand=executionSummaries&projectId={project_id}&versionId={versionId}'
            # print(QUERY_STRING)
            # if first:
            conn = ZephyrRestAPIConn(ZephyrConfig.EP_CYCLE_DETAILS, QUERY_STRING)
                # first = False
            # else:
                # conn.set_new_query_string(QUERY_STRING)
            result = conn.makeRequest()
            # print(result.json())
            assert(result.status_code == 200)
            fw = FileWriter()
            fw.emptyAFile(CYCLE_REPORT_PATH, f'{versionId}.json')
            fw.writeAFile(CYCLE_REPORT_PATH, f'{versionId}.json', json.dumps(result.json(), indent=4, sort_keys=True))
        fw = FileWriter()
        fw.emptyAFile(CYCLE_REPORT_PATH, 'cycle_version_map.csv')
        for versionId, name, released in version_list:
            fw.writeAFile(CYCLE_REPORT_PATH, 'cycle_version_map.csv', f'{versionId},{released},{name.strip()}\n')

    def test_readCycleData(self):
        project_id = 41862
        cycle_version_path = ZephyrConfig.REPORT_PATH + f'/{project_id}/cycles/cycle_version_map.csv'
        jpd = JiraParsedData()
        jpd.parseCycleData(project_id, cycle_version_path)

    def test_readCycleStatusData(self):
        project_id = 41862
        cycle_version_path = ZephyrConfig.REPORT_PATH + f'/{project_id}/cycles/cycle_version_map.csv'
        jpd = JiraParsedData()
        jpd.parseCycleStatusData(project_id, cycle_version_path)
        