import yaml

from .model import Model

class TestsEnum():

    TestID = Model('TestID')
    URL = Model('URL')
    Project = Model('Project')
    Workstream = Model('Workstream')
    ProjectName = Model('ProjectName')
    Name = Model('Name')
    Component = Model('Component')
    SubComponent = Model('SubComponent')
    TestingArea = Model('TestingArea')
    Lifecycle = Model('Lifecycle')
    TestTypeName = Model('TestTypeName')
    TestCreated = Model('TestCreated')


class TestsModel:

    project_id: str
    yaml_mock_info: str
    yaml_json_info: str

    testsModal = TestsEnum()

    model_dict = {
        testsModal.ProjectName.key: testsModal.ProjectName,
        testsModal.Name.key: testsModal.Name,
        testsModal.TestTypeName.key: testsModal.TestTypeName,
        testsModal.URL.key: testsModal.URL,
        testsModal.TestID.key: testsModal.TestID,
        testsModal.TestCreated.key: testsModal.TestCreated,
        testsModal.Project.key: testsModal.Project,
        testsModal.Workstream.key: testsModal.Workstream,
        testsModal.TestingArea.key: testsModal.TestingArea,
        testsModal.Lifecycle.key: testsModal.Lifecycle,
        testsModal.Component.key: testsModal.Component,
        testsModal.SubComponent.key: testsModal.SubComponent
    }

    def __init__(self, project_id) -> None:
        self.project_id = project_id
        f = open(
            f'./src/datamodels/mock_configs/mock_{self.project_id}.yml', 'r')
        self.yaml_mock_info = yaml.load(f, Loader=yaml.FullLoader)
        self.yaml_mock_info = self.yaml_mock_info.get('Tests')[0]
        f.close()
        print(self.model_dict.keys())
        for key, value in self.model_dict.items():
            value.mock = self.yaml_mock_info[key]
        f = open(f'./src/datamodels/ds_configs/ds_{self.project_id}.yml', 'r')
        self.yaml_json_info = yaml.load(f, Loader=yaml.FullLoader)
        for key, value in self.model_dict.items():
            value.path = self.yaml_json_info.get('Tests')[key]
