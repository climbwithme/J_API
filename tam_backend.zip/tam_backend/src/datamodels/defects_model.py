import yaml

from configs.jiraconfig import JiraConfig

from .model import Model

class DefectsEnum():

    ID = Model('ID')
    ProjectName = Model('ProjectName')
    IssueNumber = Model('IssueNumber')
    State = Model('State')
    Severity = Model('Severity')
    DateCreated = Model('DateCreated')
    TAMTestPhase = Model('TAMTestPhase')
    RootCause = Model('RootCause')
    RootCause2 = Model('RootCause2')
    BusinessPriority = Model('BusinessPriority')
    Synopsis = Model('Synopsis')
    DEPENDENCY = Model('DEPENDENCY')
    pass


class DefectsModel():
    
    project_id: str
    yaml_mock_info: str
    yaml_json_info: str

    defectsModal = DefectsEnum()

    model_dict = {
        defectsModal.ID.key: defectsModal.ID,
        defectsModal.ProjectName.key: defectsModal.ProjectName,
        defectsModal.IssueNumber.key: defectsModal.IssueNumber,
        defectsModal.State.key: defectsModal.State,
        defectsModal.Severity.key: defectsModal.Severity,
        defectsModal.DateCreated.key: defectsModal.DateCreated,
        defectsModal.TAMTestPhase.key: defectsModal.TAMTestPhase,
        defectsModal.RootCause.key: defectsModal.RootCause,
        defectsModal.RootCause2.key: defectsModal.RootCause2,
        defectsModal.BusinessPriority.key: defectsModal.BusinessPriority,
        defectsModal.Synopsis.key: defectsModal.Synopsis,
        # defectsModal.DEPENDENCY.key: defectsModal.DEPENDENCY
    }

    def __init__(self, project_id) -> None:
        self.project_id = project_id
        f = open(
            f'./src/datamodels/mock_configs/mock_{self.project_id}.yml', 'r')
        self.yaml_mock_info = yaml.load(f, Loader=yaml.FullLoader)
        self.yaml_mock_info = self.yaml_mock_info.get(JiraConfig.NAME_DEFECTSPATH)[0]
        f.close()
        print(self.model_dict.keys())
        for key, value in self.model_dict.items():
            value.mock = self.yaml_mock_info[key]
        f = open(f'./src/datamodels/ds_configs/ds_{self.project_id}.yml', 'r')
        self.yaml_json_info = yaml.load(f, Loader=yaml.FullLoader)
        for key, value in self.model_dict.items():
            value.path = self.yaml_json_info.get(JiraConfig.NAME_DEFECTSPATH)[key]
