

class Model:

    mock: bool
    key: str
    value: str
    path: list

    def __init__(self, key) -> None:
        self.key = key
        self.mock = False
        self.value = ''

    def __str__(self) -> str:
        return f"{self.key}\t{self.mock}\t{self.path}"

    def __reset__(self):
        self.value = ''