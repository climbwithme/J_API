import yaml

from configs.jiraconfig import JiraConfig

from .model import Model

class CyclesEnum():

    # CycleID = Model('CycleID')
    CycleName = Model('CycleName')
    VersionId = Model('VersionId')
    VersionName = Model('VersionName')
    Description = Model('Description')
    TestPhase = Model('TestPhase')
    start_date = Model('startDate')
    end_date = Model('endDate')
    released = Model('released')
    totalCycleExecuted = Model('totalCycleExecuted')
    totalCycleExecutions = Model('totalCycleExecutions')
    # statusCount = Model('statusCount')


class CyclesModel():
    
    project_id: str
    yaml_mock_info: str
    yaml_json_info: str

    cyclesModal = CyclesEnum()

    model_dict = {
        # cyclesModal.CycleID.key: cyclesModal.CycleID,
        cyclesModal.CycleName.key: cyclesModal.CycleName,
        cyclesModal.VersionId.key: cyclesModal.VersionId,
        cyclesModal.VersionName.key: cyclesModal.VersionName,
        cyclesModal.Description.key: cyclesModal.Description,
        cyclesModal.TestPhase.key: cyclesModal.TestPhase,
        cyclesModal.start_date.key: cyclesModal.start_date,
        cyclesModal.end_date.key: cyclesModal.end_date,
        cyclesModal.released.key: cyclesModal.released,
        cyclesModal.totalCycleExecuted.key: cyclesModal.totalCycleExecuted,
        cyclesModal.totalCycleExecutions.key: cyclesModal.totalCycleExecutions
        # cyclesModal.statusCount.key: cyclesModal.statusCount
    }

    def __init__(self, project_id) -> None:
        self.project_id = project_id
        f = open(
            f'./src/datamodels/mock_configs/mock_{self.project_id}.yml', 'r')
        self.yaml_mock_info = yaml.load(f, Loader=yaml.FullLoader)
        self.yaml_mock_info = self.yaml_mock_info.get(JiraConfig.NAME_CYCLESPATH)[0]
        f.close()
        # print(self.model_dict.keys())
        for key, value in self.model_dict.items():
            value.mock = self.yaml_mock_info[key]
        f = open(f'./src/datamodels/ds_configs/ds_{self.project_id}.yml', 'r')
        self.yaml_json_info = yaml.load(f, Loader=yaml.FullLoader)
        for key, value in self.model_dict.items():
            value.path = self.yaml_json_info.get(JiraConfig.NAME_CYCLESPATH)[key]
