import yaml

from configs.jiraconfig import JiraConfig

from .model import Model

class CyclesStatusEnum():

    # CycleID = Model('CycleID')
    CycleName = Model('CycleName')
    VersionId = Model('VersionId')
    VersionName = Model('VersionName')
    Status = Model('Status')
    StatusWiseCount = Model('StatusWiseCount')


class CyclesStatusModel():
    
    project_id: str
    yaml_mock_info: str
    yaml_json_info: str

    cyclesStatusModal = CyclesStatusEnum()

    model_dict = {
        cyclesStatusModal.CycleName.key: cyclesStatusModal.CycleName,
        cyclesStatusModal.VersionId.key: cyclesStatusModal.VersionId,
        cyclesStatusModal.VersionName.key: cyclesStatusModal.VersionName,
        cyclesStatusModal.Status.key: cyclesStatusModal.Status,
        cyclesStatusModal.StatusWiseCount.key: cyclesStatusModal.StatusWiseCount
    }

    def __init__(self, project_id) -> None:
        self.project_id = project_id
        f = open(
            f'./src/datamodels/mock_configs/mock_{self.project_id}.yml', 'r')
        self.yaml_mock_info = yaml.load(f, Loader=yaml.FullLoader)
        self.yaml_mock_info = self.yaml_mock_info.get(JiraConfig.NAME_CYCLE_STATUS_PATH)[0]
        f.close()
        # print(self.model_dict.keys())
        for key, value in self.model_dict.items():
            value.mock = self.yaml_mock_info[key]
        f = open(f'./src/datamodels/ds_configs/ds_{self.project_id}.yml', 'r')
        self.yaml_json_info = yaml.load(f, Loader=yaml.FullLoader)
        for key, value in self.model_dict.items():
            value.path = self.yaml_json_info.get(JiraConfig.NAME_CYCLE_STATUS_PATH)[key]
