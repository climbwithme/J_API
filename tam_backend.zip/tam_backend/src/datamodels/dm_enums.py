# import enum
# from enum import Flag

# class BooleanEnum(Flag):
#     TRUE = True
#     FALSE = False

# class Boolean(Flag):
#     TRUE = True
#     FALSE = False