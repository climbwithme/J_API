import json


class JsonParser:

    json_str : str
    temp_str : str

    def __init__(self, file_path: str, json_str=False) -> None:
        if json_str:
            self.json_str = file_path
        else:
            with open(file_path, encoding='UTF8') as f:
                self.json_str = f.read()
            

    def getJsonValue(self, list_of_node: list, temp_str=False):
        if temp_str:
            response = json.loads(self.temp_str)
        else:
            response = json.loads(self.json_str)
        for k in list_of_node:
            if response == None:
                return ''
            response = response[k]
        return response

    def getJsonArray(self):
        json_arr = json.loads(self.json_str)
        return json_arr

    def getJsonArrayForIndex(self, index_str: str):
        json_arr = json.loads(self.json_str)
        return json_arr[index_str]