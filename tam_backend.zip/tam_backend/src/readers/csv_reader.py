import csv


class CsvParser:

    csv_content : str

    def __init__(self, file_path: str) -> None:
        with open(file_path, encoding='UTF8') as f:
            self.csv_content = f.read()
    
    